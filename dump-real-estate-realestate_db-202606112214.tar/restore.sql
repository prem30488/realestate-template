--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.3 (Debian 18.3-1.pgdg13+1)
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE realestate_db;
--
-- Name: realestate_db; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE realestate_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


\unrestrict (null)
\connect realestate_db
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: enum_ChatMessages_sender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."enum_ChatMessages_sender" AS ENUM (
    'user',
    'assistant'
);


--
-- Name: enum_Users_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."enum_Users_role" AS ENUM (
    'superadmin',
    'admin',
    'user'
);


--
-- Name: enum_amenities_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_amenities_type AS ENUM (
    'Indoor',
    'Outdoor'
);


--
-- Name: enum_properties_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_properties_status AS ENUM (
    'For Sale',
    'For Rent'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Amenities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Amenities" (
    id integer NOT NULL,
    type character varying(255),
    title character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: Amenities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Amenities_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Amenities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Amenities_id_seq" OWNED BY public."Amenities".id;


--
-- Name: Brands; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Brands" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    image character varying(255) NOT NULL,
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    tagline character varying(255),
    description text,
    "experienceYears" integer DEFAULT 0,
    "totalProjects" integer DEFAULT 0,
    "ongoingProjects" integer DEFAULT 0,
    "completedProjects" integer DEFAULT 0,
    "operatingCities" character varying(255),
    rating double precision DEFAULT '0'::double precision,
    "reviewsCount" integer DEFAULT 0,
    category character varying(255),
    "websiteUrl" character varying(255)
);


--
-- Name: Brands_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Brands_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Brands_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Brands_id_seq" OWNED BY public."Brands".id;


--
-- Name: Brokers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Brokers" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    photo character varying(255),
    email character varying(255),
    experience character varying(255),
    specialization character varying(255),
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "phoneNumber" character varying(255),
    designation character varying(255),
    facebook character varying(255),
    twitter character varying(255),
    linkedin character varying(255),
    instagram character varying(255),
    city character varying(255)
);


--
-- Name: Brokers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Brokers_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Brokers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Brokers_id_seq" OWNED BY public."Brokers".id;


--
-- Name: Builders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Builders" (
    id integer NOT NULL,
    company_name character varying(255) NOT NULL,
    owner_name character varying(255),
    logo_url character varying(255),
    description text,
    email character varying(255) NOT NULL,
    phone_primary character varying(255) NOT NULL,
    phone_secondary character varying(255),
    website_url character varying(255),
    office_address text,
    city character varying(255),
    state character varying(255),
    zip_code character varying(255),
    license_number character varying(255),
    tax_id character varying(255),
    established_year integer,
    company_type character varying(255),
    insurance_details text,
    primary_specialty character varying(255),
    services_offered jsonb,
    operating_regions jsonb,
    total_projects_completed integer DEFAULT 0,
    active_projects integer DEFAULT 0,
    average_rating double precision DEFAULT '0'::double precision,
    total_reviews integer DEFAULT 0,
    portfolio_link character varying(255),
    status character varying(255) DEFAULT 'Pending Verification'::character varying,
    is_verified boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: Builders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Builders_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Builders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Builders_id_seq" OWNED BY public."Builders".id;


--
-- Name: ChatConversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ChatConversations" (
    id integer NOT NULL,
    title character varying(255),
    "userId" integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: ChatConversations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ChatConversations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ChatConversations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."ChatConversations_id_seq" OWNED BY public."ChatConversations".id;


--
-- Name: ChatMessages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ChatMessages" (
    id integer NOT NULL,
    "conversationId" integer NOT NULL,
    "userId" integer,
    sender public."enum_ChatMessages_sender" NOT NULL,
    message text NOT NULL,
    meta jsonb,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: ChatMessages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ChatMessages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ChatMessages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."ChatMessages_id_seq" OWNED BY public."ChatMessages".id;


--
-- Name: Cities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Cities" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    latitude numeric(10,8),
    longitude numeric(11,8),
    "isPopular" boolean DEFAULT false,
    "isNearby" boolean DEFAULT false,
    "order" integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: Cities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Cities_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Cities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Cities_id_seq" OWNED BY public."Cities".id;


--
-- Name: EmailTemplates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmailTemplates" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    body text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: EmailTemplates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."EmailTemplates_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: EmailTemplates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."EmailTemplates_id_seq" OWNED BY public."EmailTemplates".id;


--
-- Name: FunFacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FunFacts" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    value character varying(255) NOT NULL,
    icon character varying(255),
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: FunFacts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."FunFacts_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: FunFacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."FunFacts_id_seq" OWNED BY public."FunFacts".id;


--
-- Name: HomeComponents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."HomeComponents" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "displayName" character varying(255) NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: HomeComponents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."HomeComponents_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: HomeComponents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."HomeComponents_id_seq" OWNED BY public."HomeComponents".id;


--
-- Name: InstaReels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."InstaReels" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    "videoUrl" text NOT NULL,
    "thumbnailUrl" text,
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: InstaReels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."InstaReels_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: InstaReels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."InstaReels_id_seq" OWNED BY public."InstaReels".id;


--
-- Name: Localities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Localities" (
    id integer NOT NULL,
    city_id integer NOT NULL,
    name character varying(255) NOT NULL,
    postal_code character varying(255),
    latitude numeric(10,8),
    longitude numeric(11,8),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    rating numeric(3,2) DEFAULT 4,
    overview text,
    connectivity jsonb,
    infrastructure jsonb,
    lifestyle jsonb,
    real_estate_trends jsonb,
    image_url character varying(255)
);


--
-- Name: Localities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Localities_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Localities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Localities_id_seq" OWNED BY public."Localities".id;


--
-- Name: MenuItems; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MenuItems" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    link character varying(255),
    "parentId" integer,
    "itemType" character varying(255) DEFAULT 'link'::character varying NOT NULL,
    "menuType" character varying(255),
    badge character varying(255),
    "order" integer DEFAULT 0 NOT NULL,
    "isDeleted" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: MenuItems_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."MenuItems_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: MenuItems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."MenuItems_id_seq" OWNED BY public."MenuItems".id;


--
-- Name: Projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Projects" (
    id integer NOT NULL,
    locality_id integer NOT NULL,
    property_type_id integer NOT NULL,
    builder_id integer NOT NULL,
    city_id integer NOT NULL,
    "projectName" character varying(255) NOT NULL,
    budget character varying(255),
    state character varying(255),
    country character varying(255) DEFAULT 'India'::character varying,
    total_units integer,
    project_size character varying(255),
    launch_date timestamp with time zone,
    total_towers integer,
    bhk character varying(255),
    technical_information text,
    ratings numeric(3,2) DEFAULT 0,
    photo_url character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: Projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Projects_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Projects_id_seq" OWNED BY public."Projects".id;


--
-- Name: Properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Properties" (
    id integer NOT NULL,
    "typeId" integer,
    city character varying(255),
    state character varying(255),
    country character varying(255),
    latitude double precision,
    longitude double precision,
    title character varying(255),
    status character varying(255),
    price numeric,
    location character varying(255),
    area double precision,
    no_of_bedrooms integer,
    no_of_bathrooms integer,
    posted_by integer,
    featured boolean,
    no_of_garage integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: Properties_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Properties_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Properties_id_seq" OWNED BY public."Properties".id;


--
-- Name: PropertyImages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PropertyImages" (
    id integer NOT NULL,
    "propertyId" integer,
    "imageUrl" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: PropertyImages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."PropertyImages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: PropertyImages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."PropertyImages_id_seq" OWNED BY public."PropertyImages".id;


--
-- Name: PropertyTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PropertyTypes" (
    id integer NOT NULL,
    name character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: PropertyTypes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."PropertyTypes_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: PropertyTypes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."PropertyTypes_id_seq" OWNED BY public."PropertyTypes".id;


--
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


--
-- Name: Services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Services" (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    icon character varying(255),
    image character varying(255),
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: Services_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Services_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Services_id_seq" OWNED BY public."Services".id;


--
-- Name: Settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Settings" (
    id integer NOT NULL,
    "siteName" character varying(255) DEFAULT 'Real Estate Platform'::character varying,
    "siteDescription" text DEFAULT 'Find your dream home with us.'::text,
    "contactEmail" character varying(255) DEFAULT 'contact@realestate.com'::character varying,
    "contactPhone" character varying(255) DEFAULT '+1 234 567 8900'::character varying,
    address text DEFAULT '123 Real Estate Blvd, City, Country'::text,
    facebook character varying(255) DEFAULT 'https://facebook.com'::character varying,
    twitter character varying(255) DEFAULT 'https://twitter.com'::character varying,
    instagram character varying(255) DEFAULT 'https://instagram.com'::character varying,
    linkedin character varying(255) DEFAULT 'https://linkedin.com'::character varying,
    "maintenanceMode" boolean DEFAULT false,
    "userRegistration" boolean DEFAULT true,
    "smtpHost" character varying(255) DEFAULT 'smtp.example.com'::character varying,
    "smtpPort" character varying(255) DEFAULT '587'::character varying,
    "smtpUser" character varying(255) DEFAULT 'apikey'::character varying,
    "smtpPassword" character varying(255) DEFAULT 'password123'::character varying,
    "googleAnalyticsId" character varying(255) DEFAULT 'G-XXXXXXX'::character varying,
    currency character varying(255) DEFAULT 'USD'::character varying,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    app_theme character varying(255) DEFAULT 'Default'::character varying
);


--
-- Name: Settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Settings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Settings_id_seq" OWNED BY public."Settings".id;


--
-- Name: Subscribers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Subscribers" (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    "isActive" boolean DEFAULT true,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: Subscribers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Subscribers_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Subscribers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Subscribers_id_seq" OWNED BY public."Subscribers".id;


--
-- Name: TeamMembers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TeamMembers" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    designation character varying(255),
    photo character varying(255),
    bio text,
    facebook character varying(255),
    twitter character varying(255),
    linkedin character varying(255),
    instagram character varying(255),
    "order" integer DEFAULT 0,
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: TeamMembers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."TeamMembers_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: TeamMembers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."TeamMembers_id_seq" OWNED BY public."TeamMembers".id;


--
-- Name: Testimonials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Testimonials" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    designation character varying(255),
    photo character varying(255),
    content text NOT NULL,
    rating integer DEFAULT 5,
    "isDeleted" boolean DEFAULT false,
    posted_by integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: Testimonials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Testimonials_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Testimonials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Testimonials_id_seq" OWNED BY public."Testimonials".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Users" (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role public."enum_Users_role" DEFAULT 'user'::public."enum_Users_role",
    "phoneNumber" character varying(255),
    "isBlocked" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isDeleted" boolean DEFAULT false,
    privileges jsonb
);


--
-- Name: COLUMN "Users".privileges; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public."Users".privileges IS 'List of management page permissions for admins';


--
-- Name: Users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."Users_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: Users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."Users_id_seq" OWNED BY public."Users".id;


--
-- Name: amenities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.amenities (
    id integer NOT NULL,
    type public.enum_amenities_type NOT NULL,
    title character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isDeleted" boolean DEFAULT false
);


--
-- Name: amenities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.amenities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: amenities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.amenities_id_seq OWNED BY public.amenities.id;


--
-- Name: articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.articles (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    category character varying(255) NOT NULL,
    date character varying(255) NOT NULL,
    image character varying(255) NOT NULL,
    excerpt text NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isDeleted" boolean DEFAULT false,
    posted_by integer
);


--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: hero_sliders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hero_sliders (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    price character varying(255) NOT NULL,
    "priceUnit" character varying(255),
    area character varying(255) NOT NULL,
    beds integer,
    baths integer,
    garage integer,
    image character varying(255) NOT NULL,
    link character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isDeleted" boolean DEFAULT false
);


--
-- Name: hero_sliders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hero_sliders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hero_sliders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hero_sliders_id_seq OWNED BY public.hero_sliders.id;


--
-- Name: interior_articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interior_articles (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255),
    category character varying(255) DEFAULT 'Interiors & Decor'::character varying NOT NULL,
    image character varying(255),
    excerpt text,
    content text,
    author character varying(255) DEFAULT 'Editorial Team'::character varying,
    "readTime" character varying(255) DEFAULT '5 min read'::character varying,
    "publishedAt" timestamp with time zone,
    "isDeleted" boolean DEFAULT false,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: interior_articles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.interior_articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: interior_articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.interior_articles_id_seq OWNED BY public.interior_articles.id;


--
-- Name: interior_designers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.interior_designers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    logo character varying(255),
    "coverImage" character varying(255),
    city character varying(255) NOT NULL,
    specializations character varying(255)[] DEFAULT (ARRAY[]::character varying[])::character varying(255)[],
    rating double precision DEFAULT '4'::double precision,
    "reviewCount" integer DEFAULT 0,
    "yearsExperience" integer DEFAULT 1,
    "projectsCompleted" integer DEFAULT 0,
    "minBudget" bigint,
    "maxBudget" bigint,
    description text,
    address character varying(255),
    phone character varying(255),
    email character varying(255),
    website character varying(255),
    "isFeatured" boolean DEFAULT false,
    "isVerified" boolean DEFAULT false,
    "isDeleted" boolean DEFAULT false,
    tags character varying(255)[] DEFAULT (ARRAY[]::character varying[])::character varying(255)[],
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: interior_designers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.interior_designers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: interior_designers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.interior_designers_id_seq OWNED BY public.interior_designers.id;


--
-- Name: jantri_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jantri_rates (
    id integer NOT NULL,
    district character varying(200),
    area character varying(200),
    zone_code character varying(100),
    land_rate numeric,
    residential_rate numeric,
    commercial_rate numeric,
    office_rate numeric,
    industrial_rate numeric,
    page_no integer
);


--
-- Name: jantri_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.jantri_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jantri_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.jantri_rates_id_seq OWNED BY public.jantri_rates.id;


--
-- Name: locality_reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locality_reviews (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "localityId" integer NOT NULL,
    rating double precision NOT NULL,
    comment text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: locality_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.locality_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: locality_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.locality_reviews_id_seq OWNED BY public.locality_reviews.id;


--
-- Name: properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.properties (
    id integer NOT NULL,
    "typeId" integer NOT NULL,
    city character varying(255) NOT NULL,
    state character varying(255) NOT NULL,
    country character varying(255) DEFAULT 'India'::character varying NOT NULL,
    latitude numeric(10,8),
    longitude numeric(11,8),
    title character varying(255) NOT NULL,
    status public.enum_properties_status NOT NULL,
    price numeric(15,2) NOT NULL,
    area numeric(10,2) NOT NULL,
    no_of_bedrooms integer,
    no_of_bathrooms integer,
    posted_by integer NOT NULL,
    featured boolean DEFAULT false,
    no_of_garage integer DEFAULT 0,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isDeleted" boolean DEFAULT false,
    description text,
    verified boolean DEFAULT false,
    furnishing_type character varying(255) DEFAULT 'none'::character varying,
    bachelor_friendly boolean DEFAULT false,
    availability character varying(255) DEFAULT 'Immediate'::character varying,
    family_friendly boolean DEFAULT false,
    live_in_friendly boolean DEFAULT false,
    locality_id integer,
    project_id integer,
    floor integer DEFAULT 0
);


--
-- Name: COLUMN properties.area; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.properties.area IS 'Area in sqft';


--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: property_amenities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.property_amenities (
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "amenityId" integer NOT NULL,
    "propertyId" integer NOT NULL
);


--
-- Name: property_faqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.property_faqs (
    id integer NOT NULL,
    "propertyId" integer NOT NULL,
    question character varying(255) NOT NULL,
    answer text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isDeleted" boolean DEFAULT false
);


--
-- Name: property_faqs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.property_faqs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: property_faqs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.property_faqs_id_seq OWNED BY public.property_faqs.id;


--
-- Name: property_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.property_images (
    id integer NOT NULL,
    "propertyId" integer NOT NULL,
    "imageUrl" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isDeleted" boolean DEFAULT false
);


--
-- Name: property_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.property_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: property_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.property_images_id_seq OWNED BY public.property_images.id;


--
-- Name: property_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.property_types (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "isDeleted" boolean DEFAULT false
);


--
-- Name: property_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.property_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: property_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.property_types_id_seq OWNED BY public.property_types.id;


--
-- Name: reviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reviews (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "propertyId" integer NOT NULL,
    rating integer NOT NULL,
    comment text NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reviews_id_seq OWNED BY public.reviews.id;


--
-- Name: shortlists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shortlists (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "propertyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: shortlists_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.shortlists_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shortlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.shortlists_id_seq OWNED BY public.shortlists.id;


--
-- Name: viewed_properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.viewed_properties (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "propertyId" integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


--
-- Name: viewed_properties_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.viewed_properties_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: viewed_properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.viewed_properties_id_seq OWNED BY public.viewed_properties.id;


--
-- Name: Amenities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Amenities" ALTER COLUMN id SET DEFAULT nextval('public."Amenities_id_seq"'::regclass);


--
-- Name: Brands id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Brands" ALTER COLUMN id SET DEFAULT nextval('public."Brands_id_seq"'::regclass);


--
-- Name: Brokers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Brokers" ALTER COLUMN id SET DEFAULT nextval('public."Brokers_id_seq"'::regclass);


--
-- Name: Builders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders" ALTER COLUMN id SET DEFAULT nextval('public."Builders_id_seq"'::regclass);


--
-- Name: ChatConversations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatConversations" ALTER COLUMN id SET DEFAULT nextval('public."ChatConversations_id_seq"'::regclass);


--
-- Name: ChatMessages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatMessages" ALTER COLUMN id SET DEFAULT nextval('public."ChatMessages_id_seq"'::regclass);


--
-- Name: Cities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities" ALTER COLUMN id SET DEFAULT nextval('public."Cities_id_seq"'::regclass);


--
-- Name: EmailTemplates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailTemplates" ALTER COLUMN id SET DEFAULT nextval('public."EmailTemplates_id_seq"'::regclass);


--
-- Name: FunFacts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FunFacts" ALTER COLUMN id SET DEFAULT nextval('public."FunFacts_id_seq"'::regclass);


--
-- Name: HomeComponents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents" ALTER COLUMN id SET DEFAULT nextval('public."HomeComponents_id_seq"'::regclass);


--
-- Name: InstaReels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InstaReels" ALTER COLUMN id SET DEFAULT nextval('public."InstaReels_id_seq"'::regclass);


--
-- Name: Localities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Localities" ALTER COLUMN id SET DEFAULT nextval('public."Localities_id_seq"'::regclass);


--
-- Name: MenuItems id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MenuItems" ALTER COLUMN id SET DEFAULT nextval('public."MenuItems_id_seq"'::regclass);


--
-- Name: Projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Projects" ALTER COLUMN id SET DEFAULT nextval('public."Projects_id_seq"'::regclass);


--
-- Name: Properties id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Properties" ALTER COLUMN id SET DEFAULT nextval('public."Properties_id_seq"'::regclass);


--
-- Name: PropertyImages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropertyImages" ALTER COLUMN id SET DEFAULT nextval('public."PropertyImages_id_seq"'::regclass);


--
-- Name: PropertyTypes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropertyTypes" ALTER COLUMN id SET DEFAULT nextval('public."PropertyTypes_id_seq"'::regclass);


--
-- Name: Services id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Services" ALTER COLUMN id SET DEFAULT nextval('public."Services_id_seq"'::regclass);


--
-- Name: Settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Settings" ALTER COLUMN id SET DEFAULT nextval('public."Settings_id_seq"'::regclass);


--
-- Name: Subscribers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers" ALTER COLUMN id SET DEFAULT nextval('public."Subscribers_id_seq"'::regclass);


--
-- Name: TeamMembers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TeamMembers" ALTER COLUMN id SET DEFAULT nextval('public."TeamMembers_id_seq"'::regclass);


--
-- Name: Testimonials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Testimonials" ALTER COLUMN id SET DEFAULT nextval('public."Testimonials_id_seq"'::regclass);


--
-- Name: Users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users" ALTER COLUMN id SET DEFAULT nextval('public."Users_id_seq"'::regclass);


--
-- Name: amenities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities ALTER COLUMN id SET DEFAULT nextval('public.amenities_id_seq'::regclass);


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: hero_sliders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_sliders ALTER COLUMN id SET DEFAULT nextval('public.hero_sliders_id_seq'::regclass);


--
-- Name: interior_articles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interior_articles ALTER COLUMN id SET DEFAULT nextval('public.interior_articles_id_seq'::regclass);


--
-- Name: interior_designers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interior_designers ALTER COLUMN id SET DEFAULT nextval('public.interior_designers_id_seq'::regclass);


--
-- Name: jantri_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jantri_rates ALTER COLUMN id SET DEFAULT nextval('public.jantri_rates_id_seq'::regclass);


--
-- Name: locality_reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locality_reviews ALTER COLUMN id SET DEFAULT nextval('public.locality_reviews_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: property_faqs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_faqs ALTER COLUMN id SET DEFAULT nextval('public.property_faqs_id_seq'::regclass);


--
-- Name: property_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_images ALTER COLUMN id SET DEFAULT nextval('public.property_images_id_seq'::regclass);


--
-- Name: property_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types ALTER COLUMN id SET DEFAULT nextval('public.property_types_id_seq'::regclass);


--
-- Name: reviews id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews ALTER COLUMN id SET DEFAULT nextval('public.reviews_id_seq'::regclass);


--
-- Name: shortlists id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shortlists ALTER COLUMN id SET DEFAULT nextval('public.shortlists_id_seq'::regclass);


--
-- Name: viewed_properties id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.viewed_properties ALTER COLUMN id SET DEFAULT nextval('public.viewed_properties_id_seq'::regclass);


--
-- Data for Name: Amenities; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11857.dat

--
-- Data for Name: Brands; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11882.dat

--
-- Data for Name: Brokers; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11872.dat

--
-- Data for Name: Builders; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11902.dat

--
-- Data for Name: ChatConversations; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11918.dat

--
-- Data for Name: ChatMessages; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11920.dat

--
-- Data for Name: Cities; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11884.dat

--
-- Data for Name: EmailTemplates; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11888.dat

--
-- Data for Name: FunFacts; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11876.dat

--
-- Data for Name: HomeComponents; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11870.dat

--
-- Data for Name: InstaReels; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11878.dat

--
-- Data for Name: Localities; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11904.dat

--
-- Data for Name: MenuItems; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11906.dat

--
-- Data for Name: Projects; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11908.dat

--
-- Data for Name: Properties; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11850.dat

--
-- Data for Name: PropertyImages; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11862.dat

--
-- Data for Name: PropertyTypes; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11848.dat

--
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11855.dat

--
-- Data for Name: Services; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11874.dat

--
-- Data for Name: Settings; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11892.dat

--
-- Data for Name: Subscribers; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11890.dat

--
-- Data for Name: TeamMembers; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11900.dat

--
-- Data for Name: Testimonials; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11880.dat

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11846.dat

--
-- Data for Name: amenities; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11859.dat

--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11866.dat

--
-- Data for Name: hero_sliders; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11868.dat

--
-- Data for Name: interior_articles; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11914.dat

--
-- Data for Name: interior_designers; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11916.dat

--
-- Data for Name: jantri_rates; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11910.dat

--
-- Data for Name: locality_reviews; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11912.dat

--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11854.dat

--
-- Data for Name: property_amenities; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11860.dat

--
-- Data for Name: property_faqs; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11898.dat

--
-- Data for Name: property_images; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11864.dat

--
-- Data for Name: property_types; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11852.dat

--
-- Data for Name: reviews; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11896.dat

--
-- Data for Name: shortlists; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11886.dat

--
-- Data for Name: viewed_properties; Type: TABLE DATA; Schema: public; Owner: -
--

\i $$PATH$$/11894.dat

--
-- Name: Amenities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Amenities_id_seq"', 1, false);


--
-- Name: Brands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Brands_id_seq"', 54, true);


--
-- Name: Brokers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Brokers_id_seq"', 48, true);


--
-- Name: Builders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Builders_id_seq"', 23, true);


--
-- Name: ChatConversations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ChatConversations_id_seq"', 1, false);


--
-- Name: ChatMessages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."ChatMessages_id_seq"', 1, false);


--
-- Name: Cities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Cities_id_seq"', 44, true);


--
-- Name: EmailTemplates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."EmailTemplates_id_seq"', 3, true);


--
-- Name: FunFacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."FunFacts_id_seq"', 49, true);


--
-- Name: HomeComponents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."HomeComponents_id_seq"', 16, true);


--
-- Name: InstaReels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."InstaReels_id_seq"', 30, true);


--
-- Name: Localities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Localities_id_seq"', 99, true);


--
-- Name: MenuItems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."MenuItems_id_seq"', 116, true);


--
-- Name: Projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Projects_id_seq"', 98, true);


--
-- Name: Properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Properties_id_seq"', 1, false);


--
-- Name: PropertyImages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."PropertyImages_id_seq"', 1, false);


--
-- Name: PropertyTypes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."PropertyTypes_id_seq"', 1, false);


--
-- Name: Services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Services_id_seq"', 50, true);


--
-- Name: Settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Settings_id_seq"', 1, true);


--
-- Name: Subscribers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Subscribers_id_seq"', 4, true);


--
-- Name: TeamMembers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."TeamMembers_id_seq"', 4, true);


--
-- Name: Testimonials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Testimonials_id_seq"', 28, true);


--
-- Name: Users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."Users_id_seq"', 5, true);


--
-- Name: amenities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.amenities_id_seq', 69, true);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.articles_id_seq', 44, true);


--
-- Name: hero_sliders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hero_sliders_id_seq', 24, true);


--
-- Name: interior_articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.interior_articles_id_seq', 37, true);


--
-- Name: interior_designers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.interior_designers_id_seq', 47, true);


--
-- Name: jantri_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.jantri_rates_id_seq', 4013, true);


--
-- Name: locality_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.locality_reviews_id_seq', 34, true);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.properties_id_seq', 221, true);


--
-- Name: property_faqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.property_faqs_id_seq', 3, true);


--
-- Name: property_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.property_images_id_seq', 1332, true);


--
-- Name: property_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.property_types_id_seq', 22, true);


--
-- Name: reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reviews_id_seq', 2, true);


--
-- Name: shortlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.shortlists_id_seq', 6, true);


--
-- Name: viewed_properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.viewed_properties_id_seq', 3, true);


--
-- Name: Amenities Amenities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Amenities"
    ADD CONSTRAINT "Amenities_pkey" PRIMARY KEY (id);


--
-- Name: Brands Brands_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Brands"
    ADD CONSTRAINT "Brands_pkey" PRIMARY KEY (id);


--
-- Name: Brokers Brokers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Brokers"
    ADD CONSTRAINT "Brokers_pkey" PRIMARY KEY (id);


--
-- Name: Builders Builders_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key" UNIQUE (email);


--
-- Name: Builders Builders_email_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key1" UNIQUE (email);


--
-- Name: Builders Builders_email_key10; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key10" UNIQUE (email);


--
-- Name: Builders Builders_email_key100; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key100" UNIQUE (email);


--
-- Name: Builders Builders_email_key101; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key101" UNIQUE (email);


--
-- Name: Builders Builders_email_key102; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key102" UNIQUE (email);


--
-- Name: Builders Builders_email_key103; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key103" UNIQUE (email);


--
-- Name: Builders Builders_email_key104; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key104" UNIQUE (email);


--
-- Name: Builders Builders_email_key105; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key105" UNIQUE (email);


--
-- Name: Builders Builders_email_key106; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key106" UNIQUE (email);


--
-- Name: Builders Builders_email_key107; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key107" UNIQUE (email);


--
-- Name: Builders Builders_email_key108; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key108" UNIQUE (email);


--
-- Name: Builders Builders_email_key109; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key109" UNIQUE (email);


--
-- Name: Builders Builders_email_key11; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key11" UNIQUE (email);


--
-- Name: Builders Builders_email_key110; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key110" UNIQUE (email);


--
-- Name: Builders Builders_email_key111; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key111" UNIQUE (email);


--
-- Name: Builders Builders_email_key112; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key112" UNIQUE (email);


--
-- Name: Builders Builders_email_key113; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key113" UNIQUE (email);


--
-- Name: Builders Builders_email_key114; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key114" UNIQUE (email);


--
-- Name: Builders Builders_email_key115; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key115" UNIQUE (email);


--
-- Name: Builders Builders_email_key116; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key116" UNIQUE (email);


--
-- Name: Builders Builders_email_key117; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key117" UNIQUE (email);


--
-- Name: Builders Builders_email_key118; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key118" UNIQUE (email);


--
-- Name: Builders Builders_email_key119; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key119" UNIQUE (email);


--
-- Name: Builders Builders_email_key12; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key12" UNIQUE (email);


--
-- Name: Builders Builders_email_key120; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key120" UNIQUE (email);


--
-- Name: Builders Builders_email_key121; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key121" UNIQUE (email);


--
-- Name: Builders Builders_email_key122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key122" UNIQUE (email);


--
-- Name: Builders Builders_email_key123; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key123" UNIQUE (email);


--
-- Name: Builders Builders_email_key124; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key124" UNIQUE (email);


--
-- Name: Builders Builders_email_key125; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key125" UNIQUE (email);


--
-- Name: Builders Builders_email_key126; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key126" UNIQUE (email);


--
-- Name: Builders Builders_email_key127; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key127" UNIQUE (email);


--
-- Name: Builders Builders_email_key128; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key128" UNIQUE (email);


--
-- Name: Builders Builders_email_key129; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key129" UNIQUE (email);


--
-- Name: Builders Builders_email_key13; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key13" UNIQUE (email);


--
-- Name: Builders Builders_email_key130; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key130" UNIQUE (email);


--
-- Name: Builders Builders_email_key131; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key131" UNIQUE (email);


--
-- Name: Builders Builders_email_key132; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key132" UNIQUE (email);


--
-- Name: Builders Builders_email_key133; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key133" UNIQUE (email);


--
-- Name: Builders Builders_email_key134; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key134" UNIQUE (email);


--
-- Name: Builders Builders_email_key135; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key135" UNIQUE (email);


--
-- Name: Builders Builders_email_key136; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key136" UNIQUE (email);


--
-- Name: Builders Builders_email_key137; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key137" UNIQUE (email);


--
-- Name: Builders Builders_email_key138; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key138" UNIQUE (email);


--
-- Name: Builders Builders_email_key139; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key139" UNIQUE (email);


--
-- Name: Builders Builders_email_key14; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key14" UNIQUE (email);


--
-- Name: Builders Builders_email_key140; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key140" UNIQUE (email);


--
-- Name: Builders Builders_email_key141; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key141" UNIQUE (email);


--
-- Name: Builders Builders_email_key142; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key142" UNIQUE (email);


--
-- Name: Builders Builders_email_key143; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key143" UNIQUE (email);


--
-- Name: Builders Builders_email_key144; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key144" UNIQUE (email);


--
-- Name: Builders Builders_email_key145; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key145" UNIQUE (email);


--
-- Name: Builders Builders_email_key146; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key146" UNIQUE (email);


--
-- Name: Builders Builders_email_key147; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key147" UNIQUE (email);


--
-- Name: Builders Builders_email_key148; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key148" UNIQUE (email);


--
-- Name: Builders Builders_email_key149; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key149" UNIQUE (email);


--
-- Name: Builders Builders_email_key15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key15" UNIQUE (email);


--
-- Name: Builders Builders_email_key150; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key150" UNIQUE (email);


--
-- Name: Builders Builders_email_key151; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key151" UNIQUE (email);


--
-- Name: Builders Builders_email_key152; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key152" UNIQUE (email);


--
-- Name: Builders Builders_email_key153; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key153" UNIQUE (email);


--
-- Name: Builders Builders_email_key154; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key154" UNIQUE (email);


--
-- Name: Builders Builders_email_key155; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key155" UNIQUE (email);


--
-- Name: Builders Builders_email_key156; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key156" UNIQUE (email);


--
-- Name: Builders Builders_email_key157; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key157" UNIQUE (email);


--
-- Name: Builders Builders_email_key158; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key158" UNIQUE (email);


--
-- Name: Builders Builders_email_key159; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key159" UNIQUE (email);


--
-- Name: Builders Builders_email_key16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key16" UNIQUE (email);


--
-- Name: Builders Builders_email_key160; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key160" UNIQUE (email);


--
-- Name: Builders Builders_email_key161; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key161" UNIQUE (email);


--
-- Name: Builders Builders_email_key162; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key162" UNIQUE (email);


--
-- Name: Builders Builders_email_key163; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key163" UNIQUE (email);


--
-- Name: Builders Builders_email_key164; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key164" UNIQUE (email);


--
-- Name: Builders Builders_email_key165; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key165" UNIQUE (email);


--
-- Name: Builders Builders_email_key166; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key166" UNIQUE (email);


--
-- Name: Builders Builders_email_key167; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key167" UNIQUE (email);


--
-- Name: Builders Builders_email_key168; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key168" UNIQUE (email);


--
-- Name: Builders Builders_email_key169; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key169" UNIQUE (email);


--
-- Name: Builders Builders_email_key17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key17" UNIQUE (email);


--
-- Name: Builders Builders_email_key170; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key170" UNIQUE (email);


--
-- Name: Builders Builders_email_key171; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key171" UNIQUE (email);


--
-- Name: Builders Builders_email_key172; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key172" UNIQUE (email);


--
-- Name: Builders Builders_email_key173; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key173" UNIQUE (email);


--
-- Name: Builders Builders_email_key174; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key174" UNIQUE (email);


--
-- Name: Builders Builders_email_key175; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key175" UNIQUE (email);


--
-- Name: Builders Builders_email_key176; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key176" UNIQUE (email);


--
-- Name: Builders Builders_email_key177; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key177" UNIQUE (email);


--
-- Name: Builders Builders_email_key178; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key178" UNIQUE (email);


--
-- Name: Builders Builders_email_key179; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key179" UNIQUE (email);


--
-- Name: Builders Builders_email_key18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key18" UNIQUE (email);


--
-- Name: Builders Builders_email_key180; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key180" UNIQUE (email);


--
-- Name: Builders Builders_email_key181; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key181" UNIQUE (email);


--
-- Name: Builders Builders_email_key182; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key182" UNIQUE (email);


--
-- Name: Builders Builders_email_key183; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key183" UNIQUE (email);


--
-- Name: Builders Builders_email_key184; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key184" UNIQUE (email);


--
-- Name: Builders Builders_email_key185; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key185" UNIQUE (email);


--
-- Name: Builders Builders_email_key186; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key186" UNIQUE (email);


--
-- Name: Builders Builders_email_key187; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key187" UNIQUE (email);


--
-- Name: Builders Builders_email_key188; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key188" UNIQUE (email);


--
-- Name: Builders Builders_email_key189; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key189" UNIQUE (email);


--
-- Name: Builders Builders_email_key19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key19" UNIQUE (email);


--
-- Name: Builders Builders_email_key190; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key190" UNIQUE (email);


--
-- Name: Builders Builders_email_key191; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key191" UNIQUE (email);


--
-- Name: Builders Builders_email_key192; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key192" UNIQUE (email);


--
-- Name: Builders Builders_email_key193; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key193" UNIQUE (email);


--
-- Name: Builders Builders_email_key194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key194" UNIQUE (email);


--
-- Name: Builders Builders_email_key195; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key195" UNIQUE (email);


--
-- Name: Builders Builders_email_key196; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key196" UNIQUE (email);


--
-- Name: Builders Builders_email_key197; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key197" UNIQUE (email);


--
-- Name: Builders Builders_email_key198; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key198" UNIQUE (email);


--
-- Name: Builders Builders_email_key199; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key199" UNIQUE (email);


--
-- Name: Builders Builders_email_key2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key2" UNIQUE (email);


--
-- Name: Builders Builders_email_key20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key20" UNIQUE (email);


--
-- Name: Builders Builders_email_key200; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key200" UNIQUE (email);


--
-- Name: Builders Builders_email_key201; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key201" UNIQUE (email);


--
-- Name: Builders Builders_email_key202; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key202" UNIQUE (email);


--
-- Name: Builders Builders_email_key203; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key203" UNIQUE (email);


--
-- Name: Builders Builders_email_key204; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key204" UNIQUE (email);


--
-- Name: Builders Builders_email_key205; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key205" UNIQUE (email);


--
-- Name: Builders Builders_email_key206; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key206" UNIQUE (email);


--
-- Name: Builders Builders_email_key207; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key207" UNIQUE (email);


--
-- Name: Builders Builders_email_key208; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key208" UNIQUE (email);


--
-- Name: Builders Builders_email_key209; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key209" UNIQUE (email);


--
-- Name: Builders Builders_email_key21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key21" UNIQUE (email);


--
-- Name: Builders Builders_email_key210; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key210" UNIQUE (email);


--
-- Name: Builders Builders_email_key211; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key211" UNIQUE (email);


--
-- Name: Builders Builders_email_key212; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key212" UNIQUE (email);


--
-- Name: Builders Builders_email_key213; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key213" UNIQUE (email);


--
-- Name: Builders Builders_email_key214; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key214" UNIQUE (email);


--
-- Name: Builders Builders_email_key215; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key215" UNIQUE (email);


--
-- Name: Builders Builders_email_key216; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key216" UNIQUE (email);


--
-- Name: Builders Builders_email_key217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key217" UNIQUE (email);


--
-- Name: Builders Builders_email_key218; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key218" UNIQUE (email);


--
-- Name: Builders Builders_email_key219; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key219" UNIQUE (email);


--
-- Name: Builders Builders_email_key22; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key22" UNIQUE (email);


--
-- Name: Builders Builders_email_key220; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key220" UNIQUE (email);


--
-- Name: Builders Builders_email_key221; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key221" UNIQUE (email);


--
-- Name: Builders Builders_email_key222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key222" UNIQUE (email);


--
-- Name: Builders Builders_email_key223; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key223" UNIQUE (email);


--
-- Name: Builders Builders_email_key224; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key224" UNIQUE (email);


--
-- Name: Builders Builders_email_key225; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key225" UNIQUE (email);


--
-- Name: Builders Builders_email_key226; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key226" UNIQUE (email);


--
-- Name: Builders Builders_email_key227; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key227" UNIQUE (email);


--
-- Name: Builders Builders_email_key228; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key228" UNIQUE (email);


--
-- Name: Builders Builders_email_key229; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key229" UNIQUE (email);


--
-- Name: Builders Builders_email_key23; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key23" UNIQUE (email);


--
-- Name: Builders Builders_email_key230; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key230" UNIQUE (email);


--
-- Name: Builders Builders_email_key231; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key231" UNIQUE (email);


--
-- Name: Builders Builders_email_key232; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key232" UNIQUE (email);


--
-- Name: Builders Builders_email_key233; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key233" UNIQUE (email);


--
-- Name: Builders Builders_email_key234; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key234" UNIQUE (email);


--
-- Name: Builders Builders_email_key235; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key235" UNIQUE (email);


--
-- Name: Builders Builders_email_key236; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key236" UNIQUE (email);


--
-- Name: Builders Builders_email_key237; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key237" UNIQUE (email);


--
-- Name: Builders Builders_email_key238; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key238" UNIQUE (email);


--
-- Name: Builders Builders_email_key239; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key239" UNIQUE (email);


--
-- Name: Builders Builders_email_key24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key24" UNIQUE (email);


--
-- Name: Builders Builders_email_key240; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key240" UNIQUE (email);


--
-- Name: Builders Builders_email_key241; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key241" UNIQUE (email);


--
-- Name: Builders Builders_email_key242; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key242" UNIQUE (email);


--
-- Name: Builders Builders_email_key243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key243" UNIQUE (email);


--
-- Name: Builders Builders_email_key244; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key244" UNIQUE (email);


--
-- Name: Builders Builders_email_key245; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key245" UNIQUE (email);


--
-- Name: Builders Builders_email_key246; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key246" UNIQUE (email);


--
-- Name: Builders Builders_email_key247; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key247" UNIQUE (email);


--
-- Name: Builders Builders_email_key248; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key248" UNIQUE (email);


--
-- Name: Builders Builders_email_key249; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key249" UNIQUE (email);


--
-- Name: Builders Builders_email_key25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key25" UNIQUE (email);


--
-- Name: Builders Builders_email_key250; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key250" UNIQUE (email);


--
-- Name: Builders Builders_email_key251; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key251" UNIQUE (email);


--
-- Name: Builders Builders_email_key252; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key252" UNIQUE (email);


--
-- Name: Builders Builders_email_key253; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key253" UNIQUE (email);


--
-- Name: Builders Builders_email_key254; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key254" UNIQUE (email);


--
-- Name: Builders Builders_email_key255; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key255" UNIQUE (email);


--
-- Name: Builders Builders_email_key256; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key256" UNIQUE (email);


--
-- Name: Builders Builders_email_key26; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key26" UNIQUE (email);


--
-- Name: Builders Builders_email_key27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key27" UNIQUE (email);


--
-- Name: Builders Builders_email_key28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key28" UNIQUE (email);


--
-- Name: Builders Builders_email_key29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key29" UNIQUE (email);


--
-- Name: Builders Builders_email_key3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key3" UNIQUE (email);


--
-- Name: Builders Builders_email_key30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key30" UNIQUE (email);


--
-- Name: Builders Builders_email_key31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key31" UNIQUE (email);


--
-- Name: Builders Builders_email_key32; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key32" UNIQUE (email);


--
-- Name: Builders Builders_email_key33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key33" UNIQUE (email);


--
-- Name: Builders Builders_email_key34; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key34" UNIQUE (email);


--
-- Name: Builders Builders_email_key35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key35" UNIQUE (email);


--
-- Name: Builders Builders_email_key36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key36" UNIQUE (email);


--
-- Name: Builders Builders_email_key37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key37" UNIQUE (email);


--
-- Name: Builders Builders_email_key38; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key38" UNIQUE (email);


--
-- Name: Builders Builders_email_key39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key39" UNIQUE (email);


--
-- Name: Builders Builders_email_key4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key4" UNIQUE (email);


--
-- Name: Builders Builders_email_key40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key40" UNIQUE (email);


--
-- Name: Builders Builders_email_key41; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key41" UNIQUE (email);


--
-- Name: Builders Builders_email_key42; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key42" UNIQUE (email);


--
-- Name: Builders Builders_email_key43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key43" UNIQUE (email);


--
-- Name: Builders Builders_email_key44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key44" UNIQUE (email);


--
-- Name: Builders Builders_email_key45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key45" UNIQUE (email);


--
-- Name: Builders Builders_email_key46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key46" UNIQUE (email);


--
-- Name: Builders Builders_email_key47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key47" UNIQUE (email);


--
-- Name: Builders Builders_email_key48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key48" UNIQUE (email);


--
-- Name: Builders Builders_email_key49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key49" UNIQUE (email);


--
-- Name: Builders Builders_email_key5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key5" UNIQUE (email);


--
-- Name: Builders Builders_email_key50; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key50" UNIQUE (email);


--
-- Name: Builders Builders_email_key51; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key51" UNIQUE (email);


--
-- Name: Builders Builders_email_key52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key52" UNIQUE (email);


--
-- Name: Builders Builders_email_key53; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key53" UNIQUE (email);


--
-- Name: Builders Builders_email_key54; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key54" UNIQUE (email);


--
-- Name: Builders Builders_email_key55; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key55" UNIQUE (email);


--
-- Name: Builders Builders_email_key56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key56" UNIQUE (email);


--
-- Name: Builders Builders_email_key57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key57" UNIQUE (email);


--
-- Name: Builders Builders_email_key58; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key58" UNIQUE (email);


--
-- Name: Builders Builders_email_key59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key59" UNIQUE (email);


--
-- Name: Builders Builders_email_key6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key6" UNIQUE (email);


--
-- Name: Builders Builders_email_key60; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key60" UNIQUE (email);


--
-- Name: Builders Builders_email_key61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key61" UNIQUE (email);


--
-- Name: Builders Builders_email_key62; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key62" UNIQUE (email);


--
-- Name: Builders Builders_email_key63; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key63" UNIQUE (email);


--
-- Name: Builders Builders_email_key64; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key64" UNIQUE (email);


--
-- Name: Builders Builders_email_key65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key65" UNIQUE (email);


--
-- Name: Builders Builders_email_key66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key66" UNIQUE (email);


--
-- Name: Builders Builders_email_key67; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key67" UNIQUE (email);


--
-- Name: Builders Builders_email_key68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key68" UNIQUE (email);


--
-- Name: Builders Builders_email_key69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key69" UNIQUE (email);


--
-- Name: Builders Builders_email_key7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key7" UNIQUE (email);


--
-- Name: Builders Builders_email_key70; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key70" UNIQUE (email);


--
-- Name: Builders Builders_email_key71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key71" UNIQUE (email);


--
-- Name: Builders Builders_email_key72; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key72" UNIQUE (email);


--
-- Name: Builders Builders_email_key73; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key73" UNIQUE (email);


--
-- Name: Builders Builders_email_key74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key74" UNIQUE (email);


--
-- Name: Builders Builders_email_key75; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key75" UNIQUE (email);


--
-- Name: Builders Builders_email_key76; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key76" UNIQUE (email);


--
-- Name: Builders Builders_email_key77; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key77" UNIQUE (email);


--
-- Name: Builders Builders_email_key78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key78" UNIQUE (email);


--
-- Name: Builders Builders_email_key79; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key79" UNIQUE (email);


--
-- Name: Builders Builders_email_key8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key8" UNIQUE (email);


--
-- Name: Builders Builders_email_key80; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key80" UNIQUE (email);


--
-- Name: Builders Builders_email_key81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key81" UNIQUE (email);


--
-- Name: Builders Builders_email_key82; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key82" UNIQUE (email);


--
-- Name: Builders Builders_email_key83; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key83" UNIQUE (email);


--
-- Name: Builders Builders_email_key84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key84" UNIQUE (email);


--
-- Name: Builders Builders_email_key85; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key85" UNIQUE (email);


--
-- Name: Builders Builders_email_key86; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key86" UNIQUE (email);


--
-- Name: Builders Builders_email_key87; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key87" UNIQUE (email);


--
-- Name: Builders Builders_email_key88; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key88" UNIQUE (email);


--
-- Name: Builders Builders_email_key89; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key89" UNIQUE (email);


--
-- Name: Builders Builders_email_key9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key9" UNIQUE (email);


--
-- Name: Builders Builders_email_key90; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key90" UNIQUE (email);


--
-- Name: Builders Builders_email_key91; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key91" UNIQUE (email);


--
-- Name: Builders Builders_email_key92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key92" UNIQUE (email);


--
-- Name: Builders Builders_email_key93; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key93" UNIQUE (email);


--
-- Name: Builders Builders_email_key94; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key94" UNIQUE (email);


--
-- Name: Builders Builders_email_key95; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key95" UNIQUE (email);


--
-- Name: Builders Builders_email_key96; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key96" UNIQUE (email);


--
-- Name: Builders Builders_email_key97; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key97" UNIQUE (email);


--
-- Name: Builders Builders_email_key98; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key98" UNIQUE (email);


--
-- Name: Builders Builders_email_key99; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_email_key99" UNIQUE (email);


--
-- Name: Builders Builders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Builders"
    ADD CONSTRAINT "Builders_pkey" PRIMARY KEY (id);


--
-- Name: ChatConversations ChatConversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatConversations"
    ADD CONSTRAINT "ChatConversations_pkey" PRIMARY KEY (id);


--
-- Name: ChatMessages ChatMessages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_pkey" PRIMARY KEY (id);


--
-- Name: Cities Cities_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key" UNIQUE (name);


--
-- Name: Cities Cities_name_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key1" UNIQUE (name);


--
-- Name: Cities Cities_name_key10; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key10" UNIQUE (name);


--
-- Name: Cities Cities_name_key100; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key100" UNIQUE (name);


--
-- Name: Cities Cities_name_key101; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key101" UNIQUE (name);


--
-- Name: Cities Cities_name_key102; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key102" UNIQUE (name);


--
-- Name: Cities Cities_name_key103; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key103" UNIQUE (name);


--
-- Name: Cities Cities_name_key104; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key104" UNIQUE (name);


--
-- Name: Cities Cities_name_key105; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key105" UNIQUE (name);


--
-- Name: Cities Cities_name_key106; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key106" UNIQUE (name);


--
-- Name: Cities Cities_name_key107; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key107" UNIQUE (name);


--
-- Name: Cities Cities_name_key108; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key108" UNIQUE (name);


--
-- Name: Cities Cities_name_key109; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key109" UNIQUE (name);


--
-- Name: Cities Cities_name_key11; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key11" UNIQUE (name);


--
-- Name: Cities Cities_name_key110; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key110" UNIQUE (name);


--
-- Name: Cities Cities_name_key111; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key111" UNIQUE (name);


--
-- Name: Cities Cities_name_key112; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key112" UNIQUE (name);


--
-- Name: Cities Cities_name_key113; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key113" UNIQUE (name);


--
-- Name: Cities Cities_name_key114; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key114" UNIQUE (name);


--
-- Name: Cities Cities_name_key115; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key115" UNIQUE (name);


--
-- Name: Cities Cities_name_key116; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key116" UNIQUE (name);


--
-- Name: Cities Cities_name_key117; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key117" UNIQUE (name);


--
-- Name: Cities Cities_name_key118; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key118" UNIQUE (name);


--
-- Name: Cities Cities_name_key119; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key119" UNIQUE (name);


--
-- Name: Cities Cities_name_key12; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key12" UNIQUE (name);


--
-- Name: Cities Cities_name_key120; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key120" UNIQUE (name);


--
-- Name: Cities Cities_name_key121; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key121" UNIQUE (name);


--
-- Name: Cities Cities_name_key122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key122" UNIQUE (name);


--
-- Name: Cities Cities_name_key123; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key123" UNIQUE (name);


--
-- Name: Cities Cities_name_key124; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key124" UNIQUE (name);


--
-- Name: Cities Cities_name_key125; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key125" UNIQUE (name);


--
-- Name: Cities Cities_name_key126; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key126" UNIQUE (name);


--
-- Name: Cities Cities_name_key127; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key127" UNIQUE (name);


--
-- Name: Cities Cities_name_key128; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key128" UNIQUE (name);


--
-- Name: Cities Cities_name_key129; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key129" UNIQUE (name);


--
-- Name: Cities Cities_name_key13; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key13" UNIQUE (name);


--
-- Name: Cities Cities_name_key130; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key130" UNIQUE (name);


--
-- Name: Cities Cities_name_key131; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key131" UNIQUE (name);


--
-- Name: Cities Cities_name_key132; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key132" UNIQUE (name);


--
-- Name: Cities Cities_name_key133; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key133" UNIQUE (name);


--
-- Name: Cities Cities_name_key134; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key134" UNIQUE (name);


--
-- Name: Cities Cities_name_key135; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key135" UNIQUE (name);


--
-- Name: Cities Cities_name_key136; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key136" UNIQUE (name);


--
-- Name: Cities Cities_name_key137; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key137" UNIQUE (name);


--
-- Name: Cities Cities_name_key138; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key138" UNIQUE (name);


--
-- Name: Cities Cities_name_key139; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key139" UNIQUE (name);


--
-- Name: Cities Cities_name_key14; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key14" UNIQUE (name);


--
-- Name: Cities Cities_name_key140; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key140" UNIQUE (name);


--
-- Name: Cities Cities_name_key141; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key141" UNIQUE (name);


--
-- Name: Cities Cities_name_key142; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key142" UNIQUE (name);


--
-- Name: Cities Cities_name_key143; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key143" UNIQUE (name);


--
-- Name: Cities Cities_name_key144; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key144" UNIQUE (name);


--
-- Name: Cities Cities_name_key145; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key145" UNIQUE (name);


--
-- Name: Cities Cities_name_key146; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key146" UNIQUE (name);


--
-- Name: Cities Cities_name_key147; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key147" UNIQUE (name);


--
-- Name: Cities Cities_name_key148; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key148" UNIQUE (name);


--
-- Name: Cities Cities_name_key149; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key149" UNIQUE (name);


--
-- Name: Cities Cities_name_key15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key15" UNIQUE (name);


--
-- Name: Cities Cities_name_key150; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key150" UNIQUE (name);


--
-- Name: Cities Cities_name_key151; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key151" UNIQUE (name);


--
-- Name: Cities Cities_name_key152; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key152" UNIQUE (name);


--
-- Name: Cities Cities_name_key153; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key153" UNIQUE (name);


--
-- Name: Cities Cities_name_key154; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key154" UNIQUE (name);


--
-- Name: Cities Cities_name_key155; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key155" UNIQUE (name);


--
-- Name: Cities Cities_name_key156; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key156" UNIQUE (name);


--
-- Name: Cities Cities_name_key157; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key157" UNIQUE (name);


--
-- Name: Cities Cities_name_key158; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key158" UNIQUE (name);


--
-- Name: Cities Cities_name_key159; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key159" UNIQUE (name);


--
-- Name: Cities Cities_name_key16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key16" UNIQUE (name);


--
-- Name: Cities Cities_name_key160; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key160" UNIQUE (name);


--
-- Name: Cities Cities_name_key161; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key161" UNIQUE (name);


--
-- Name: Cities Cities_name_key162; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key162" UNIQUE (name);


--
-- Name: Cities Cities_name_key163; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key163" UNIQUE (name);


--
-- Name: Cities Cities_name_key164; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key164" UNIQUE (name);


--
-- Name: Cities Cities_name_key165; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key165" UNIQUE (name);


--
-- Name: Cities Cities_name_key166; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key166" UNIQUE (name);


--
-- Name: Cities Cities_name_key167; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key167" UNIQUE (name);


--
-- Name: Cities Cities_name_key168; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key168" UNIQUE (name);


--
-- Name: Cities Cities_name_key169; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key169" UNIQUE (name);


--
-- Name: Cities Cities_name_key17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key17" UNIQUE (name);


--
-- Name: Cities Cities_name_key170; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key170" UNIQUE (name);


--
-- Name: Cities Cities_name_key171; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key171" UNIQUE (name);


--
-- Name: Cities Cities_name_key172; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key172" UNIQUE (name);


--
-- Name: Cities Cities_name_key173; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key173" UNIQUE (name);


--
-- Name: Cities Cities_name_key174; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key174" UNIQUE (name);


--
-- Name: Cities Cities_name_key175; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key175" UNIQUE (name);


--
-- Name: Cities Cities_name_key176; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key176" UNIQUE (name);


--
-- Name: Cities Cities_name_key177; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key177" UNIQUE (name);


--
-- Name: Cities Cities_name_key178; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key178" UNIQUE (name);


--
-- Name: Cities Cities_name_key179; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key179" UNIQUE (name);


--
-- Name: Cities Cities_name_key18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key18" UNIQUE (name);


--
-- Name: Cities Cities_name_key180; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key180" UNIQUE (name);


--
-- Name: Cities Cities_name_key181; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key181" UNIQUE (name);


--
-- Name: Cities Cities_name_key182; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key182" UNIQUE (name);


--
-- Name: Cities Cities_name_key183; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key183" UNIQUE (name);


--
-- Name: Cities Cities_name_key184; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key184" UNIQUE (name);


--
-- Name: Cities Cities_name_key185; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key185" UNIQUE (name);


--
-- Name: Cities Cities_name_key186; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key186" UNIQUE (name);


--
-- Name: Cities Cities_name_key187; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key187" UNIQUE (name);


--
-- Name: Cities Cities_name_key188; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key188" UNIQUE (name);


--
-- Name: Cities Cities_name_key189; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key189" UNIQUE (name);


--
-- Name: Cities Cities_name_key19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key19" UNIQUE (name);


--
-- Name: Cities Cities_name_key190; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key190" UNIQUE (name);


--
-- Name: Cities Cities_name_key191; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key191" UNIQUE (name);


--
-- Name: Cities Cities_name_key192; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key192" UNIQUE (name);


--
-- Name: Cities Cities_name_key193; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key193" UNIQUE (name);


--
-- Name: Cities Cities_name_key194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key194" UNIQUE (name);


--
-- Name: Cities Cities_name_key195; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key195" UNIQUE (name);


--
-- Name: Cities Cities_name_key196; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key196" UNIQUE (name);


--
-- Name: Cities Cities_name_key197; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key197" UNIQUE (name);


--
-- Name: Cities Cities_name_key198; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key198" UNIQUE (name);


--
-- Name: Cities Cities_name_key199; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key199" UNIQUE (name);


--
-- Name: Cities Cities_name_key2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key2" UNIQUE (name);


--
-- Name: Cities Cities_name_key20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key20" UNIQUE (name);


--
-- Name: Cities Cities_name_key200; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key200" UNIQUE (name);


--
-- Name: Cities Cities_name_key201; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key201" UNIQUE (name);


--
-- Name: Cities Cities_name_key202; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key202" UNIQUE (name);


--
-- Name: Cities Cities_name_key203; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key203" UNIQUE (name);


--
-- Name: Cities Cities_name_key204; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key204" UNIQUE (name);


--
-- Name: Cities Cities_name_key205; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key205" UNIQUE (name);


--
-- Name: Cities Cities_name_key206; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key206" UNIQUE (name);


--
-- Name: Cities Cities_name_key207; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key207" UNIQUE (name);


--
-- Name: Cities Cities_name_key208; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key208" UNIQUE (name);


--
-- Name: Cities Cities_name_key209; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key209" UNIQUE (name);


--
-- Name: Cities Cities_name_key21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key21" UNIQUE (name);


--
-- Name: Cities Cities_name_key210; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key210" UNIQUE (name);


--
-- Name: Cities Cities_name_key211; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key211" UNIQUE (name);


--
-- Name: Cities Cities_name_key212; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key212" UNIQUE (name);


--
-- Name: Cities Cities_name_key213; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key213" UNIQUE (name);


--
-- Name: Cities Cities_name_key214; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key214" UNIQUE (name);


--
-- Name: Cities Cities_name_key215; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key215" UNIQUE (name);


--
-- Name: Cities Cities_name_key216; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key216" UNIQUE (name);


--
-- Name: Cities Cities_name_key217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key217" UNIQUE (name);


--
-- Name: Cities Cities_name_key218; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key218" UNIQUE (name);


--
-- Name: Cities Cities_name_key219; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key219" UNIQUE (name);


--
-- Name: Cities Cities_name_key22; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key22" UNIQUE (name);


--
-- Name: Cities Cities_name_key220; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key220" UNIQUE (name);


--
-- Name: Cities Cities_name_key221; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key221" UNIQUE (name);


--
-- Name: Cities Cities_name_key222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key222" UNIQUE (name);


--
-- Name: Cities Cities_name_key223; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key223" UNIQUE (name);


--
-- Name: Cities Cities_name_key224; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key224" UNIQUE (name);


--
-- Name: Cities Cities_name_key225; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key225" UNIQUE (name);


--
-- Name: Cities Cities_name_key226; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key226" UNIQUE (name);


--
-- Name: Cities Cities_name_key227; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key227" UNIQUE (name);


--
-- Name: Cities Cities_name_key228; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key228" UNIQUE (name);


--
-- Name: Cities Cities_name_key229; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key229" UNIQUE (name);


--
-- Name: Cities Cities_name_key23; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key23" UNIQUE (name);


--
-- Name: Cities Cities_name_key230; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key230" UNIQUE (name);


--
-- Name: Cities Cities_name_key231; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key231" UNIQUE (name);


--
-- Name: Cities Cities_name_key232; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key232" UNIQUE (name);


--
-- Name: Cities Cities_name_key233; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key233" UNIQUE (name);


--
-- Name: Cities Cities_name_key234; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key234" UNIQUE (name);


--
-- Name: Cities Cities_name_key235; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key235" UNIQUE (name);


--
-- Name: Cities Cities_name_key236; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key236" UNIQUE (name);


--
-- Name: Cities Cities_name_key237; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key237" UNIQUE (name);


--
-- Name: Cities Cities_name_key238; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key238" UNIQUE (name);


--
-- Name: Cities Cities_name_key239; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key239" UNIQUE (name);


--
-- Name: Cities Cities_name_key24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key24" UNIQUE (name);


--
-- Name: Cities Cities_name_key240; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key240" UNIQUE (name);


--
-- Name: Cities Cities_name_key241; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key241" UNIQUE (name);


--
-- Name: Cities Cities_name_key242; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key242" UNIQUE (name);


--
-- Name: Cities Cities_name_key243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key243" UNIQUE (name);


--
-- Name: Cities Cities_name_key244; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key244" UNIQUE (name);


--
-- Name: Cities Cities_name_key245; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key245" UNIQUE (name);


--
-- Name: Cities Cities_name_key246; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key246" UNIQUE (name);


--
-- Name: Cities Cities_name_key247; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key247" UNIQUE (name);


--
-- Name: Cities Cities_name_key248; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key248" UNIQUE (name);


--
-- Name: Cities Cities_name_key249; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key249" UNIQUE (name);


--
-- Name: Cities Cities_name_key25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key25" UNIQUE (name);


--
-- Name: Cities Cities_name_key250; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key250" UNIQUE (name);


--
-- Name: Cities Cities_name_key251; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key251" UNIQUE (name);


--
-- Name: Cities Cities_name_key252; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key252" UNIQUE (name);


--
-- Name: Cities Cities_name_key253; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key253" UNIQUE (name);


--
-- Name: Cities Cities_name_key254; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key254" UNIQUE (name);


--
-- Name: Cities Cities_name_key255; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key255" UNIQUE (name);


--
-- Name: Cities Cities_name_key256; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key256" UNIQUE (name);


--
-- Name: Cities Cities_name_key257; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key257" UNIQUE (name);


--
-- Name: Cities Cities_name_key258; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key258" UNIQUE (name);


--
-- Name: Cities Cities_name_key259; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key259" UNIQUE (name);


--
-- Name: Cities Cities_name_key26; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key26" UNIQUE (name);


--
-- Name: Cities Cities_name_key260; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key260" UNIQUE (name);


--
-- Name: Cities Cities_name_key261; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key261" UNIQUE (name);


--
-- Name: Cities Cities_name_key262; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key262" UNIQUE (name);


--
-- Name: Cities Cities_name_key263; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key263" UNIQUE (name);


--
-- Name: Cities Cities_name_key264; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key264" UNIQUE (name);


--
-- Name: Cities Cities_name_key265; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key265" UNIQUE (name);


--
-- Name: Cities Cities_name_key266; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key266" UNIQUE (name);


--
-- Name: Cities Cities_name_key267; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key267" UNIQUE (name);


--
-- Name: Cities Cities_name_key268; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key268" UNIQUE (name);


--
-- Name: Cities Cities_name_key269; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key269" UNIQUE (name);


--
-- Name: Cities Cities_name_key27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key27" UNIQUE (name);


--
-- Name: Cities Cities_name_key270; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key270" UNIQUE (name);


--
-- Name: Cities Cities_name_key271; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key271" UNIQUE (name);


--
-- Name: Cities Cities_name_key272; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key272" UNIQUE (name);


--
-- Name: Cities Cities_name_key273; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key273" UNIQUE (name);


--
-- Name: Cities Cities_name_key274; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key274" UNIQUE (name);


--
-- Name: Cities Cities_name_key275; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key275" UNIQUE (name);


--
-- Name: Cities Cities_name_key276; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key276" UNIQUE (name);


--
-- Name: Cities Cities_name_key277; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key277" UNIQUE (name);


--
-- Name: Cities Cities_name_key278; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key278" UNIQUE (name);


--
-- Name: Cities Cities_name_key279; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key279" UNIQUE (name);


--
-- Name: Cities Cities_name_key28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key28" UNIQUE (name);


--
-- Name: Cities Cities_name_key280; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key280" UNIQUE (name);


--
-- Name: Cities Cities_name_key281; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key281" UNIQUE (name);


--
-- Name: Cities Cities_name_key282; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key282" UNIQUE (name);


--
-- Name: Cities Cities_name_key283; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key283" UNIQUE (name);


--
-- Name: Cities Cities_name_key284; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key284" UNIQUE (name);


--
-- Name: Cities Cities_name_key285; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key285" UNIQUE (name);


--
-- Name: Cities Cities_name_key286; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key286" UNIQUE (name);


--
-- Name: Cities Cities_name_key287; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key287" UNIQUE (name);


--
-- Name: Cities Cities_name_key288; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key288" UNIQUE (name);


--
-- Name: Cities Cities_name_key289; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key289" UNIQUE (name);


--
-- Name: Cities Cities_name_key29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key29" UNIQUE (name);


--
-- Name: Cities Cities_name_key290; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key290" UNIQUE (name);


--
-- Name: Cities Cities_name_key291; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key291" UNIQUE (name);


--
-- Name: Cities Cities_name_key292; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key292" UNIQUE (name);


--
-- Name: Cities Cities_name_key293; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key293" UNIQUE (name);


--
-- Name: Cities Cities_name_key294; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key294" UNIQUE (name);


--
-- Name: Cities Cities_name_key295; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key295" UNIQUE (name);


--
-- Name: Cities Cities_name_key296; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key296" UNIQUE (name);


--
-- Name: Cities Cities_name_key297; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key297" UNIQUE (name);


--
-- Name: Cities Cities_name_key298; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key298" UNIQUE (name);


--
-- Name: Cities Cities_name_key299; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key299" UNIQUE (name);


--
-- Name: Cities Cities_name_key3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key3" UNIQUE (name);


--
-- Name: Cities Cities_name_key30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key30" UNIQUE (name);


--
-- Name: Cities Cities_name_key300; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key300" UNIQUE (name);


--
-- Name: Cities Cities_name_key301; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key301" UNIQUE (name);


--
-- Name: Cities Cities_name_key302; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key302" UNIQUE (name);


--
-- Name: Cities Cities_name_key303; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key303" UNIQUE (name);


--
-- Name: Cities Cities_name_key304; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key304" UNIQUE (name);


--
-- Name: Cities Cities_name_key305; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key305" UNIQUE (name);


--
-- Name: Cities Cities_name_key306; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key306" UNIQUE (name);


--
-- Name: Cities Cities_name_key307; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key307" UNIQUE (name);


--
-- Name: Cities Cities_name_key308; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key308" UNIQUE (name);


--
-- Name: Cities Cities_name_key309; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key309" UNIQUE (name);


--
-- Name: Cities Cities_name_key31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key31" UNIQUE (name);


--
-- Name: Cities Cities_name_key310; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key310" UNIQUE (name);


--
-- Name: Cities Cities_name_key311; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key311" UNIQUE (name);


--
-- Name: Cities Cities_name_key312; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key312" UNIQUE (name);


--
-- Name: Cities Cities_name_key313; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key313" UNIQUE (name);


--
-- Name: Cities Cities_name_key314; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key314" UNIQUE (name);


--
-- Name: Cities Cities_name_key315; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key315" UNIQUE (name);


--
-- Name: Cities Cities_name_key316; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key316" UNIQUE (name);


--
-- Name: Cities Cities_name_key317; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key317" UNIQUE (name);


--
-- Name: Cities Cities_name_key318; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key318" UNIQUE (name);


--
-- Name: Cities Cities_name_key319; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key319" UNIQUE (name);


--
-- Name: Cities Cities_name_key32; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key32" UNIQUE (name);


--
-- Name: Cities Cities_name_key320; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key320" UNIQUE (name);


--
-- Name: Cities Cities_name_key321; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key321" UNIQUE (name);


--
-- Name: Cities Cities_name_key322; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key322" UNIQUE (name);


--
-- Name: Cities Cities_name_key323; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key323" UNIQUE (name);


--
-- Name: Cities Cities_name_key324; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key324" UNIQUE (name);


--
-- Name: Cities Cities_name_key325; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key325" UNIQUE (name);


--
-- Name: Cities Cities_name_key326; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key326" UNIQUE (name);


--
-- Name: Cities Cities_name_key327; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key327" UNIQUE (name);


--
-- Name: Cities Cities_name_key328; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key328" UNIQUE (name);


--
-- Name: Cities Cities_name_key329; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key329" UNIQUE (name);


--
-- Name: Cities Cities_name_key33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key33" UNIQUE (name);


--
-- Name: Cities Cities_name_key330; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key330" UNIQUE (name);


--
-- Name: Cities Cities_name_key331; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key331" UNIQUE (name);


--
-- Name: Cities Cities_name_key332; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key332" UNIQUE (name);


--
-- Name: Cities Cities_name_key333; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key333" UNIQUE (name);


--
-- Name: Cities Cities_name_key334; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key334" UNIQUE (name);


--
-- Name: Cities Cities_name_key335; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key335" UNIQUE (name);


--
-- Name: Cities Cities_name_key336; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key336" UNIQUE (name);


--
-- Name: Cities Cities_name_key337; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key337" UNIQUE (name);


--
-- Name: Cities Cities_name_key338; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key338" UNIQUE (name);


--
-- Name: Cities Cities_name_key339; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key339" UNIQUE (name);


--
-- Name: Cities Cities_name_key34; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key34" UNIQUE (name);


--
-- Name: Cities Cities_name_key340; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key340" UNIQUE (name);


--
-- Name: Cities Cities_name_key341; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key341" UNIQUE (name);


--
-- Name: Cities Cities_name_key342; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key342" UNIQUE (name);


--
-- Name: Cities Cities_name_key343; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key343" UNIQUE (name);


--
-- Name: Cities Cities_name_key344; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key344" UNIQUE (name);


--
-- Name: Cities Cities_name_key345; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key345" UNIQUE (name);


--
-- Name: Cities Cities_name_key346; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key346" UNIQUE (name);


--
-- Name: Cities Cities_name_key347; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key347" UNIQUE (name);


--
-- Name: Cities Cities_name_key348; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key348" UNIQUE (name);


--
-- Name: Cities Cities_name_key349; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key349" UNIQUE (name);


--
-- Name: Cities Cities_name_key35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key35" UNIQUE (name);


--
-- Name: Cities Cities_name_key350; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key350" UNIQUE (name);


--
-- Name: Cities Cities_name_key351; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key351" UNIQUE (name);


--
-- Name: Cities Cities_name_key352; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key352" UNIQUE (name);


--
-- Name: Cities Cities_name_key353; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key353" UNIQUE (name);


--
-- Name: Cities Cities_name_key354; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key354" UNIQUE (name);


--
-- Name: Cities Cities_name_key355; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key355" UNIQUE (name);


--
-- Name: Cities Cities_name_key356; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key356" UNIQUE (name);


--
-- Name: Cities Cities_name_key357; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key357" UNIQUE (name);


--
-- Name: Cities Cities_name_key358; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key358" UNIQUE (name);


--
-- Name: Cities Cities_name_key359; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key359" UNIQUE (name);


--
-- Name: Cities Cities_name_key36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key36" UNIQUE (name);


--
-- Name: Cities Cities_name_key360; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key360" UNIQUE (name);


--
-- Name: Cities Cities_name_key361; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key361" UNIQUE (name);


--
-- Name: Cities Cities_name_key362; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key362" UNIQUE (name);


--
-- Name: Cities Cities_name_key363; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key363" UNIQUE (name);


--
-- Name: Cities Cities_name_key364; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key364" UNIQUE (name);


--
-- Name: Cities Cities_name_key365; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key365" UNIQUE (name);


--
-- Name: Cities Cities_name_key366; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key366" UNIQUE (name);


--
-- Name: Cities Cities_name_key367; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key367" UNIQUE (name);


--
-- Name: Cities Cities_name_key368; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key368" UNIQUE (name);


--
-- Name: Cities Cities_name_key369; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key369" UNIQUE (name);


--
-- Name: Cities Cities_name_key37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key37" UNIQUE (name);


--
-- Name: Cities Cities_name_key370; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key370" UNIQUE (name);


--
-- Name: Cities Cities_name_key371; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key371" UNIQUE (name);


--
-- Name: Cities Cities_name_key372; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key372" UNIQUE (name);


--
-- Name: Cities Cities_name_key373; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key373" UNIQUE (name);


--
-- Name: Cities Cities_name_key374; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key374" UNIQUE (name);


--
-- Name: Cities Cities_name_key375; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key375" UNIQUE (name);


--
-- Name: Cities Cities_name_key376; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key376" UNIQUE (name);


--
-- Name: Cities Cities_name_key377; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key377" UNIQUE (name);


--
-- Name: Cities Cities_name_key378; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key378" UNIQUE (name);


--
-- Name: Cities Cities_name_key379; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key379" UNIQUE (name);


--
-- Name: Cities Cities_name_key38; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key38" UNIQUE (name);


--
-- Name: Cities Cities_name_key380; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key380" UNIQUE (name);


--
-- Name: Cities Cities_name_key381; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key381" UNIQUE (name);


--
-- Name: Cities Cities_name_key382; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key382" UNIQUE (name);


--
-- Name: Cities Cities_name_key383; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key383" UNIQUE (name);


--
-- Name: Cities Cities_name_key384; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key384" UNIQUE (name);


--
-- Name: Cities Cities_name_key385; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key385" UNIQUE (name);


--
-- Name: Cities Cities_name_key386; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key386" UNIQUE (name);


--
-- Name: Cities Cities_name_key387; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key387" UNIQUE (name);


--
-- Name: Cities Cities_name_key388; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key388" UNIQUE (name);


--
-- Name: Cities Cities_name_key389; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key389" UNIQUE (name);


--
-- Name: Cities Cities_name_key39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key39" UNIQUE (name);


--
-- Name: Cities Cities_name_key390; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key390" UNIQUE (name);


--
-- Name: Cities Cities_name_key391; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key391" UNIQUE (name);


--
-- Name: Cities Cities_name_key392; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key392" UNIQUE (name);


--
-- Name: Cities Cities_name_key393; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key393" UNIQUE (name);


--
-- Name: Cities Cities_name_key394; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key394" UNIQUE (name);


--
-- Name: Cities Cities_name_key395; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key395" UNIQUE (name);


--
-- Name: Cities Cities_name_key396; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key396" UNIQUE (name);


--
-- Name: Cities Cities_name_key397; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key397" UNIQUE (name);


--
-- Name: Cities Cities_name_key398; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key398" UNIQUE (name);


--
-- Name: Cities Cities_name_key399; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key399" UNIQUE (name);


--
-- Name: Cities Cities_name_key4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key4" UNIQUE (name);


--
-- Name: Cities Cities_name_key40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key40" UNIQUE (name);


--
-- Name: Cities Cities_name_key41; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key41" UNIQUE (name);


--
-- Name: Cities Cities_name_key42; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key42" UNIQUE (name);


--
-- Name: Cities Cities_name_key43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key43" UNIQUE (name);


--
-- Name: Cities Cities_name_key44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key44" UNIQUE (name);


--
-- Name: Cities Cities_name_key45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key45" UNIQUE (name);


--
-- Name: Cities Cities_name_key46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key46" UNIQUE (name);


--
-- Name: Cities Cities_name_key47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key47" UNIQUE (name);


--
-- Name: Cities Cities_name_key48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key48" UNIQUE (name);


--
-- Name: Cities Cities_name_key49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key49" UNIQUE (name);


--
-- Name: Cities Cities_name_key5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key5" UNIQUE (name);


--
-- Name: Cities Cities_name_key50; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key50" UNIQUE (name);


--
-- Name: Cities Cities_name_key51; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key51" UNIQUE (name);


--
-- Name: Cities Cities_name_key52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key52" UNIQUE (name);


--
-- Name: Cities Cities_name_key53; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key53" UNIQUE (name);


--
-- Name: Cities Cities_name_key54; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key54" UNIQUE (name);


--
-- Name: Cities Cities_name_key55; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key55" UNIQUE (name);


--
-- Name: Cities Cities_name_key56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key56" UNIQUE (name);


--
-- Name: Cities Cities_name_key57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key57" UNIQUE (name);


--
-- Name: Cities Cities_name_key58; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key58" UNIQUE (name);


--
-- Name: Cities Cities_name_key59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key59" UNIQUE (name);


--
-- Name: Cities Cities_name_key6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key6" UNIQUE (name);


--
-- Name: Cities Cities_name_key60; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key60" UNIQUE (name);


--
-- Name: Cities Cities_name_key61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key61" UNIQUE (name);


--
-- Name: Cities Cities_name_key62; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key62" UNIQUE (name);


--
-- Name: Cities Cities_name_key63; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key63" UNIQUE (name);


--
-- Name: Cities Cities_name_key64; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key64" UNIQUE (name);


--
-- Name: Cities Cities_name_key65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key65" UNIQUE (name);


--
-- Name: Cities Cities_name_key66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key66" UNIQUE (name);


--
-- Name: Cities Cities_name_key67; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key67" UNIQUE (name);


--
-- Name: Cities Cities_name_key68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key68" UNIQUE (name);


--
-- Name: Cities Cities_name_key69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key69" UNIQUE (name);


--
-- Name: Cities Cities_name_key7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key7" UNIQUE (name);


--
-- Name: Cities Cities_name_key70; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key70" UNIQUE (name);


--
-- Name: Cities Cities_name_key71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key71" UNIQUE (name);


--
-- Name: Cities Cities_name_key72; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key72" UNIQUE (name);


--
-- Name: Cities Cities_name_key73; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key73" UNIQUE (name);


--
-- Name: Cities Cities_name_key74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key74" UNIQUE (name);


--
-- Name: Cities Cities_name_key75; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key75" UNIQUE (name);


--
-- Name: Cities Cities_name_key76; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key76" UNIQUE (name);


--
-- Name: Cities Cities_name_key77; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key77" UNIQUE (name);


--
-- Name: Cities Cities_name_key78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key78" UNIQUE (name);


--
-- Name: Cities Cities_name_key79; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key79" UNIQUE (name);


--
-- Name: Cities Cities_name_key8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key8" UNIQUE (name);


--
-- Name: Cities Cities_name_key80; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key80" UNIQUE (name);


--
-- Name: Cities Cities_name_key81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key81" UNIQUE (name);


--
-- Name: Cities Cities_name_key82; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key82" UNIQUE (name);


--
-- Name: Cities Cities_name_key83; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key83" UNIQUE (name);


--
-- Name: Cities Cities_name_key84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key84" UNIQUE (name);


--
-- Name: Cities Cities_name_key85; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key85" UNIQUE (name);


--
-- Name: Cities Cities_name_key86; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key86" UNIQUE (name);


--
-- Name: Cities Cities_name_key87; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key87" UNIQUE (name);


--
-- Name: Cities Cities_name_key88; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key88" UNIQUE (name);


--
-- Name: Cities Cities_name_key89; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key89" UNIQUE (name);


--
-- Name: Cities Cities_name_key9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key9" UNIQUE (name);


--
-- Name: Cities Cities_name_key90; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key90" UNIQUE (name);


--
-- Name: Cities Cities_name_key91; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key91" UNIQUE (name);


--
-- Name: Cities Cities_name_key92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key92" UNIQUE (name);


--
-- Name: Cities Cities_name_key93; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key93" UNIQUE (name);


--
-- Name: Cities Cities_name_key94; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key94" UNIQUE (name);


--
-- Name: Cities Cities_name_key95; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key95" UNIQUE (name);


--
-- Name: Cities Cities_name_key96; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key96" UNIQUE (name);


--
-- Name: Cities Cities_name_key97; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key97" UNIQUE (name);


--
-- Name: Cities Cities_name_key98; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key98" UNIQUE (name);


--
-- Name: Cities Cities_name_key99; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_name_key99" UNIQUE (name);


--
-- Name: Cities Cities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Cities"
    ADD CONSTRAINT "Cities_pkey" PRIMARY KEY (id);


--
-- Name: EmailTemplates EmailTemplates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmailTemplates"
    ADD CONSTRAINT "EmailTemplates_pkey" PRIMARY KEY (id);


--
-- Name: FunFacts FunFacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FunFacts"
    ADD CONSTRAINT "FunFacts_pkey" PRIMARY KEY (id);


--
-- Name: HomeComponents HomeComponents_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key1" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key10; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key10" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key100; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key100" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key101; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key101" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key102; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key102" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key103; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key103" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key104; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key104" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key105; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key105" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key106; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key106" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key107; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key107" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key108; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key108" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key109; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key109" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key11; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key11" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key110; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key110" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key111; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key111" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key112; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key112" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key113; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key113" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key114; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key114" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key115; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key115" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key116; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key116" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key117; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key117" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key118; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key118" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key119; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key119" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key12; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key12" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key120; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key120" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key121; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key121" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key122" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key123; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key123" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key124; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key124" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key125; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key125" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key126; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key126" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key127; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key127" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key128; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key128" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key129; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key129" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key13; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key13" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key130; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key130" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key131; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key131" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key132; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key132" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key133; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key133" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key134; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key134" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key135; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key135" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key136; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key136" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key137; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key137" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key138; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key138" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key139; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key139" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key14; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key14" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key140; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key140" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key141; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key141" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key142; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key142" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key143; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key143" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key144; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key144" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key145; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key145" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key146; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key146" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key147; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key147" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key148; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key148" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key149; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key149" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key15" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key150; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key150" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key151; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key151" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key152; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key152" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key153; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key153" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key154; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key154" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key155; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key155" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key156; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key156" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key157; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key157" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key158; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key158" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key159; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key159" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key16" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key160; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key160" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key161; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key161" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key162; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key162" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key163; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key163" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key164; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key164" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key165; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key165" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key166; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key166" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key167; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key167" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key168; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key168" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key169; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key169" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key17" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key170; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key170" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key171; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key171" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key172; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key172" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key173; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key173" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key174; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key174" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key175; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key175" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key176; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key176" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key177; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key177" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key178; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key178" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key179; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key179" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key18" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key180; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key180" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key181; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key181" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key182; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key182" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key183; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key183" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key184; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key184" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key185; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key185" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key186; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key186" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key187; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key187" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key188; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key188" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key189; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key189" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key19" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key190; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key190" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key191; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key191" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key192; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key192" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key193; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key193" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key194" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key195; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key195" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key196; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key196" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key197; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key197" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key198; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key198" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key199; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key199" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key2" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key20" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key200; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key200" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key201; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key201" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key202; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key202" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key203; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key203" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key204; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key204" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key205; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key205" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key206; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key206" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key207; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key207" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key208; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key208" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key209; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key209" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key21" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key210; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key210" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key211; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key211" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key212; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key212" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key213; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key213" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key214; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key214" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key215; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key215" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key216; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key216" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key217" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key218; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key218" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key219; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key219" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key22; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key22" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key220; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key220" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key221; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key221" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key222" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key223; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key223" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key224; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key224" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key225; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key225" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key226; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key226" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key227; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key227" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key228; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key228" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key229; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key229" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key23; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key23" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key230; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key230" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key231; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key231" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key232; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key232" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key233; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key233" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key234; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key234" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key235; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key235" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key236; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key236" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key237; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key237" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key238; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key238" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key239; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key239" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key24" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key240; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key240" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key241; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key241" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key242; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key242" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key243" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key244; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key244" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key245; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key245" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key246; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key246" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key247; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key247" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key248; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key248" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key249; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key249" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key25" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key250; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key250" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key251; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key251" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key252; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key252" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key253; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key253" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key254; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key254" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key255; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key255" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key256; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key256" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key257; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key257" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key258; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key258" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key259; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key259" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key26; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key26" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key260; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key260" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key261; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key261" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key262; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key262" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key263; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key263" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key264; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key264" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key265; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key265" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key266; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key266" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key267; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key267" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key268; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key268" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key269; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key269" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key27" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key270; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key270" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key271; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key271" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key272; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key272" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key273; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key273" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key274; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key274" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key275; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key275" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key276; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key276" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key277; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key277" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key278; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key278" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key279; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key279" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key28" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key280; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key280" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key281; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key281" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key282; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key282" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key283; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key283" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key284; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key284" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key285; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key285" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key286; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key286" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key287; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key287" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key288; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key288" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key289; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key289" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key29" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key290; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key290" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key291; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key291" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key292; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key292" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key293; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key293" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key294; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key294" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key295; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key295" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key296; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key296" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key297; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key297" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key298; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key298" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key299; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key299" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key3" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key30" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key300; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key300" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key301; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key301" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key302; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key302" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key303; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key303" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key304; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key304" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key305; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key305" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key306; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key306" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key307; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key307" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key308; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key308" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key309; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key309" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key31" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key310; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key310" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key311; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key311" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key312; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key312" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key313; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key313" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key314; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key314" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key315; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key315" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key316; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key316" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key317; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key317" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key318; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key318" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key319; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key319" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key32; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key32" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key320; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key320" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key321; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key321" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key322; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key322" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key323; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key323" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key324; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key324" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key325; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key325" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key326; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key326" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key327; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key327" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key328; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key328" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key329; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key329" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key33" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key330; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key330" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key331; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key331" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key332; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key332" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key333; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key333" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key334; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key334" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key335; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key335" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key336; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key336" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key337; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key337" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key338; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key338" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key339; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key339" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key34; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key34" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key340; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key340" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key341; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key341" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key342; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key342" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key343; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key343" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key344; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key344" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key345; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key345" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key346; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key346" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key347; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key347" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key348; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key348" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key349; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key349" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key35" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key350; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key350" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key351; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key351" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key352; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key352" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key353; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key353" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key354; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key354" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key355; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key355" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key356; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key356" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key357; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key357" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key358; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key358" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key359; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key359" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key36" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key360; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key360" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key361; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key361" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key362; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key362" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key363; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key363" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key364; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key364" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key365; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key365" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key366; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key366" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key367; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key367" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key368; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key368" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key369; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key369" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key37" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key370; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key370" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key371; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key371" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key372; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key372" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key373; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key373" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key374; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key374" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key375; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key375" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key376; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key376" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key377; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key377" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key378; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key378" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key379; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key379" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key38; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key38" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key380; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key380" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key381; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key381" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key382; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key382" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key383; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key383" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key384; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key384" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key385; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key385" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key386; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key386" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key387; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key387" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key388; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key388" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key389; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key389" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key39" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key390; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key390" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key391; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key391" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key392; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key392" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key393; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key393" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key394; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key394" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key395; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key395" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key396; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key396" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key397; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key397" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key398; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key398" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key399; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key399" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key4" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key40" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key400; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key400" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key401; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key401" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key402; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key402" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key403; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key403" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key404; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key404" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key405; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key405" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key406; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key406" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key407; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key407" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key408; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key408" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key409; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key409" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key41; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key41" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key410; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key410" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key411; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key411" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key412; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key412" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key413; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key413" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key414; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key414" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key415; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key415" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key416; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key416" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key417; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key417" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key418; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key418" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key419; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key419" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key42; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key42" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key420; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key420" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key421; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key421" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key422; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key422" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key423; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key423" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key424; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key424" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key425; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key425" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key426; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key426" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key427; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key427" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key428; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key428" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key429; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key429" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key43" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key430; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key430" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key431; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key431" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key432; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key432" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key433" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key434; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key434" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key435; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key435" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key436; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key436" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key437; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key437" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key438; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key438" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key439; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key439" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key44" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key440; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key440" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key441; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key441" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key442; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key442" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key443; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key443" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key444; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key444" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key445; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key445" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key446; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key446" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key447; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key447" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key448; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key448" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key449; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key449" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key45" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key450; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key450" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key451; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key451" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key452; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key452" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key453; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key453" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key454; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key454" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key455; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key455" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key456; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key456" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key457; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key457" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key458; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key458" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key459; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key459" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key46" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key460; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key460" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key461; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key461" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key462; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key462" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key463; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key463" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key464; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key464" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key465; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key465" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key466; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key466" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key467; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key467" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key468; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key468" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key469; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key469" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key47" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key470; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key470" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key471; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key471" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key472; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key472" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key473; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key473" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key474; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key474" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key475; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key475" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key476; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key476" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key477; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key477" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key478; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key478" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key479; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key479" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key48" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key480; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key480" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key481; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key481" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key482; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key482" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key483; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key483" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key484; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key484" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key485; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key485" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key486; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key486" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key487; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key487" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key488; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key488" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key489; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key489" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key49" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key5" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key50; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key50" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key51; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key51" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key52" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key53; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key53" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key54; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key54" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key55; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key55" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key56" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key57" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key58; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key58" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key59" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key6" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key60; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key60" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key61" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key62; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key62" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key63; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key63" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key64; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key64" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key65" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key66" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key67; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key67" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key68" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key69" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key7" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key70; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key70" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key71" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key72; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key72" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key73; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key73" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key74" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key75; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key75" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key76; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key76" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key77; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key77" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key78" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key79; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key79" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key8" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key80; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key80" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key81" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key82; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key82" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key83; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key83" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key84" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key85; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key85" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key86; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key86" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key87; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key87" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key88; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key88" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key89; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key89" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key9" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key90; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key90" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key91; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key91" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key92" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key93; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key93" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key94; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key94" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key95; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key95" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key96; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key96" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key97; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key97" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key98; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key98" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_name_key99; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_name_key99" UNIQUE (name);


--
-- Name: HomeComponents HomeComponents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."HomeComponents"
    ADD CONSTRAINT "HomeComponents_pkey" PRIMARY KEY (id);


--
-- Name: InstaReels InstaReels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."InstaReels"
    ADD CONSTRAINT "InstaReels_pkey" PRIMARY KEY (id);


--
-- Name: Localities Localities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Localities"
    ADD CONSTRAINT "Localities_pkey" PRIMARY KEY (id);


--
-- Name: MenuItems MenuItems_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MenuItems"
    ADD CONSTRAINT "MenuItems_pkey" PRIMARY KEY (id);


--
-- Name: Projects Projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "Projects_pkey" PRIMARY KEY (id);


--
-- Name: Properties Properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "Properties_pkey" PRIMARY KEY (id);


--
-- Name: PropertyImages PropertyImages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropertyImages"
    ADD CONSTRAINT "PropertyImages_pkey" PRIMARY KEY (id);


--
-- Name: PropertyTypes PropertyTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PropertyTypes"
    ADD CONSTRAINT "PropertyTypes_pkey" PRIMARY KEY (id);


--
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- Name: Services Services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Services"
    ADD CONSTRAINT "Services_pkey" PRIMARY KEY (id);


--
-- Name: Settings Settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Settings"
    ADD CONSTRAINT "Settings_pkey" PRIMARY KEY (id);


--
-- Name: Subscribers Subscribers_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key1" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key10; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key10" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key100; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key100" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key101; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key101" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key102; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key102" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key103; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key103" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key104; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key104" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key105; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key105" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key106; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key106" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key107; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key107" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key108; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key108" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key109; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key109" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key11; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key11" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key110; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key110" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key111; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key111" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key112; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key112" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key113; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key113" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key114; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key114" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key115; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key115" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key116; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key116" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key117; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key117" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key118; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key118" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key119; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key119" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key12; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key12" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key120; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key120" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key121; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key121" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key122" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key123; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key123" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key124; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key124" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key125; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key125" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key126; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key126" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key127; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key127" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key128; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key128" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key129; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key129" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key13; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key13" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key130; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key130" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key131; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key131" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key132; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key132" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key133; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key133" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key134; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key134" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key135; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key135" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key136; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key136" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key137; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key137" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key138; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key138" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key139; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key139" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key14; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key14" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key140; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key140" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key141; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key141" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key142; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key142" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key143; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key143" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key144; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key144" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key145; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key145" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key146; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key146" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key147; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key147" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key148; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key148" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key149; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key149" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key15" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key150; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key150" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key151; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key151" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key152; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key152" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key153; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key153" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key154; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key154" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key155; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key155" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key156; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key156" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key157; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key157" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key158; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key158" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key159; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key159" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key16" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key160; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key160" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key161; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key161" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key162; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key162" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key163; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key163" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key164; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key164" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key165; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key165" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key166; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key166" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key167; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key167" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key168; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key168" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key169; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key169" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key17" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key170; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key170" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key171; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key171" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key172; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key172" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key173; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key173" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key174; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key174" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key175; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key175" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key176; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key176" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key177; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key177" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key178; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key178" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key179; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key179" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key18" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key180; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key180" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key181; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key181" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key182; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key182" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key183; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key183" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key184; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key184" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key185; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key185" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key186; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key186" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key187; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key187" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key188; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key188" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key189; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key189" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key19" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key190; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key190" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key191; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key191" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key192; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key192" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key193; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key193" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key194" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key195; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key195" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key196; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key196" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key197; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key197" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key198; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key198" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key199; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key199" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key2" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key20" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key200; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key200" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key201; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key201" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key202; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key202" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key203; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key203" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key204; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key204" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key205; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key205" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key206; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key206" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key207; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key207" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key208; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key208" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key209; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key209" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key21" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key210; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key210" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key211; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key211" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key212; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key212" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key213; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key213" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key214; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key214" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key215; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key215" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key216; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key216" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key217" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key218; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key218" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key219; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key219" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key22; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key22" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key220; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key220" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key221; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key221" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key222" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key223; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key223" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key224; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key224" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key225; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key225" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key226; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key226" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key227; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key227" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key228; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key228" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key229; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key229" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key23; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key23" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key230; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key230" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key231; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key231" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key232; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key232" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key233; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key233" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key234; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key234" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key235; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key235" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key236; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key236" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key237; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key237" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key238; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key238" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key239; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key239" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key24" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key240; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key240" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key241; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key241" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key242; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key242" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key243" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key244; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key244" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key245; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key245" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key246; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key246" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key247; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key247" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key248; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key248" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key249; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key249" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key25" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key250; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key250" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key251; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key251" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key252; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key252" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key253; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key253" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key254; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key254" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key255; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key255" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key256; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key256" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key257; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key257" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key258; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key258" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key259; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key259" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key26; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key26" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key260; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key260" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key261; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key261" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key262; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key262" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key263; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key263" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key264; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key264" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key265; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key265" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key266; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key266" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key267; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key267" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key268; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key268" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key269; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key269" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key27" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key270; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key270" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key271; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key271" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key272; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key272" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key273; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key273" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key274; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key274" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key275; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key275" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key276; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key276" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key277; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key277" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key278; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key278" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key279; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key279" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key28" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key280; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key280" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key281; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key281" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key282; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key282" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key283; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key283" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key284; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key284" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key285; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key285" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key286; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key286" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key287; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key287" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key288; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key288" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key289; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key289" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key29" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key290; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key290" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key291; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key291" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key292; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key292" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key293; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key293" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key294; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key294" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key295; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key295" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key296; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key296" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key297; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key297" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key298; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key298" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key299; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key299" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key3" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key30" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key300; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key300" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key301; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key301" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key31" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key32; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key32" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key33" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key34; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key34" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key35" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key36" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key37" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key38; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key38" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key39" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key4" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key40" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key41; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key41" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key42; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key42" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key43" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key44" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key45" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key46" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key47" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key48" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key49" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key5" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key50; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key50" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key51; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key51" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key52" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key53; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key53" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key54; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key54" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key55; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key55" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key56" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key57" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key58; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key58" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key59" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key6" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key60; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key60" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key61" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key62; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key62" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key63; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key63" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key64; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key64" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key65" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key66" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key67; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key67" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key68" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key69" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key7" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key70; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key70" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key71" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key72; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key72" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key73; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key73" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key74" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key75; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key75" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key76; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key76" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key77; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key77" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key78" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key79; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key79" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key8" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key80; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key80" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key81" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key82; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key82" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key83; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key83" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key84" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key85; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key85" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key86; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key86" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key87; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key87" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key88; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key88" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key89; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key89" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key9" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key90; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key90" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key91; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key91" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key92" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key93; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key93" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key94; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key94" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key95; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key95" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key96; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key96" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key97; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key97" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key98; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key98" UNIQUE (email);


--
-- Name: Subscribers Subscribers_email_key99; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_email_key99" UNIQUE (email);


--
-- Name: Subscribers Subscribers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscribers"
    ADD CONSTRAINT "Subscribers_pkey" PRIMARY KEY (id);


--
-- Name: TeamMembers TeamMembers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TeamMembers"
    ADD CONSTRAINT "TeamMembers_pkey" PRIMARY KEY (id);


--
-- Name: Testimonials Testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Testimonials"
    ADD CONSTRAINT "Testimonials_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key" UNIQUE (email);


--
-- Name: Users Users_email_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key1" UNIQUE (email);


--
-- Name: Users Users_email_key10; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key10" UNIQUE (email);


--
-- Name: Users Users_email_key100; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key100" UNIQUE (email);


--
-- Name: Users Users_email_key101; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key101" UNIQUE (email);


--
-- Name: Users Users_email_key102; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key102" UNIQUE (email);


--
-- Name: Users Users_email_key103; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key103" UNIQUE (email);


--
-- Name: Users Users_email_key104; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key104" UNIQUE (email);


--
-- Name: Users Users_email_key105; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key105" UNIQUE (email);


--
-- Name: Users Users_email_key106; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key106" UNIQUE (email);


--
-- Name: Users Users_email_key107; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key107" UNIQUE (email);


--
-- Name: Users Users_email_key108; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key108" UNIQUE (email);


--
-- Name: Users Users_email_key109; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key109" UNIQUE (email);


--
-- Name: Users Users_email_key11; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key11" UNIQUE (email);


--
-- Name: Users Users_email_key110; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key110" UNIQUE (email);


--
-- Name: Users Users_email_key111; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key111" UNIQUE (email);


--
-- Name: Users Users_email_key112; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key112" UNIQUE (email);


--
-- Name: Users Users_email_key113; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key113" UNIQUE (email);


--
-- Name: Users Users_email_key114; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key114" UNIQUE (email);


--
-- Name: Users Users_email_key115; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key115" UNIQUE (email);


--
-- Name: Users Users_email_key116; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key116" UNIQUE (email);


--
-- Name: Users Users_email_key117; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key117" UNIQUE (email);


--
-- Name: Users Users_email_key118; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key118" UNIQUE (email);


--
-- Name: Users Users_email_key119; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key119" UNIQUE (email);


--
-- Name: Users Users_email_key12; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key12" UNIQUE (email);


--
-- Name: Users Users_email_key120; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key120" UNIQUE (email);


--
-- Name: Users Users_email_key121; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key121" UNIQUE (email);


--
-- Name: Users Users_email_key122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key122" UNIQUE (email);


--
-- Name: Users Users_email_key123; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key123" UNIQUE (email);


--
-- Name: Users Users_email_key124; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key124" UNIQUE (email);


--
-- Name: Users Users_email_key125; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key125" UNIQUE (email);


--
-- Name: Users Users_email_key126; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key126" UNIQUE (email);


--
-- Name: Users Users_email_key127; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key127" UNIQUE (email);


--
-- Name: Users Users_email_key128; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key128" UNIQUE (email);


--
-- Name: Users Users_email_key129; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key129" UNIQUE (email);


--
-- Name: Users Users_email_key13; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key13" UNIQUE (email);


--
-- Name: Users Users_email_key130; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key130" UNIQUE (email);


--
-- Name: Users Users_email_key131; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key131" UNIQUE (email);


--
-- Name: Users Users_email_key132; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key132" UNIQUE (email);


--
-- Name: Users Users_email_key133; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key133" UNIQUE (email);


--
-- Name: Users Users_email_key134; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key134" UNIQUE (email);


--
-- Name: Users Users_email_key135; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key135" UNIQUE (email);


--
-- Name: Users Users_email_key136; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key136" UNIQUE (email);


--
-- Name: Users Users_email_key137; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key137" UNIQUE (email);


--
-- Name: Users Users_email_key138; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key138" UNIQUE (email);


--
-- Name: Users Users_email_key139; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key139" UNIQUE (email);


--
-- Name: Users Users_email_key14; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key14" UNIQUE (email);


--
-- Name: Users Users_email_key140; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key140" UNIQUE (email);


--
-- Name: Users Users_email_key141; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key141" UNIQUE (email);


--
-- Name: Users Users_email_key142; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key142" UNIQUE (email);


--
-- Name: Users Users_email_key143; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key143" UNIQUE (email);


--
-- Name: Users Users_email_key144; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key144" UNIQUE (email);


--
-- Name: Users Users_email_key145; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key145" UNIQUE (email);


--
-- Name: Users Users_email_key146; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key146" UNIQUE (email);


--
-- Name: Users Users_email_key147; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key147" UNIQUE (email);


--
-- Name: Users Users_email_key148; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key148" UNIQUE (email);


--
-- Name: Users Users_email_key149; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key149" UNIQUE (email);


--
-- Name: Users Users_email_key15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key15" UNIQUE (email);


--
-- Name: Users Users_email_key150; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key150" UNIQUE (email);


--
-- Name: Users Users_email_key151; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key151" UNIQUE (email);


--
-- Name: Users Users_email_key152; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key152" UNIQUE (email);


--
-- Name: Users Users_email_key153; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key153" UNIQUE (email);


--
-- Name: Users Users_email_key154; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key154" UNIQUE (email);


--
-- Name: Users Users_email_key155; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key155" UNIQUE (email);


--
-- Name: Users Users_email_key156; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key156" UNIQUE (email);


--
-- Name: Users Users_email_key157; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key157" UNIQUE (email);


--
-- Name: Users Users_email_key158; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key158" UNIQUE (email);


--
-- Name: Users Users_email_key159; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key159" UNIQUE (email);


--
-- Name: Users Users_email_key16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key16" UNIQUE (email);


--
-- Name: Users Users_email_key160; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key160" UNIQUE (email);


--
-- Name: Users Users_email_key161; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key161" UNIQUE (email);


--
-- Name: Users Users_email_key162; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key162" UNIQUE (email);


--
-- Name: Users Users_email_key163; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key163" UNIQUE (email);


--
-- Name: Users Users_email_key164; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key164" UNIQUE (email);


--
-- Name: Users Users_email_key165; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key165" UNIQUE (email);


--
-- Name: Users Users_email_key166; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key166" UNIQUE (email);


--
-- Name: Users Users_email_key167; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key167" UNIQUE (email);


--
-- Name: Users Users_email_key168; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key168" UNIQUE (email);


--
-- Name: Users Users_email_key169; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key169" UNIQUE (email);


--
-- Name: Users Users_email_key17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key17" UNIQUE (email);


--
-- Name: Users Users_email_key170; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key170" UNIQUE (email);


--
-- Name: Users Users_email_key171; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key171" UNIQUE (email);


--
-- Name: Users Users_email_key172; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key172" UNIQUE (email);


--
-- Name: Users Users_email_key173; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key173" UNIQUE (email);


--
-- Name: Users Users_email_key174; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key174" UNIQUE (email);


--
-- Name: Users Users_email_key175; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key175" UNIQUE (email);


--
-- Name: Users Users_email_key176; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key176" UNIQUE (email);


--
-- Name: Users Users_email_key177; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key177" UNIQUE (email);


--
-- Name: Users Users_email_key178; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key178" UNIQUE (email);


--
-- Name: Users Users_email_key179; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key179" UNIQUE (email);


--
-- Name: Users Users_email_key18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key18" UNIQUE (email);


--
-- Name: Users Users_email_key180; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key180" UNIQUE (email);


--
-- Name: Users Users_email_key181; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key181" UNIQUE (email);


--
-- Name: Users Users_email_key182; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key182" UNIQUE (email);


--
-- Name: Users Users_email_key183; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key183" UNIQUE (email);


--
-- Name: Users Users_email_key184; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key184" UNIQUE (email);


--
-- Name: Users Users_email_key185; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key185" UNIQUE (email);


--
-- Name: Users Users_email_key186; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key186" UNIQUE (email);


--
-- Name: Users Users_email_key187; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key187" UNIQUE (email);


--
-- Name: Users Users_email_key188; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key188" UNIQUE (email);


--
-- Name: Users Users_email_key189; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key189" UNIQUE (email);


--
-- Name: Users Users_email_key19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key19" UNIQUE (email);


--
-- Name: Users Users_email_key190; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key190" UNIQUE (email);


--
-- Name: Users Users_email_key191; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key191" UNIQUE (email);


--
-- Name: Users Users_email_key192; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key192" UNIQUE (email);


--
-- Name: Users Users_email_key193; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key193" UNIQUE (email);


--
-- Name: Users Users_email_key194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key194" UNIQUE (email);


--
-- Name: Users Users_email_key195; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key195" UNIQUE (email);


--
-- Name: Users Users_email_key196; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key196" UNIQUE (email);


--
-- Name: Users Users_email_key197; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key197" UNIQUE (email);


--
-- Name: Users Users_email_key198; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key198" UNIQUE (email);


--
-- Name: Users Users_email_key199; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key199" UNIQUE (email);


--
-- Name: Users Users_email_key2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key2" UNIQUE (email);


--
-- Name: Users Users_email_key20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key20" UNIQUE (email);


--
-- Name: Users Users_email_key200; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key200" UNIQUE (email);


--
-- Name: Users Users_email_key201; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key201" UNIQUE (email);


--
-- Name: Users Users_email_key202; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key202" UNIQUE (email);


--
-- Name: Users Users_email_key203; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key203" UNIQUE (email);


--
-- Name: Users Users_email_key204; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key204" UNIQUE (email);


--
-- Name: Users Users_email_key205; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key205" UNIQUE (email);


--
-- Name: Users Users_email_key206; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key206" UNIQUE (email);


--
-- Name: Users Users_email_key207; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key207" UNIQUE (email);


--
-- Name: Users Users_email_key208; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key208" UNIQUE (email);


--
-- Name: Users Users_email_key209; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key209" UNIQUE (email);


--
-- Name: Users Users_email_key21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key21" UNIQUE (email);


--
-- Name: Users Users_email_key210; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key210" UNIQUE (email);


--
-- Name: Users Users_email_key211; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key211" UNIQUE (email);


--
-- Name: Users Users_email_key212; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key212" UNIQUE (email);


--
-- Name: Users Users_email_key213; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key213" UNIQUE (email);


--
-- Name: Users Users_email_key214; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key214" UNIQUE (email);


--
-- Name: Users Users_email_key215; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key215" UNIQUE (email);


--
-- Name: Users Users_email_key216; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key216" UNIQUE (email);


--
-- Name: Users Users_email_key217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key217" UNIQUE (email);


--
-- Name: Users Users_email_key218; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key218" UNIQUE (email);


--
-- Name: Users Users_email_key219; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key219" UNIQUE (email);


--
-- Name: Users Users_email_key22; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key22" UNIQUE (email);


--
-- Name: Users Users_email_key220; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key220" UNIQUE (email);


--
-- Name: Users Users_email_key221; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key221" UNIQUE (email);


--
-- Name: Users Users_email_key222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key222" UNIQUE (email);


--
-- Name: Users Users_email_key223; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key223" UNIQUE (email);


--
-- Name: Users Users_email_key224; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key224" UNIQUE (email);


--
-- Name: Users Users_email_key225; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key225" UNIQUE (email);


--
-- Name: Users Users_email_key226; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key226" UNIQUE (email);


--
-- Name: Users Users_email_key227; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key227" UNIQUE (email);


--
-- Name: Users Users_email_key228; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key228" UNIQUE (email);


--
-- Name: Users Users_email_key229; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key229" UNIQUE (email);


--
-- Name: Users Users_email_key23; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key23" UNIQUE (email);


--
-- Name: Users Users_email_key230; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key230" UNIQUE (email);


--
-- Name: Users Users_email_key231; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key231" UNIQUE (email);


--
-- Name: Users Users_email_key232; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key232" UNIQUE (email);


--
-- Name: Users Users_email_key233; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key233" UNIQUE (email);


--
-- Name: Users Users_email_key234; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key234" UNIQUE (email);


--
-- Name: Users Users_email_key235; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key235" UNIQUE (email);


--
-- Name: Users Users_email_key236; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key236" UNIQUE (email);


--
-- Name: Users Users_email_key237; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key237" UNIQUE (email);


--
-- Name: Users Users_email_key238; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key238" UNIQUE (email);


--
-- Name: Users Users_email_key239; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key239" UNIQUE (email);


--
-- Name: Users Users_email_key24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key24" UNIQUE (email);


--
-- Name: Users Users_email_key240; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key240" UNIQUE (email);


--
-- Name: Users Users_email_key241; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key241" UNIQUE (email);


--
-- Name: Users Users_email_key242; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key242" UNIQUE (email);


--
-- Name: Users Users_email_key243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key243" UNIQUE (email);


--
-- Name: Users Users_email_key244; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key244" UNIQUE (email);


--
-- Name: Users Users_email_key245; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key245" UNIQUE (email);


--
-- Name: Users Users_email_key246; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key246" UNIQUE (email);


--
-- Name: Users Users_email_key247; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key247" UNIQUE (email);


--
-- Name: Users Users_email_key248; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key248" UNIQUE (email);


--
-- Name: Users Users_email_key249; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key249" UNIQUE (email);


--
-- Name: Users Users_email_key25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key25" UNIQUE (email);


--
-- Name: Users Users_email_key250; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key250" UNIQUE (email);


--
-- Name: Users Users_email_key251; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key251" UNIQUE (email);


--
-- Name: Users Users_email_key252; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key252" UNIQUE (email);


--
-- Name: Users Users_email_key253; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key253" UNIQUE (email);


--
-- Name: Users Users_email_key254; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key254" UNIQUE (email);


--
-- Name: Users Users_email_key255; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key255" UNIQUE (email);


--
-- Name: Users Users_email_key256; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key256" UNIQUE (email);


--
-- Name: Users Users_email_key257; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key257" UNIQUE (email);


--
-- Name: Users Users_email_key258; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key258" UNIQUE (email);


--
-- Name: Users Users_email_key259; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key259" UNIQUE (email);


--
-- Name: Users Users_email_key26; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key26" UNIQUE (email);


--
-- Name: Users Users_email_key260; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key260" UNIQUE (email);


--
-- Name: Users Users_email_key261; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key261" UNIQUE (email);


--
-- Name: Users Users_email_key262; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key262" UNIQUE (email);


--
-- Name: Users Users_email_key263; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key263" UNIQUE (email);


--
-- Name: Users Users_email_key264; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key264" UNIQUE (email);


--
-- Name: Users Users_email_key265; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key265" UNIQUE (email);


--
-- Name: Users Users_email_key266; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key266" UNIQUE (email);


--
-- Name: Users Users_email_key267; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key267" UNIQUE (email);


--
-- Name: Users Users_email_key268; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key268" UNIQUE (email);


--
-- Name: Users Users_email_key269; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key269" UNIQUE (email);


--
-- Name: Users Users_email_key27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key27" UNIQUE (email);


--
-- Name: Users Users_email_key270; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key270" UNIQUE (email);


--
-- Name: Users Users_email_key271; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key271" UNIQUE (email);


--
-- Name: Users Users_email_key272; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key272" UNIQUE (email);


--
-- Name: Users Users_email_key273; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key273" UNIQUE (email);


--
-- Name: Users Users_email_key274; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key274" UNIQUE (email);


--
-- Name: Users Users_email_key275; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key275" UNIQUE (email);


--
-- Name: Users Users_email_key276; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key276" UNIQUE (email);


--
-- Name: Users Users_email_key277; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key277" UNIQUE (email);


--
-- Name: Users Users_email_key278; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key278" UNIQUE (email);


--
-- Name: Users Users_email_key279; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key279" UNIQUE (email);


--
-- Name: Users Users_email_key28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key28" UNIQUE (email);


--
-- Name: Users Users_email_key280; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key280" UNIQUE (email);


--
-- Name: Users Users_email_key281; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key281" UNIQUE (email);


--
-- Name: Users Users_email_key282; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key282" UNIQUE (email);


--
-- Name: Users Users_email_key283; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key283" UNIQUE (email);


--
-- Name: Users Users_email_key284; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key284" UNIQUE (email);


--
-- Name: Users Users_email_key285; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key285" UNIQUE (email);


--
-- Name: Users Users_email_key286; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key286" UNIQUE (email);


--
-- Name: Users Users_email_key287; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key287" UNIQUE (email);


--
-- Name: Users Users_email_key288; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key288" UNIQUE (email);


--
-- Name: Users Users_email_key289; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key289" UNIQUE (email);


--
-- Name: Users Users_email_key29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key29" UNIQUE (email);


--
-- Name: Users Users_email_key290; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key290" UNIQUE (email);


--
-- Name: Users Users_email_key291; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key291" UNIQUE (email);


--
-- Name: Users Users_email_key292; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key292" UNIQUE (email);


--
-- Name: Users Users_email_key293; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key293" UNIQUE (email);


--
-- Name: Users Users_email_key294; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key294" UNIQUE (email);


--
-- Name: Users Users_email_key295; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key295" UNIQUE (email);


--
-- Name: Users Users_email_key296; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key296" UNIQUE (email);


--
-- Name: Users Users_email_key297; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key297" UNIQUE (email);


--
-- Name: Users Users_email_key298; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key298" UNIQUE (email);


--
-- Name: Users Users_email_key299; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key299" UNIQUE (email);


--
-- Name: Users Users_email_key3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key3" UNIQUE (email);


--
-- Name: Users Users_email_key30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key30" UNIQUE (email);


--
-- Name: Users Users_email_key300; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key300" UNIQUE (email);


--
-- Name: Users Users_email_key301; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key301" UNIQUE (email);


--
-- Name: Users Users_email_key302; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key302" UNIQUE (email);


--
-- Name: Users Users_email_key303; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key303" UNIQUE (email);


--
-- Name: Users Users_email_key304; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key304" UNIQUE (email);


--
-- Name: Users Users_email_key305; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key305" UNIQUE (email);


--
-- Name: Users Users_email_key306; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key306" UNIQUE (email);


--
-- Name: Users Users_email_key307; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key307" UNIQUE (email);


--
-- Name: Users Users_email_key308; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key308" UNIQUE (email);


--
-- Name: Users Users_email_key309; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key309" UNIQUE (email);


--
-- Name: Users Users_email_key31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key31" UNIQUE (email);


--
-- Name: Users Users_email_key310; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key310" UNIQUE (email);


--
-- Name: Users Users_email_key311; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key311" UNIQUE (email);


--
-- Name: Users Users_email_key312; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key312" UNIQUE (email);


--
-- Name: Users Users_email_key313; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key313" UNIQUE (email);


--
-- Name: Users Users_email_key314; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key314" UNIQUE (email);


--
-- Name: Users Users_email_key315; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key315" UNIQUE (email);


--
-- Name: Users Users_email_key316; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key316" UNIQUE (email);


--
-- Name: Users Users_email_key317; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key317" UNIQUE (email);


--
-- Name: Users Users_email_key318; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key318" UNIQUE (email);


--
-- Name: Users Users_email_key319; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key319" UNIQUE (email);


--
-- Name: Users Users_email_key32; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key32" UNIQUE (email);


--
-- Name: Users Users_email_key320; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key320" UNIQUE (email);


--
-- Name: Users Users_email_key321; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key321" UNIQUE (email);


--
-- Name: Users Users_email_key322; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key322" UNIQUE (email);


--
-- Name: Users Users_email_key323; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key323" UNIQUE (email);


--
-- Name: Users Users_email_key324; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key324" UNIQUE (email);


--
-- Name: Users Users_email_key325; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key325" UNIQUE (email);


--
-- Name: Users Users_email_key326; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key326" UNIQUE (email);


--
-- Name: Users Users_email_key327; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key327" UNIQUE (email);


--
-- Name: Users Users_email_key328; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key328" UNIQUE (email);


--
-- Name: Users Users_email_key329; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key329" UNIQUE (email);


--
-- Name: Users Users_email_key33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key33" UNIQUE (email);


--
-- Name: Users Users_email_key330; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key330" UNIQUE (email);


--
-- Name: Users Users_email_key331; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key331" UNIQUE (email);


--
-- Name: Users Users_email_key332; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key332" UNIQUE (email);


--
-- Name: Users Users_email_key333; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key333" UNIQUE (email);


--
-- Name: Users Users_email_key334; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key334" UNIQUE (email);


--
-- Name: Users Users_email_key335; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key335" UNIQUE (email);


--
-- Name: Users Users_email_key336; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key336" UNIQUE (email);


--
-- Name: Users Users_email_key337; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key337" UNIQUE (email);


--
-- Name: Users Users_email_key338; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key338" UNIQUE (email);


--
-- Name: Users Users_email_key339; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key339" UNIQUE (email);


--
-- Name: Users Users_email_key34; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key34" UNIQUE (email);


--
-- Name: Users Users_email_key340; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key340" UNIQUE (email);


--
-- Name: Users Users_email_key341; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key341" UNIQUE (email);


--
-- Name: Users Users_email_key342; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key342" UNIQUE (email);


--
-- Name: Users Users_email_key343; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key343" UNIQUE (email);


--
-- Name: Users Users_email_key344; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key344" UNIQUE (email);


--
-- Name: Users Users_email_key345; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key345" UNIQUE (email);


--
-- Name: Users Users_email_key346; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key346" UNIQUE (email);


--
-- Name: Users Users_email_key347; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key347" UNIQUE (email);


--
-- Name: Users Users_email_key348; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key348" UNIQUE (email);


--
-- Name: Users Users_email_key349; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key349" UNIQUE (email);


--
-- Name: Users Users_email_key35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key35" UNIQUE (email);


--
-- Name: Users Users_email_key350; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key350" UNIQUE (email);


--
-- Name: Users Users_email_key351; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key351" UNIQUE (email);


--
-- Name: Users Users_email_key352; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key352" UNIQUE (email);


--
-- Name: Users Users_email_key353; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key353" UNIQUE (email);


--
-- Name: Users Users_email_key354; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key354" UNIQUE (email);


--
-- Name: Users Users_email_key355; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key355" UNIQUE (email);


--
-- Name: Users Users_email_key356; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key356" UNIQUE (email);


--
-- Name: Users Users_email_key357; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key357" UNIQUE (email);


--
-- Name: Users Users_email_key358; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key358" UNIQUE (email);


--
-- Name: Users Users_email_key359; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key359" UNIQUE (email);


--
-- Name: Users Users_email_key36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key36" UNIQUE (email);


--
-- Name: Users Users_email_key360; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key360" UNIQUE (email);


--
-- Name: Users Users_email_key361; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key361" UNIQUE (email);


--
-- Name: Users Users_email_key362; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key362" UNIQUE (email);


--
-- Name: Users Users_email_key363; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key363" UNIQUE (email);


--
-- Name: Users Users_email_key364; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key364" UNIQUE (email);


--
-- Name: Users Users_email_key365; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key365" UNIQUE (email);


--
-- Name: Users Users_email_key366; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key366" UNIQUE (email);


--
-- Name: Users Users_email_key367; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key367" UNIQUE (email);


--
-- Name: Users Users_email_key368; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key368" UNIQUE (email);


--
-- Name: Users Users_email_key369; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key369" UNIQUE (email);


--
-- Name: Users Users_email_key37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key37" UNIQUE (email);


--
-- Name: Users Users_email_key370; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key370" UNIQUE (email);


--
-- Name: Users Users_email_key371; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key371" UNIQUE (email);


--
-- Name: Users Users_email_key372; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key372" UNIQUE (email);


--
-- Name: Users Users_email_key373; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key373" UNIQUE (email);


--
-- Name: Users Users_email_key374; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key374" UNIQUE (email);


--
-- Name: Users Users_email_key375; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key375" UNIQUE (email);


--
-- Name: Users Users_email_key376; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key376" UNIQUE (email);


--
-- Name: Users Users_email_key377; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key377" UNIQUE (email);


--
-- Name: Users Users_email_key378; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key378" UNIQUE (email);


--
-- Name: Users Users_email_key379; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key379" UNIQUE (email);


--
-- Name: Users Users_email_key38; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key38" UNIQUE (email);


--
-- Name: Users Users_email_key380; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key380" UNIQUE (email);


--
-- Name: Users Users_email_key381; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key381" UNIQUE (email);


--
-- Name: Users Users_email_key382; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key382" UNIQUE (email);


--
-- Name: Users Users_email_key383; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key383" UNIQUE (email);


--
-- Name: Users Users_email_key384; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key384" UNIQUE (email);


--
-- Name: Users Users_email_key385; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key385" UNIQUE (email);


--
-- Name: Users Users_email_key386; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key386" UNIQUE (email);


--
-- Name: Users Users_email_key387; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key387" UNIQUE (email);


--
-- Name: Users Users_email_key388; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key388" UNIQUE (email);


--
-- Name: Users Users_email_key389; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key389" UNIQUE (email);


--
-- Name: Users Users_email_key39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key39" UNIQUE (email);


--
-- Name: Users Users_email_key390; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key390" UNIQUE (email);


--
-- Name: Users Users_email_key391; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key391" UNIQUE (email);


--
-- Name: Users Users_email_key392; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key392" UNIQUE (email);


--
-- Name: Users Users_email_key393; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key393" UNIQUE (email);


--
-- Name: Users Users_email_key394; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key394" UNIQUE (email);


--
-- Name: Users Users_email_key395; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key395" UNIQUE (email);


--
-- Name: Users Users_email_key396; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key396" UNIQUE (email);


--
-- Name: Users Users_email_key397; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key397" UNIQUE (email);


--
-- Name: Users Users_email_key398; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key398" UNIQUE (email);


--
-- Name: Users Users_email_key399; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key399" UNIQUE (email);


--
-- Name: Users Users_email_key4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key4" UNIQUE (email);


--
-- Name: Users Users_email_key40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key40" UNIQUE (email);


--
-- Name: Users Users_email_key400; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key400" UNIQUE (email);


--
-- Name: Users Users_email_key401; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key401" UNIQUE (email);


--
-- Name: Users Users_email_key402; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key402" UNIQUE (email);


--
-- Name: Users Users_email_key403; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key403" UNIQUE (email);


--
-- Name: Users Users_email_key404; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key404" UNIQUE (email);


--
-- Name: Users Users_email_key405; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key405" UNIQUE (email);


--
-- Name: Users Users_email_key406; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key406" UNIQUE (email);


--
-- Name: Users Users_email_key407; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key407" UNIQUE (email);


--
-- Name: Users Users_email_key408; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key408" UNIQUE (email);


--
-- Name: Users Users_email_key409; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key409" UNIQUE (email);


--
-- Name: Users Users_email_key41; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key41" UNIQUE (email);


--
-- Name: Users Users_email_key410; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key410" UNIQUE (email);


--
-- Name: Users Users_email_key411; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key411" UNIQUE (email);


--
-- Name: Users Users_email_key412; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key412" UNIQUE (email);


--
-- Name: Users Users_email_key413; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key413" UNIQUE (email);


--
-- Name: Users Users_email_key414; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key414" UNIQUE (email);


--
-- Name: Users Users_email_key415; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key415" UNIQUE (email);


--
-- Name: Users Users_email_key416; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key416" UNIQUE (email);


--
-- Name: Users Users_email_key417; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key417" UNIQUE (email);


--
-- Name: Users Users_email_key418; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key418" UNIQUE (email);


--
-- Name: Users Users_email_key419; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key419" UNIQUE (email);


--
-- Name: Users Users_email_key42; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key42" UNIQUE (email);


--
-- Name: Users Users_email_key420; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key420" UNIQUE (email);


--
-- Name: Users Users_email_key421; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key421" UNIQUE (email);


--
-- Name: Users Users_email_key422; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key422" UNIQUE (email);


--
-- Name: Users Users_email_key423; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key423" UNIQUE (email);


--
-- Name: Users Users_email_key424; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key424" UNIQUE (email);


--
-- Name: Users Users_email_key425; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key425" UNIQUE (email);


--
-- Name: Users Users_email_key426; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key426" UNIQUE (email);


--
-- Name: Users Users_email_key427; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key427" UNIQUE (email);


--
-- Name: Users Users_email_key428; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key428" UNIQUE (email);


--
-- Name: Users Users_email_key429; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key429" UNIQUE (email);


--
-- Name: Users Users_email_key43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key43" UNIQUE (email);


--
-- Name: Users Users_email_key430; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key430" UNIQUE (email);


--
-- Name: Users Users_email_key431; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key431" UNIQUE (email);


--
-- Name: Users Users_email_key432; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key432" UNIQUE (email);


--
-- Name: Users Users_email_key433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key433" UNIQUE (email);


--
-- Name: Users Users_email_key434; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key434" UNIQUE (email);


--
-- Name: Users Users_email_key435; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key435" UNIQUE (email);


--
-- Name: Users Users_email_key436; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key436" UNIQUE (email);


--
-- Name: Users Users_email_key437; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key437" UNIQUE (email);


--
-- Name: Users Users_email_key438; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key438" UNIQUE (email);


--
-- Name: Users Users_email_key439; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key439" UNIQUE (email);


--
-- Name: Users Users_email_key44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key44" UNIQUE (email);


--
-- Name: Users Users_email_key440; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key440" UNIQUE (email);


--
-- Name: Users Users_email_key441; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key441" UNIQUE (email);


--
-- Name: Users Users_email_key442; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key442" UNIQUE (email);


--
-- Name: Users Users_email_key443; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key443" UNIQUE (email);


--
-- Name: Users Users_email_key444; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key444" UNIQUE (email);


--
-- Name: Users Users_email_key445; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key445" UNIQUE (email);


--
-- Name: Users Users_email_key446; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key446" UNIQUE (email);


--
-- Name: Users Users_email_key447; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key447" UNIQUE (email);


--
-- Name: Users Users_email_key448; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key448" UNIQUE (email);


--
-- Name: Users Users_email_key449; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key449" UNIQUE (email);


--
-- Name: Users Users_email_key45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key45" UNIQUE (email);


--
-- Name: Users Users_email_key450; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key450" UNIQUE (email);


--
-- Name: Users Users_email_key451; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key451" UNIQUE (email);


--
-- Name: Users Users_email_key452; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key452" UNIQUE (email);


--
-- Name: Users Users_email_key453; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key453" UNIQUE (email);


--
-- Name: Users Users_email_key454; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key454" UNIQUE (email);


--
-- Name: Users Users_email_key455; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key455" UNIQUE (email);


--
-- Name: Users Users_email_key456; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key456" UNIQUE (email);


--
-- Name: Users Users_email_key457; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key457" UNIQUE (email);


--
-- Name: Users Users_email_key458; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key458" UNIQUE (email);


--
-- Name: Users Users_email_key459; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key459" UNIQUE (email);


--
-- Name: Users Users_email_key46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key46" UNIQUE (email);


--
-- Name: Users Users_email_key460; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key460" UNIQUE (email);


--
-- Name: Users Users_email_key461; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key461" UNIQUE (email);


--
-- Name: Users Users_email_key462; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key462" UNIQUE (email);


--
-- Name: Users Users_email_key463; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key463" UNIQUE (email);


--
-- Name: Users Users_email_key464; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key464" UNIQUE (email);


--
-- Name: Users Users_email_key465; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key465" UNIQUE (email);


--
-- Name: Users Users_email_key466; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key466" UNIQUE (email);


--
-- Name: Users Users_email_key467; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key467" UNIQUE (email);


--
-- Name: Users Users_email_key468; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key468" UNIQUE (email);


--
-- Name: Users Users_email_key469; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key469" UNIQUE (email);


--
-- Name: Users Users_email_key47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key47" UNIQUE (email);


--
-- Name: Users Users_email_key470; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key470" UNIQUE (email);


--
-- Name: Users Users_email_key471; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key471" UNIQUE (email);


--
-- Name: Users Users_email_key472; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key472" UNIQUE (email);


--
-- Name: Users Users_email_key473; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key473" UNIQUE (email);


--
-- Name: Users Users_email_key474; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key474" UNIQUE (email);


--
-- Name: Users Users_email_key475; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key475" UNIQUE (email);


--
-- Name: Users Users_email_key476; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key476" UNIQUE (email);


--
-- Name: Users Users_email_key477; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key477" UNIQUE (email);


--
-- Name: Users Users_email_key478; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key478" UNIQUE (email);


--
-- Name: Users Users_email_key479; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key479" UNIQUE (email);


--
-- Name: Users Users_email_key48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key48" UNIQUE (email);


--
-- Name: Users Users_email_key480; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key480" UNIQUE (email);


--
-- Name: Users Users_email_key481; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key481" UNIQUE (email);


--
-- Name: Users Users_email_key482; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key482" UNIQUE (email);


--
-- Name: Users Users_email_key483; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key483" UNIQUE (email);


--
-- Name: Users Users_email_key484; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key484" UNIQUE (email);


--
-- Name: Users Users_email_key485; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key485" UNIQUE (email);


--
-- Name: Users Users_email_key486; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key486" UNIQUE (email);


--
-- Name: Users Users_email_key487; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key487" UNIQUE (email);


--
-- Name: Users Users_email_key488; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key488" UNIQUE (email);


--
-- Name: Users Users_email_key489; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key489" UNIQUE (email);


--
-- Name: Users Users_email_key49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key49" UNIQUE (email);


--
-- Name: Users Users_email_key490; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key490" UNIQUE (email);


--
-- Name: Users Users_email_key491; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key491" UNIQUE (email);


--
-- Name: Users Users_email_key492; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key492" UNIQUE (email);


--
-- Name: Users Users_email_key493; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key493" UNIQUE (email);


--
-- Name: Users Users_email_key494; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key494" UNIQUE (email);


--
-- Name: Users Users_email_key495; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key495" UNIQUE (email);


--
-- Name: Users Users_email_key496; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key496" UNIQUE (email);


--
-- Name: Users Users_email_key497; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key497" UNIQUE (email);


--
-- Name: Users Users_email_key498; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key498" UNIQUE (email);


--
-- Name: Users Users_email_key499; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key499" UNIQUE (email);


--
-- Name: Users Users_email_key5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key5" UNIQUE (email);


--
-- Name: Users Users_email_key50; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key50" UNIQUE (email);


--
-- Name: Users Users_email_key500; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key500" UNIQUE (email);


--
-- Name: Users Users_email_key501; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key501" UNIQUE (email);


--
-- Name: Users Users_email_key502; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key502" UNIQUE (email);


--
-- Name: Users Users_email_key503; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key503" UNIQUE (email);


--
-- Name: Users Users_email_key504; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key504" UNIQUE (email);


--
-- Name: Users Users_email_key505; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key505" UNIQUE (email);


--
-- Name: Users Users_email_key506; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key506" UNIQUE (email);


--
-- Name: Users Users_email_key507; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key507" UNIQUE (email);


--
-- Name: Users Users_email_key508; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key508" UNIQUE (email);


--
-- Name: Users Users_email_key509; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key509" UNIQUE (email);


--
-- Name: Users Users_email_key51; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key51" UNIQUE (email);


--
-- Name: Users Users_email_key510; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key510" UNIQUE (email);


--
-- Name: Users Users_email_key511; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key511" UNIQUE (email);


--
-- Name: Users Users_email_key512; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key512" UNIQUE (email);


--
-- Name: Users Users_email_key513; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key513" UNIQUE (email);


--
-- Name: Users Users_email_key514; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key514" UNIQUE (email);


--
-- Name: Users Users_email_key515; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key515" UNIQUE (email);


--
-- Name: Users Users_email_key516; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key516" UNIQUE (email);


--
-- Name: Users Users_email_key517; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key517" UNIQUE (email);


--
-- Name: Users Users_email_key518; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key518" UNIQUE (email);


--
-- Name: Users Users_email_key519; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key519" UNIQUE (email);


--
-- Name: Users Users_email_key52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key52" UNIQUE (email);


--
-- Name: Users Users_email_key520; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key520" UNIQUE (email);


--
-- Name: Users Users_email_key521; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key521" UNIQUE (email);


--
-- Name: Users Users_email_key522; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key522" UNIQUE (email);


--
-- Name: Users Users_email_key523; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key523" UNIQUE (email);


--
-- Name: Users Users_email_key524; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key524" UNIQUE (email);


--
-- Name: Users Users_email_key525; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key525" UNIQUE (email);


--
-- Name: Users Users_email_key526; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key526" UNIQUE (email);


--
-- Name: Users Users_email_key527; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key527" UNIQUE (email);


--
-- Name: Users Users_email_key528; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key528" UNIQUE (email);


--
-- Name: Users Users_email_key529; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key529" UNIQUE (email);


--
-- Name: Users Users_email_key53; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key53" UNIQUE (email);


--
-- Name: Users Users_email_key530; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key530" UNIQUE (email);


--
-- Name: Users Users_email_key531; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key531" UNIQUE (email);


--
-- Name: Users Users_email_key532; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key532" UNIQUE (email);


--
-- Name: Users Users_email_key533; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key533" UNIQUE (email);


--
-- Name: Users Users_email_key534; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key534" UNIQUE (email);


--
-- Name: Users Users_email_key535; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key535" UNIQUE (email);


--
-- Name: Users Users_email_key536; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key536" UNIQUE (email);


--
-- Name: Users Users_email_key537; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key537" UNIQUE (email);


--
-- Name: Users Users_email_key538; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key538" UNIQUE (email);


--
-- Name: Users Users_email_key539; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key539" UNIQUE (email);


--
-- Name: Users Users_email_key54; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key54" UNIQUE (email);


--
-- Name: Users Users_email_key540; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key540" UNIQUE (email);


--
-- Name: Users Users_email_key541; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key541" UNIQUE (email);


--
-- Name: Users Users_email_key542; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key542" UNIQUE (email);


--
-- Name: Users Users_email_key543; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key543" UNIQUE (email);


--
-- Name: Users Users_email_key544; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key544" UNIQUE (email);


--
-- Name: Users Users_email_key545; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key545" UNIQUE (email);


--
-- Name: Users Users_email_key546; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key546" UNIQUE (email);


--
-- Name: Users Users_email_key547; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key547" UNIQUE (email);


--
-- Name: Users Users_email_key548; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key548" UNIQUE (email);


--
-- Name: Users Users_email_key549; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key549" UNIQUE (email);


--
-- Name: Users Users_email_key55; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key55" UNIQUE (email);


--
-- Name: Users Users_email_key550; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key550" UNIQUE (email);


--
-- Name: Users Users_email_key551; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key551" UNIQUE (email);


--
-- Name: Users Users_email_key552; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key552" UNIQUE (email);


--
-- Name: Users Users_email_key553; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key553" UNIQUE (email);


--
-- Name: Users Users_email_key554; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key554" UNIQUE (email);


--
-- Name: Users Users_email_key555; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key555" UNIQUE (email);


--
-- Name: Users Users_email_key556; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key556" UNIQUE (email);


--
-- Name: Users Users_email_key557; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key557" UNIQUE (email);


--
-- Name: Users Users_email_key558; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key558" UNIQUE (email);


--
-- Name: Users Users_email_key559; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key559" UNIQUE (email);


--
-- Name: Users Users_email_key56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key56" UNIQUE (email);


--
-- Name: Users Users_email_key560; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key560" UNIQUE (email);


--
-- Name: Users Users_email_key561; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key561" UNIQUE (email);


--
-- Name: Users Users_email_key562; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key562" UNIQUE (email);


--
-- Name: Users Users_email_key563; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key563" UNIQUE (email);


--
-- Name: Users Users_email_key564; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key564" UNIQUE (email);


--
-- Name: Users Users_email_key565; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key565" UNIQUE (email);


--
-- Name: Users Users_email_key566; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key566" UNIQUE (email);


--
-- Name: Users Users_email_key567; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key567" UNIQUE (email);


--
-- Name: Users Users_email_key568; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key568" UNIQUE (email);


--
-- Name: Users Users_email_key569; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key569" UNIQUE (email);


--
-- Name: Users Users_email_key57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key57" UNIQUE (email);


--
-- Name: Users Users_email_key570; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key570" UNIQUE (email);


--
-- Name: Users Users_email_key571; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key571" UNIQUE (email);


--
-- Name: Users Users_email_key572; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key572" UNIQUE (email);


--
-- Name: Users Users_email_key573; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key573" UNIQUE (email);


--
-- Name: Users Users_email_key574; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key574" UNIQUE (email);


--
-- Name: Users Users_email_key575; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key575" UNIQUE (email);


--
-- Name: Users Users_email_key576; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key576" UNIQUE (email);


--
-- Name: Users Users_email_key577; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key577" UNIQUE (email);


--
-- Name: Users Users_email_key578; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key578" UNIQUE (email);


--
-- Name: Users Users_email_key579; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key579" UNIQUE (email);


--
-- Name: Users Users_email_key58; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key58" UNIQUE (email);


--
-- Name: Users Users_email_key580; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key580" UNIQUE (email);


--
-- Name: Users Users_email_key581; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key581" UNIQUE (email);


--
-- Name: Users Users_email_key582; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key582" UNIQUE (email);


--
-- Name: Users Users_email_key583; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key583" UNIQUE (email);


--
-- Name: Users Users_email_key584; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key584" UNIQUE (email);


--
-- Name: Users Users_email_key585; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key585" UNIQUE (email);


--
-- Name: Users Users_email_key586; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key586" UNIQUE (email);


--
-- Name: Users Users_email_key587; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key587" UNIQUE (email);


--
-- Name: Users Users_email_key588; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key588" UNIQUE (email);


--
-- Name: Users Users_email_key589; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key589" UNIQUE (email);


--
-- Name: Users Users_email_key59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key59" UNIQUE (email);


--
-- Name: Users Users_email_key590; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key590" UNIQUE (email);


--
-- Name: Users Users_email_key591; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key591" UNIQUE (email);


--
-- Name: Users Users_email_key592; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key592" UNIQUE (email);


--
-- Name: Users Users_email_key593; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key593" UNIQUE (email);


--
-- Name: Users Users_email_key594; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key594" UNIQUE (email);


--
-- Name: Users Users_email_key595; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key595" UNIQUE (email);


--
-- Name: Users Users_email_key596; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key596" UNIQUE (email);


--
-- Name: Users Users_email_key597; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key597" UNIQUE (email);


--
-- Name: Users Users_email_key598; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key598" UNIQUE (email);


--
-- Name: Users Users_email_key599; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key599" UNIQUE (email);


--
-- Name: Users Users_email_key6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key6" UNIQUE (email);


--
-- Name: Users Users_email_key60; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key60" UNIQUE (email);


--
-- Name: Users Users_email_key600; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key600" UNIQUE (email);


--
-- Name: Users Users_email_key601; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key601" UNIQUE (email);


--
-- Name: Users Users_email_key602; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key602" UNIQUE (email);


--
-- Name: Users Users_email_key603; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key603" UNIQUE (email);


--
-- Name: Users Users_email_key604; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key604" UNIQUE (email);


--
-- Name: Users Users_email_key605; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key605" UNIQUE (email);


--
-- Name: Users Users_email_key606; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key606" UNIQUE (email);


--
-- Name: Users Users_email_key607; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key607" UNIQUE (email);


--
-- Name: Users Users_email_key608; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key608" UNIQUE (email);


--
-- Name: Users Users_email_key609; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key609" UNIQUE (email);


--
-- Name: Users Users_email_key61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key61" UNIQUE (email);


--
-- Name: Users Users_email_key610; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key610" UNIQUE (email);


--
-- Name: Users Users_email_key611; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key611" UNIQUE (email);


--
-- Name: Users Users_email_key612; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key612" UNIQUE (email);


--
-- Name: Users Users_email_key613; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key613" UNIQUE (email);


--
-- Name: Users Users_email_key614; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key614" UNIQUE (email);


--
-- Name: Users Users_email_key615; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key615" UNIQUE (email);


--
-- Name: Users Users_email_key616; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key616" UNIQUE (email);


--
-- Name: Users Users_email_key617; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key617" UNIQUE (email);


--
-- Name: Users Users_email_key618; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key618" UNIQUE (email);


--
-- Name: Users Users_email_key619; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key619" UNIQUE (email);


--
-- Name: Users Users_email_key62; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key62" UNIQUE (email);


--
-- Name: Users Users_email_key620; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key620" UNIQUE (email);


--
-- Name: Users Users_email_key621; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key621" UNIQUE (email);


--
-- Name: Users Users_email_key622; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key622" UNIQUE (email);


--
-- Name: Users Users_email_key623; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key623" UNIQUE (email);


--
-- Name: Users Users_email_key624; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key624" UNIQUE (email);


--
-- Name: Users Users_email_key625; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key625" UNIQUE (email);


--
-- Name: Users Users_email_key626; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key626" UNIQUE (email);


--
-- Name: Users Users_email_key627; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key627" UNIQUE (email);


--
-- Name: Users Users_email_key628; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key628" UNIQUE (email);


--
-- Name: Users Users_email_key629; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key629" UNIQUE (email);


--
-- Name: Users Users_email_key63; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key63" UNIQUE (email);


--
-- Name: Users Users_email_key630; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key630" UNIQUE (email);


--
-- Name: Users Users_email_key631; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key631" UNIQUE (email);


--
-- Name: Users Users_email_key632; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key632" UNIQUE (email);


--
-- Name: Users Users_email_key633; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key633" UNIQUE (email);


--
-- Name: Users Users_email_key634; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key634" UNIQUE (email);


--
-- Name: Users Users_email_key635; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key635" UNIQUE (email);


--
-- Name: Users Users_email_key636; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key636" UNIQUE (email);


--
-- Name: Users Users_email_key637; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key637" UNIQUE (email);


--
-- Name: Users Users_email_key638; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key638" UNIQUE (email);


--
-- Name: Users Users_email_key639; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key639" UNIQUE (email);


--
-- Name: Users Users_email_key64; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key64" UNIQUE (email);


--
-- Name: Users Users_email_key640; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key640" UNIQUE (email);


--
-- Name: Users Users_email_key641; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key641" UNIQUE (email);


--
-- Name: Users Users_email_key642; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key642" UNIQUE (email);


--
-- Name: Users Users_email_key643; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key643" UNIQUE (email);


--
-- Name: Users Users_email_key644; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key644" UNIQUE (email);


--
-- Name: Users Users_email_key645; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key645" UNIQUE (email);


--
-- Name: Users Users_email_key646; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key646" UNIQUE (email);


--
-- Name: Users Users_email_key647; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key647" UNIQUE (email);


--
-- Name: Users Users_email_key648; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key648" UNIQUE (email);


--
-- Name: Users Users_email_key649; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key649" UNIQUE (email);


--
-- Name: Users Users_email_key65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key65" UNIQUE (email);


--
-- Name: Users Users_email_key650; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key650" UNIQUE (email);


--
-- Name: Users Users_email_key651; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key651" UNIQUE (email);


--
-- Name: Users Users_email_key652; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key652" UNIQUE (email);


--
-- Name: Users Users_email_key653; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key653" UNIQUE (email);


--
-- Name: Users Users_email_key654; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key654" UNIQUE (email);


--
-- Name: Users Users_email_key655; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key655" UNIQUE (email);


--
-- Name: Users Users_email_key656; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key656" UNIQUE (email);


--
-- Name: Users Users_email_key657; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key657" UNIQUE (email);


--
-- Name: Users Users_email_key658; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key658" UNIQUE (email);


--
-- Name: Users Users_email_key659; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key659" UNIQUE (email);


--
-- Name: Users Users_email_key66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key66" UNIQUE (email);


--
-- Name: Users Users_email_key660; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key660" UNIQUE (email);


--
-- Name: Users Users_email_key661; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key661" UNIQUE (email);


--
-- Name: Users Users_email_key662; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key662" UNIQUE (email);


--
-- Name: Users Users_email_key663; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key663" UNIQUE (email);


--
-- Name: Users Users_email_key664; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key664" UNIQUE (email);


--
-- Name: Users Users_email_key665; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key665" UNIQUE (email);


--
-- Name: Users Users_email_key666; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key666" UNIQUE (email);


--
-- Name: Users Users_email_key667; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key667" UNIQUE (email);


--
-- Name: Users Users_email_key67; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key67" UNIQUE (email);


--
-- Name: Users Users_email_key68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key68" UNIQUE (email);


--
-- Name: Users Users_email_key69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key69" UNIQUE (email);


--
-- Name: Users Users_email_key7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key7" UNIQUE (email);


--
-- Name: Users Users_email_key70; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key70" UNIQUE (email);


--
-- Name: Users Users_email_key71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key71" UNIQUE (email);


--
-- Name: Users Users_email_key72; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key72" UNIQUE (email);


--
-- Name: Users Users_email_key73; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key73" UNIQUE (email);


--
-- Name: Users Users_email_key74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key74" UNIQUE (email);


--
-- Name: Users Users_email_key75; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key75" UNIQUE (email);


--
-- Name: Users Users_email_key76; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key76" UNIQUE (email);


--
-- Name: Users Users_email_key77; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key77" UNIQUE (email);


--
-- Name: Users Users_email_key78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key78" UNIQUE (email);


--
-- Name: Users Users_email_key79; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key79" UNIQUE (email);


--
-- Name: Users Users_email_key8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key8" UNIQUE (email);


--
-- Name: Users Users_email_key80; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key80" UNIQUE (email);


--
-- Name: Users Users_email_key81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key81" UNIQUE (email);


--
-- Name: Users Users_email_key82; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key82" UNIQUE (email);


--
-- Name: Users Users_email_key83; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key83" UNIQUE (email);


--
-- Name: Users Users_email_key84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key84" UNIQUE (email);


--
-- Name: Users Users_email_key85; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key85" UNIQUE (email);


--
-- Name: Users Users_email_key86; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key86" UNIQUE (email);


--
-- Name: Users Users_email_key87; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key87" UNIQUE (email);


--
-- Name: Users Users_email_key88; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key88" UNIQUE (email);


--
-- Name: Users Users_email_key89; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key89" UNIQUE (email);


--
-- Name: Users Users_email_key9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key9" UNIQUE (email);


--
-- Name: Users Users_email_key90; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key90" UNIQUE (email);


--
-- Name: Users Users_email_key91; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key91" UNIQUE (email);


--
-- Name: Users Users_email_key92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key92" UNIQUE (email);


--
-- Name: Users Users_email_key93; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key93" UNIQUE (email);


--
-- Name: Users Users_email_key94; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key94" UNIQUE (email);


--
-- Name: Users Users_email_key95; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key95" UNIQUE (email);


--
-- Name: Users Users_email_key96; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key96" UNIQUE (email);


--
-- Name: Users Users_email_key97; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key97" UNIQUE (email);


--
-- Name: Users Users_email_key98; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key98" UNIQUE (email);


--
-- Name: Users Users_email_key99; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_email_key99" UNIQUE (email);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key" UNIQUE (username);


--
-- Name: Users Users_username_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key1" UNIQUE (username);


--
-- Name: Users Users_username_key10; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key10" UNIQUE (username);


--
-- Name: Users Users_username_key100; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key100" UNIQUE (username);


--
-- Name: Users Users_username_key101; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key101" UNIQUE (username);


--
-- Name: Users Users_username_key102; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key102" UNIQUE (username);


--
-- Name: Users Users_username_key103; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key103" UNIQUE (username);


--
-- Name: Users Users_username_key104; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key104" UNIQUE (username);


--
-- Name: Users Users_username_key105; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key105" UNIQUE (username);


--
-- Name: Users Users_username_key106; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key106" UNIQUE (username);


--
-- Name: Users Users_username_key107; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key107" UNIQUE (username);


--
-- Name: Users Users_username_key108; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key108" UNIQUE (username);


--
-- Name: Users Users_username_key109; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key109" UNIQUE (username);


--
-- Name: Users Users_username_key11; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key11" UNIQUE (username);


--
-- Name: Users Users_username_key110; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key110" UNIQUE (username);


--
-- Name: Users Users_username_key111; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key111" UNIQUE (username);


--
-- Name: Users Users_username_key112; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key112" UNIQUE (username);


--
-- Name: Users Users_username_key113; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key113" UNIQUE (username);


--
-- Name: Users Users_username_key114; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key114" UNIQUE (username);


--
-- Name: Users Users_username_key115; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key115" UNIQUE (username);


--
-- Name: Users Users_username_key116; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key116" UNIQUE (username);


--
-- Name: Users Users_username_key117; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key117" UNIQUE (username);


--
-- Name: Users Users_username_key118; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key118" UNIQUE (username);


--
-- Name: Users Users_username_key119; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key119" UNIQUE (username);


--
-- Name: Users Users_username_key12; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key12" UNIQUE (username);


--
-- Name: Users Users_username_key120; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key120" UNIQUE (username);


--
-- Name: Users Users_username_key121; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key121" UNIQUE (username);


--
-- Name: Users Users_username_key122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key122" UNIQUE (username);


--
-- Name: Users Users_username_key123; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key123" UNIQUE (username);


--
-- Name: Users Users_username_key124; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key124" UNIQUE (username);


--
-- Name: Users Users_username_key125; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key125" UNIQUE (username);


--
-- Name: Users Users_username_key126; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key126" UNIQUE (username);


--
-- Name: Users Users_username_key127; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key127" UNIQUE (username);


--
-- Name: Users Users_username_key128; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key128" UNIQUE (username);


--
-- Name: Users Users_username_key129; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key129" UNIQUE (username);


--
-- Name: Users Users_username_key13; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key13" UNIQUE (username);


--
-- Name: Users Users_username_key130; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key130" UNIQUE (username);


--
-- Name: Users Users_username_key131; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key131" UNIQUE (username);


--
-- Name: Users Users_username_key132; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key132" UNIQUE (username);


--
-- Name: Users Users_username_key133; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key133" UNIQUE (username);


--
-- Name: Users Users_username_key134; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key134" UNIQUE (username);


--
-- Name: Users Users_username_key135; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key135" UNIQUE (username);


--
-- Name: Users Users_username_key136; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key136" UNIQUE (username);


--
-- Name: Users Users_username_key137; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key137" UNIQUE (username);


--
-- Name: Users Users_username_key138; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key138" UNIQUE (username);


--
-- Name: Users Users_username_key139; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key139" UNIQUE (username);


--
-- Name: Users Users_username_key14; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key14" UNIQUE (username);


--
-- Name: Users Users_username_key140; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key140" UNIQUE (username);


--
-- Name: Users Users_username_key141; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key141" UNIQUE (username);


--
-- Name: Users Users_username_key142; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key142" UNIQUE (username);


--
-- Name: Users Users_username_key143; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key143" UNIQUE (username);


--
-- Name: Users Users_username_key144; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key144" UNIQUE (username);


--
-- Name: Users Users_username_key145; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key145" UNIQUE (username);


--
-- Name: Users Users_username_key146; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key146" UNIQUE (username);


--
-- Name: Users Users_username_key147; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key147" UNIQUE (username);


--
-- Name: Users Users_username_key148; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key148" UNIQUE (username);


--
-- Name: Users Users_username_key149; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key149" UNIQUE (username);


--
-- Name: Users Users_username_key15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key15" UNIQUE (username);


--
-- Name: Users Users_username_key150; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key150" UNIQUE (username);


--
-- Name: Users Users_username_key151; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key151" UNIQUE (username);


--
-- Name: Users Users_username_key152; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key152" UNIQUE (username);


--
-- Name: Users Users_username_key153; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key153" UNIQUE (username);


--
-- Name: Users Users_username_key154; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key154" UNIQUE (username);


--
-- Name: Users Users_username_key155; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key155" UNIQUE (username);


--
-- Name: Users Users_username_key156; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key156" UNIQUE (username);


--
-- Name: Users Users_username_key157; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key157" UNIQUE (username);


--
-- Name: Users Users_username_key158; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key158" UNIQUE (username);


--
-- Name: Users Users_username_key159; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key159" UNIQUE (username);


--
-- Name: Users Users_username_key16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key16" UNIQUE (username);


--
-- Name: Users Users_username_key160; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key160" UNIQUE (username);


--
-- Name: Users Users_username_key161; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key161" UNIQUE (username);


--
-- Name: Users Users_username_key162; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key162" UNIQUE (username);


--
-- Name: Users Users_username_key163; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key163" UNIQUE (username);


--
-- Name: Users Users_username_key164; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key164" UNIQUE (username);


--
-- Name: Users Users_username_key165; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key165" UNIQUE (username);


--
-- Name: Users Users_username_key166; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key166" UNIQUE (username);


--
-- Name: Users Users_username_key167; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key167" UNIQUE (username);


--
-- Name: Users Users_username_key168; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key168" UNIQUE (username);


--
-- Name: Users Users_username_key169; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key169" UNIQUE (username);


--
-- Name: Users Users_username_key17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key17" UNIQUE (username);


--
-- Name: Users Users_username_key170; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key170" UNIQUE (username);


--
-- Name: Users Users_username_key171; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key171" UNIQUE (username);


--
-- Name: Users Users_username_key172; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key172" UNIQUE (username);


--
-- Name: Users Users_username_key173; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key173" UNIQUE (username);


--
-- Name: Users Users_username_key174; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key174" UNIQUE (username);


--
-- Name: Users Users_username_key175; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key175" UNIQUE (username);


--
-- Name: Users Users_username_key176; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key176" UNIQUE (username);


--
-- Name: Users Users_username_key177; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key177" UNIQUE (username);


--
-- Name: Users Users_username_key178; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key178" UNIQUE (username);


--
-- Name: Users Users_username_key179; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key179" UNIQUE (username);


--
-- Name: Users Users_username_key18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key18" UNIQUE (username);


--
-- Name: Users Users_username_key180; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key180" UNIQUE (username);


--
-- Name: Users Users_username_key181; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key181" UNIQUE (username);


--
-- Name: Users Users_username_key182; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key182" UNIQUE (username);


--
-- Name: Users Users_username_key183; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key183" UNIQUE (username);


--
-- Name: Users Users_username_key184; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key184" UNIQUE (username);


--
-- Name: Users Users_username_key185; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key185" UNIQUE (username);


--
-- Name: Users Users_username_key186; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key186" UNIQUE (username);


--
-- Name: Users Users_username_key187; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key187" UNIQUE (username);


--
-- Name: Users Users_username_key188; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key188" UNIQUE (username);


--
-- Name: Users Users_username_key189; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key189" UNIQUE (username);


--
-- Name: Users Users_username_key19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key19" UNIQUE (username);


--
-- Name: Users Users_username_key190; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key190" UNIQUE (username);


--
-- Name: Users Users_username_key191; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key191" UNIQUE (username);


--
-- Name: Users Users_username_key192; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key192" UNIQUE (username);


--
-- Name: Users Users_username_key193; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key193" UNIQUE (username);


--
-- Name: Users Users_username_key194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key194" UNIQUE (username);


--
-- Name: Users Users_username_key195; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key195" UNIQUE (username);


--
-- Name: Users Users_username_key196; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key196" UNIQUE (username);


--
-- Name: Users Users_username_key197; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key197" UNIQUE (username);


--
-- Name: Users Users_username_key198; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key198" UNIQUE (username);


--
-- Name: Users Users_username_key199; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key199" UNIQUE (username);


--
-- Name: Users Users_username_key2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key2" UNIQUE (username);


--
-- Name: Users Users_username_key20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key20" UNIQUE (username);


--
-- Name: Users Users_username_key200; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key200" UNIQUE (username);


--
-- Name: Users Users_username_key201; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key201" UNIQUE (username);


--
-- Name: Users Users_username_key202; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key202" UNIQUE (username);


--
-- Name: Users Users_username_key203; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key203" UNIQUE (username);


--
-- Name: Users Users_username_key204; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key204" UNIQUE (username);


--
-- Name: Users Users_username_key205; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key205" UNIQUE (username);


--
-- Name: Users Users_username_key206; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key206" UNIQUE (username);


--
-- Name: Users Users_username_key207; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key207" UNIQUE (username);


--
-- Name: Users Users_username_key208; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key208" UNIQUE (username);


--
-- Name: Users Users_username_key209; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key209" UNIQUE (username);


--
-- Name: Users Users_username_key21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key21" UNIQUE (username);


--
-- Name: Users Users_username_key210; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key210" UNIQUE (username);


--
-- Name: Users Users_username_key211; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key211" UNIQUE (username);


--
-- Name: Users Users_username_key212; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key212" UNIQUE (username);


--
-- Name: Users Users_username_key213; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key213" UNIQUE (username);


--
-- Name: Users Users_username_key214; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key214" UNIQUE (username);


--
-- Name: Users Users_username_key215; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key215" UNIQUE (username);


--
-- Name: Users Users_username_key216; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key216" UNIQUE (username);


--
-- Name: Users Users_username_key217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key217" UNIQUE (username);


--
-- Name: Users Users_username_key218; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key218" UNIQUE (username);


--
-- Name: Users Users_username_key219; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key219" UNIQUE (username);


--
-- Name: Users Users_username_key22; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key22" UNIQUE (username);


--
-- Name: Users Users_username_key220; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key220" UNIQUE (username);


--
-- Name: Users Users_username_key221; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key221" UNIQUE (username);


--
-- Name: Users Users_username_key222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key222" UNIQUE (username);


--
-- Name: Users Users_username_key223; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key223" UNIQUE (username);


--
-- Name: Users Users_username_key224; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key224" UNIQUE (username);


--
-- Name: Users Users_username_key225; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key225" UNIQUE (username);


--
-- Name: Users Users_username_key226; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key226" UNIQUE (username);


--
-- Name: Users Users_username_key227; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key227" UNIQUE (username);


--
-- Name: Users Users_username_key228; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key228" UNIQUE (username);


--
-- Name: Users Users_username_key229; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key229" UNIQUE (username);


--
-- Name: Users Users_username_key23; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key23" UNIQUE (username);


--
-- Name: Users Users_username_key230; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key230" UNIQUE (username);


--
-- Name: Users Users_username_key231; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key231" UNIQUE (username);


--
-- Name: Users Users_username_key232; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key232" UNIQUE (username);


--
-- Name: Users Users_username_key233; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key233" UNIQUE (username);


--
-- Name: Users Users_username_key234; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key234" UNIQUE (username);


--
-- Name: Users Users_username_key235; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key235" UNIQUE (username);


--
-- Name: Users Users_username_key236; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key236" UNIQUE (username);


--
-- Name: Users Users_username_key237; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key237" UNIQUE (username);


--
-- Name: Users Users_username_key238; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key238" UNIQUE (username);


--
-- Name: Users Users_username_key239; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key239" UNIQUE (username);


--
-- Name: Users Users_username_key24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key24" UNIQUE (username);


--
-- Name: Users Users_username_key240; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key240" UNIQUE (username);


--
-- Name: Users Users_username_key241; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key241" UNIQUE (username);


--
-- Name: Users Users_username_key242; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key242" UNIQUE (username);


--
-- Name: Users Users_username_key243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key243" UNIQUE (username);


--
-- Name: Users Users_username_key244; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key244" UNIQUE (username);


--
-- Name: Users Users_username_key245; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key245" UNIQUE (username);


--
-- Name: Users Users_username_key246; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key246" UNIQUE (username);


--
-- Name: Users Users_username_key247; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key247" UNIQUE (username);


--
-- Name: Users Users_username_key248; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key248" UNIQUE (username);


--
-- Name: Users Users_username_key249; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key249" UNIQUE (username);


--
-- Name: Users Users_username_key25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key25" UNIQUE (username);


--
-- Name: Users Users_username_key250; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key250" UNIQUE (username);


--
-- Name: Users Users_username_key251; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key251" UNIQUE (username);


--
-- Name: Users Users_username_key252; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key252" UNIQUE (username);


--
-- Name: Users Users_username_key253; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key253" UNIQUE (username);


--
-- Name: Users Users_username_key254; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key254" UNIQUE (username);


--
-- Name: Users Users_username_key255; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key255" UNIQUE (username);


--
-- Name: Users Users_username_key256; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key256" UNIQUE (username);


--
-- Name: Users Users_username_key257; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key257" UNIQUE (username);


--
-- Name: Users Users_username_key258; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key258" UNIQUE (username);


--
-- Name: Users Users_username_key259; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key259" UNIQUE (username);


--
-- Name: Users Users_username_key26; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key26" UNIQUE (username);


--
-- Name: Users Users_username_key260; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key260" UNIQUE (username);


--
-- Name: Users Users_username_key261; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key261" UNIQUE (username);


--
-- Name: Users Users_username_key262; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key262" UNIQUE (username);


--
-- Name: Users Users_username_key263; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key263" UNIQUE (username);


--
-- Name: Users Users_username_key264; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key264" UNIQUE (username);


--
-- Name: Users Users_username_key265; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key265" UNIQUE (username);


--
-- Name: Users Users_username_key266; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key266" UNIQUE (username);


--
-- Name: Users Users_username_key267; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key267" UNIQUE (username);


--
-- Name: Users Users_username_key268; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key268" UNIQUE (username);


--
-- Name: Users Users_username_key269; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key269" UNIQUE (username);


--
-- Name: Users Users_username_key27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key27" UNIQUE (username);


--
-- Name: Users Users_username_key270; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key270" UNIQUE (username);


--
-- Name: Users Users_username_key271; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key271" UNIQUE (username);


--
-- Name: Users Users_username_key272; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key272" UNIQUE (username);


--
-- Name: Users Users_username_key273; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key273" UNIQUE (username);


--
-- Name: Users Users_username_key274; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key274" UNIQUE (username);


--
-- Name: Users Users_username_key275; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key275" UNIQUE (username);


--
-- Name: Users Users_username_key276; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key276" UNIQUE (username);


--
-- Name: Users Users_username_key277; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key277" UNIQUE (username);


--
-- Name: Users Users_username_key278; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key278" UNIQUE (username);


--
-- Name: Users Users_username_key279; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key279" UNIQUE (username);


--
-- Name: Users Users_username_key28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key28" UNIQUE (username);


--
-- Name: Users Users_username_key280; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key280" UNIQUE (username);


--
-- Name: Users Users_username_key281; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key281" UNIQUE (username);


--
-- Name: Users Users_username_key282; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key282" UNIQUE (username);


--
-- Name: Users Users_username_key283; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key283" UNIQUE (username);


--
-- Name: Users Users_username_key284; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key284" UNIQUE (username);


--
-- Name: Users Users_username_key285; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key285" UNIQUE (username);


--
-- Name: Users Users_username_key286; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key286" UNIQUE (username);


--
-- Name: Users Users_username_key287; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key287" UNIQUE (username);


--
-- Name: Users Users_username_key288; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key288" UNIQUE (username);


--
-- Name: Users Users_username_key289; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key289" UNIQUE (username);


--
-- Name: Users Users_username_key29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key29" UNIQUE (username);


--
-- Name: Users Users_username_key290; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key290" UNIQUE (username);


--
-- Name: Users Users_username_key291; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key291" UNIQUE (username);


--
-- Name: Users Users_username_key292; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key292" UNIQUE (username);


--
-- Name: Users Users_username_key293; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key293" UNIQUE (username);


--
-- Name: Users Users_username_key294; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key294" UNIQUE (username);


--
-- Name: Users Users_username_key295; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key295" UNIQUE (username);


--
-- Name: Users Users_username_key296; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key296" UNIQUE (username);


--
-- Name: Users Users_username_key297; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key297" UNIQUE (username);


--
-- Name: Users Users_username_key298; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key298" UNIQUE (username);


--
-- Name: Users Users_username_key299; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key299" UNIQUE (username);


--
-- Name: Users Users_username_key3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key3" UNIQUE (username);


--
-- Name: Users Users_username_key30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key30" UNIQUE (username);


--
-- Name: Users Users_username_key300; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key300" UNIQUE (username);


--
-- Name: Users Users_username_key301; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key301" UNIQUE (username);


--
-- Name: Users Users_username_key302; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key302" UNIQUE (username);


--
-- Name: Users Users_username_key303; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key303" UNIQUE (username);


--
-- Name: Users Users_username_key304; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key304" UNIQUE (username);


--
-- Name: Users Users_username_key305; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key305" UNIQUE (username);


--
-- Name: Users Users_username_key306; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key306" UNIQUE (username);


--
-- Name: Users Users_username_key307; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key307" UNIQUE (username);


--
-- Name: Users Users_username_key308; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key308" UNIQUE (username);


--
-- Name: Users Users_username_key309; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key309" UNIQUE (username);


--
-- Name: Users Users_username_key31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key31" UNIQUE (username);


--
-- Name: Users Users_username_key310; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key310" UNIQUE (username);


--
-- Name: Users Users_username_key311; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key311" UNIQUE (username);


--
-- Name: Users Users_username_key312; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key312" UNIQUE (username);


--
-- Name: Users Users_username_key313; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key313" UNIQUE (username);


--
-- Name: Users Users_username_key314; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key314" UNIQUE (username);


--
-- Name: Users Users_username_key315; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key315" UNIQUE (username);


--
-- Name: Users Users_username_key316; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key316" UNIQUE (username);


--
-- Name: Users Users_username_key317; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key317" UNIQUE (username);


--
-- Name: Users Users_username_key318; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key318" UNIQUE (username);


--
-- Name: Users Users_username_key319; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key319" UNIQUE (username);


--
-- Name: Users Users_username_key32; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key32" UNIQUE (username);


--
-- Name: Users Users_username_key320; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key320" UNIQUE (username);


--
-- Name: Users Users_username_key321; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key321" UNIQUE (username);


--
-- Name: Users Users_username_key322; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key322" UNIQUE (username);


--
-- Name: Users Users_username_key323; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key323" UNIQUE (username);


--
-- Name: Users Users_username_key324; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key324" UNIQUE (username);


--
-- Name: Users Users_username_key325; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key325" UNIQUE (username);


--
-- Name: Users Users_username_key326; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key326" UNIQUE (username);


--
-- Name: Users Users_username_key327; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key327" UNIQUE (username);


--
-- Name: Users Users_username_key328; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key328" UNIQUE (username);


--
-- Name: Users Users_username_key329; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key329" UNIQUE (username);


--
-- Name: Users Users_username_key33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key33" UNIQUE (username);


--
-- Name: Users Users_username_key330; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key330" UNIQUE (username);


--
-- Name: Users Users_username_key331; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key331" UNIQUE (username);


--
-- Name: Users Users_username_key332; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key332" UNIQUE (username);


--
-- Name: Users Users_username_key333; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key333" UNIQUE (username);


--
-- Name: Users Users_username_key334; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key334" UNIQUE (username);


--
-- Name: Users Users_username_key335; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key335" UNIQUE (username);


--
-- Name: Users Users_username_key336; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key336" UNIQUE (username);


--
-- Name: Users Users_username_key337; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key337" UNIQUE (username);


--
-- Name: Users Users_username_key338; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key338" UNIQUE (username);


--
-- Name: Users Users_username_key339; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key339" UNIQUE (username);


--
-- Name: Users Users_username_key34; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key34" UNIQUE (username);


--
-- Name: Users Users_username_key340; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key340" UNIQUE (username);


--
-- Name: Users Users_username_key341; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key341" UNIQUE (username);


--
-- Name: Users Users_username_key342; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key342" UNIQUE (username);


--
-- Name: Users Users_username_key343; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key343" UNIQUE (username);


--
-- Name: Users Users_username_key344; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key344" UNIQUE (username);


--
-- Name: Users Users_username_key345; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key345" UNIQUE (username);


--
-- Name: Users Users_username_key346; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key346" UNIQUE (username);


--
-- Name: Users Users_username_key347; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key347" UNIQUE (username);


--
-- Name: Users Users_username_key348; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key348" UNIQUE (username);


--
-- Name: Users Users_username_key349; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key349" UNIQUE (username);


--
-- Name: Users Users_username_key35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key35" UNIQUE (username);


--
-- Name: Users Users_username_key350; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key350" UNIQUE (username);


--
-- Name: Users Users_username_key351; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key351" UNIQUE (username);


--
-- Name: Users Users_username_key352; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key352" UNIQUE (username);


--
-- Name: Users Users_username_key353; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key353" UNIQUE (username);


--
-- Name: Users Users_username_key354; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key354" UNIQUE (username);


--
-- Name: Users Users_username_key355; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key355" UNIQUE (username);


--
-- Name: Users Users_username_key356; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key356" UNIQUE (username);


--
-- Name: Users Users_username_key357; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key357" UNIQUE (username);


--
-- Name: Users Users_username_key358; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key358" UNIQUE (username);


--
-- Name: Users Users_username_key359; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key359" UNIQUE (username);


--
-- Name: Users Users_username_key36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key36" UNIQUE (username);


--
-- Name: Users Users_username_key360; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key360" UNIQUE (username);


--
-- Name: Users Users_username_key361; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key361" UNIQUE (username);


--
-- Name: Users Users_username_key362; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key362" UNIQUE (username);


--
-- Name: Users Users_username_key363; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key363" UNIQUE (username);


--
-- Name: Users Users_username_key364; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key364" UNIQUE (username);


--
-- Name: Users Users_username_key365; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key365" UNIQUE (username);


--
-- Name: Users Users_username_key366; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key366" UNIQUE (username);


--
-- Name: Users Users_username_key367; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key367" UNIQUE (username);


--
-- Name: Users Users_username_key368; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key368" UNIQUE (username);


--
-- Name: Users Users_username_key369; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key369" UNIQUE (username);


--
-- Name: Users Users_username_key37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key37" UNIQUE (username);


--
-- Name: Users Users_username_key370; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key370" UNIQUE (username);


--
-- Name: Users Users_username_key371; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key371" UNIQUE (username);


--
-- Name: Users Users_username_key372; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key372" UNIQUE (username);


--
-- Name: Users Users_username_key373; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key373" UNIQUE (username);


--
-- Name: Users Users_username_key374; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key374" UNIQUE (username);


--
-- Name: Users Users_username_key375; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key375" UNIQUE (username);


--
-- Name: Users Users_username_key376; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key376" UNIQUE (username);


--
-- Name: Users Users_username_key377; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key377" UNIQUE (username);


--
-- Name: Users Users_username_key378; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key378" UNIQUE (username);


--
-- Name: Users Users_username_key379; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key379" UNIQUE (username);


--
-- Name: Users Users_username_key38; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key38" UNIQUE (username);


--
-- Name: Users Users_username_key380; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key380" UNIQUE (username);


--
-- Name: Users Users_username_key381; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key381" UNIQUE (username);


--
-- Name: Users Users_username_key382; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key382" UNIQUE (username);


--
-- Name: Users Users_username_key383; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key383" UNIQUE (username);


--
-- Name: Users Users_username_key384; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key384" UNIQUE (username);


--
-- Name: Users Users_username_key385; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key385" UNIQUE (username);


--
-- Name: Users Users_username_key386; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key386" UNIQUE (username);


--
-- Name: Users Users_username_key387; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key387" UNIQUE (username);


--
-- Name: Users Users_username_key388; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key388" UNIQUE (username);


--
-- Name: Users Users_username_key389; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key389" UNIQUE (username);


--
-- Name: Users Users_username_key39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key39" UNIQUE (username);


--
-- Name: Users Users_username_key390; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key390" UNIQUE (username);


--
-- Name: Users Users_username_key391; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key391" UNIQUE (username);


--
-- Name: Users Users_username_key392; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key392" UNIQUE (username);


--
-- Name: Users Users_username_key393; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key393" UNIQUE (username);


--
-- Name: Users Users_username_key394; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key394" UNIQUE (username);


--
-- Name: Users Users_username_key395; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key395" UNIQUE (username);


--
-- Name: Users Users_username_key396; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key396" UNIQUE (username);


--
-- Name: Users Users_username_key397; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key397" UNIQUE (username);


--
-- Name: Users Users_username_key398; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key398" UNIQUE (username);


--
-- Name: Users Users_username_key399; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key399" UNIQUE (username);


--
-- Name: Users Users_username_key4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key4" UNIQUE (username);


--
-- Name: Users Users_username_key40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key40" UNIQUE (username);


--
-- Name: Users Users_username_key400; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key400" UNIQUE (username);


--
-- Name: Users Users_username_key401; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key401" UNIQUE (username);


--
-- Name: Users Users_username_key402; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key402" UNIQUE (username);


--
-- Name: Users Users_username_key403; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key403" UNIQUE (username);


--
-- Name: Users Users_username_key404; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key404" UNIQUE (username);


--
-- Name: Users Users_username_key405; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key405" UNIQUE (username);


--
-- Name: Users Users_username_key406; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key406" UNIQUE (username);


--
-- Name: Users Users_username_key407; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key407" UNIQUE (username);


--
-- Name: Users Users_username_key408; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key408" UNIQUE (username);


--
-- Name: Users Users_username_key409; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key409" UNIQUE (username);


--
-- Name: Users Users_username_key41; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key41" UNIQUE (username);


--
-- Name: Users Users_username_key410; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key410" UNIQUE (username);


--
-- Name: Users Users_username_key411; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key411" UNIQUE (username);


--
-- Name: Users Users_username_key412; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key412" UNIQUE (username);


--
-- Name: Users Users_username_key413; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key413" UNIQUE (username);


--
-- Name: Users Users_username_key414; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key414" UNIQUE (username);


--
-- Name: Users Users_username_key415; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key415" UNIQUE (username);


--
-- Name: Users Users_username_key416; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key416" UNIQUE (username);


--
-- Name: Users Users_username_key417; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key417" UNIQUE (username);


--
-- Name: Users Users_username_key418; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key418" UNIQUE (username);


--
-- Name: Users Users_username_key419; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key419" UNIQUE (username);


--
-- Name: Users Users_username_key42; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key42" UNIQUE (username);


--
-- Name: Users Users_username_key420; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key420" UNIQUE (username);


--
-- Name: Users Users_username_key421; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key421" UNIQUE (username);


--
-- Name: Users Users_username_key422; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key422" UNIQUE (username);


--
-- Name: Users Users_username_key423; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key423" UNIQUE (username);


--
-- Name: Users Users_username_key424; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key424" UNIQUE (username);


--
-- Name: Users Users_username_key425; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key425" UNIQUE (username);


--
-- Name: Users Users_username_key426; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key426" UNIQUE (username);


--
-- Name: Users Users_username_key427; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key427" UNIQUE (username);


--
-- Name: Users Users_username_key428; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key428" UNIQUE (username);


--
-- Name: Users Users_username_key429; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key429" UNIQUE (username);


--
-- Name: Users Users_username_key43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key43" UNIQUE (username);


--
-- Name: Users Users_username_key430; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key430" UNIQUE (username);


--
-- Name: Users Users_username_key431; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key431" UNIQUE (username);


--
-- Name: Users Users_username_key432; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key432" UNIQUE (username);


--
-- Name: Users Users_username_key433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key433" UNIQUE (username);


--
-- Name: Users Users_username_key434; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key434" UNIQUE (username);


--
-- Name: Users Users_username_key435; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key435" UNIQUE (username);


--
-- Name: Users Users_username_key436; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key436" UNIQUE (username);


--
-- Name: Users Users_username_key437; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key437" UNIQUE (username);


--
-- Name: Users Users_username_key438; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key438" UNIQUE (username);


--
-- Name: Users Users_username_key439; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key439" UNIQUE (username);


--
-- Name: Users Users_username_key44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key44" UNIQUE (username);


--
-- Name: Users Users_username_key440; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key440" UNIQUE (username);


--
-- Name: Users Users_username_key441; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key441" UNIQUE (username);


--
-- Name: Users Users_username_key442; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key442" UNIQUE (username);


--
-- Name: Users Users_username_key443; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key443" UNIQUE (username);


--
-- Name: Users Users_username_key444; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key444" UNIQUE (username);


--
-- Name: Users Users_username_key445; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key445" UNIQUE (username);


--
-- Name: Users Users_username_key446; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key446" UNIQUE (username);


--
-- Name: Users Users_username_key447; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key447" UNIQUE (username);


--
-- Name: Users Users_username_key448; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key448" UNIQUE (username);


--
-- Name: Users Users_username_key449; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key449" UNIQUE (username);


--
-- Name: Users Users_username_key45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key45" UNIQUE (username);


--
-- Name: Users Users_username_key450; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key450" UNIQUE (username);


--
-- Name: Users Users_username_key451; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key451" UNIQUE (username);


--
-- Name: Users Users_username_key452; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key452" UNIQUE (username);


--
-- Name: Users Users_username_key453; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key453" UNIQUE (username);


--
-- Name: Users Users_username_key454; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key454" UNIQUE (username);


--
-- Name: Users Users_username_key455; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key455" UNIQUE (username);


--
-- Name: Users Users_username_key456; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key456" UNIQUE (username);


--
-- Name: Users Users_username_key457; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key457" UNIQUE (username);


--
-- Name: Users Users_username_key458; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key458" UNIQUE (username);


--
-- Name: Users Users_username_key459; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key459" UNIQUE (username);


--
-- Name: Users Users_username_key46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key46" UNIQUE (username);


--
-- Name: Users Users_username_key460; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key460" UNIQUE (username);


--
-- Name: Users Users_username_key461; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key461" UNIQUE (username);


--
-- Name: Users Users_username_key462; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key462" UNIQUE (username);


--
-- Name: Users Users_username_key463; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key463" UNIQUE (username);


--
-- Name: Users Users_username_key464; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key464" UNIQUE (username);


--
-- Name: Users Users_username_key465; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key465" UNIQUE (username);


--
-- Name: Users Users_username_key466; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key466" UNIQUE (username);


--
-- Name: Users Users_username_key467; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key467" UNIQUE (username);


--
-- Name: Users Users_username_key468; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key468" UNIQUE (username);


--
-- Name: Users Users_username_key469; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key469" UNIQUE (username);


--
-- Name: Users Users_username_key47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key47" UNIQUE (username);


--
-- Name: Users Users_username_key470; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key470" UNIQUE (username);


--
-- Name: Users Users_username_key471; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key471" UNIQUE (username);


--
-- Name: Users Users_username_key472; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key472" UNIQUE (username);


--
-- Name: Users Users_username_key473; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key473" UNIQUE (username);


--
-- Name: Users Users_username_key474; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key474" UNIQUE (username);


--
-- Name: Users Users_username_key475; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key475" UNIQUE (username);


--
-- Name: Users Users_username_key476; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key476" UNIQUE (username);


--
-- Name: Users Users_username_key477; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key477" UNIQUE (username);


--
-- Name: Users Users_username_key478; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key478" UNIQUE (username);


--
-- Name: Users Users_username_key479; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key479" UNIQUE (username);


--
-- Name: Users Users_username_key48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key48" UNIQUE (username);


--
-- Name: Users Users_username_key480; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key480" UNIQUE (username);


--
-- Name: Users Users_username_key481; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key481" UNIQUE (username);


--
-- Name: Users Users_username_key482; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key482" UNIQUE (username);


--
-- Name: Users Users_username_key483; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key483" UNIQUE (username);


--
-- Name: Users Users_username_key484; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key484" UNIQUE (username);


--
-- Name: Users Users_username_key485; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key485" UNIQUE (username);


--
-- Name: Users Users_username_key486; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key486" UNIQUE (username);


--
-- Name: Users Users_username_key487; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key487" UNIQUE (username);


--
-- Name: Users Users_username_key488; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key488" UNIQUE (username);


--
-- Name: Users Users_username_key489; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key489" UNIQUE (username);


--
-- Name: Users Users_username_key49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key49" UNIQUE (username);


--
-- Name: Users Users_username_key490; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key490" UNIQUE (username);


--
-- Name: Users Users_username_key491; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key491" UNIQUE (username);


--
-- Name: Users Users_username_key492; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key492" UNIQUE (username);


--
-- Name: Users Users_username_key493; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key493" UNIQUE (username);


--
-- Name: Users Users_username_key494; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key494" UNIQUE (username);


--
-- Name: Users Users_username_key495; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key495" UNIQUE (username);


--
-- Name: Users Users_username_key496; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key496" UNIQUE (username);


--
-- Name: Users Users_username_key497; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key497" UNIQUE (username);


--
-- Name: Users Users_username_key498; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key498" UNIQUE (username);


--
-- Name: Users Users_username_key499; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key499" UNIQUE (username);


--
-- Name: Users Users_username_key5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key5" UNIQUE (username);


--
-- Name: Users Users_username_key50; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key50" UNIQUE (username);


--
-- Name: Users Users_username_key500; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key500" UNIQUE (username);


--
-- Name: Users Users_username_key501; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key501" UNIQUE (username);


--
-- Name: Users Users_username_key502; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key502" UNIQUE (username);


--
-- Name: Users Users_username_key503; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key503" UNIQUE (username);


--
-- Name: Users Users_username_key504; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key504" UNIQUE (username);


--
-- Name: Users Users_username_key505; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key505" UNIQUE (username);


--
-- Name: Users Users_username_key506; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key506" UNIQUE (username);


--
-- Name: Users Users_username_key507; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key507" UNIQUE (username);


--
-- Name: Users Users_username_key508; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key508" UNIQUE (username);


--
-- Name: Users Users_username_key509; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key509" UNIQUE (username);


--
-- Name: Users Users_username_key51; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key51" UNIQUE (username);


--
-- Name: Users Users_username_key510; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key510" UNIQUE (username);


--
-- Name: Users Users_username_key511; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key511" UNIQUE (username);


--
-- Name: Users Users_username_key512; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key512" UNIQUE (username);


--
-- Name: Users Users_username_key513; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key513" UNIQUE (username);


--
-- Name: Users Users_username_key514; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key514" UNIQUE (username);


--
-- Name: Users Users_username_key515; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key515" UNIQUE (username);


--
-- Name: Users Users_username_key516; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key516" UNIQUE (username);


--
-- Name: Users Users_username_key517; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key517" UNIQUE (username);


--
-- Name: Users Users_username_key518; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key518" UNIQUE (username);


--
-- Name: Users Users_username_key519; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key519" UNIQUE (username);


--
-- Name: Users Users_username_key52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key52" UNIQUE (username);


--
-- Name: Users Users_username_key520; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key520" UNIQUE (username);


--
-- Name: Users Users_username_key521; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key521" UNIQUE (username);


--
-- Name: Users Users_username_key522; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key522" UNIQUE (username);


--
-- Name: Users Users_username_key523; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key523" UNIQUE (username);


--
-- Name: Users Users_username_key524; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key524" UNIQUE (username);


--
-- Name: Users Users_username_key525; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key525" UNIQUE (username);


--
-- Name: Users Users_username_key526; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key526" UNIQUE (username);


--
-- Name: Users Users_username_key527; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key527" UNIQUE (username);


--
-- Name: Users Users_username_key528; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key528" UNIQUE (username);


--
-- Name: Users Users_username_key529; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key529" UNIQUE (username);


--
-- Name: Users Users_username_key53; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key53" UNIQUE (username);


--
-- Name: Users Users_username_key530; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key530" UNIQUE (username);


--
-- Name: Users Users_username_key531; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key531" UNIQUE (username);


--
-- Name: Users Users_username_key532; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key532" UNIQUE (username);


--
-- Name: Users Users_username_key533; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key533" UNIQUE (username);


--
-- Name: Users Users_username_key534; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key534" UNIQUE (username);


--
-- Name: Users Users_username_key535; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key535" UNIQUE (username);


--
-- Name: Users Users_username_key536; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key536" UNIQUE (username);


--
-- Name: Users Users_username_key537; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key537" UNIQUE (username);


--
-- Name: Users Users_username_key538; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key538" UNIQUE (username);


--
-- Name: Users Users_username_key539; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key539" UNIQUE (username);


--
-- Name: Users Users_username_key54; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key54" UNIQUE (username);


--
-- Name: Users Users_username_key540; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key540" UNIQUE (username);


--
-- Name: Users Users_username_key541; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key541" UNIQUE (username);


--
-- Name: Users Users_username_key542; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key542" UNIQUE (username);


--
-- Name: Users Users_username_key543; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key543" UNIQUE (username);


--
-- Name: Users Users_username_key544; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key544" UNIQUE (username);


--
-- Name: Users Users_username_key545; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key545" UNIQUE (username);


--
-- Name: Users Users_username_key546; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key546" UNIQUE (username);


--
-- Name: Users Users_username_key547; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key547" UNIQUE (username);


--
-- Name: Users Users_username_key548; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key548" UNIQUE (username);


--
-- Name: Users Users_username_key549; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key549" UNIQUE (username);


--
-- Name: Users Users_username_key55; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key55" UNIQUE (username);


--
-- Name: Users Users_username_key550; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key550" UNIQUE (username);


--
-- Name: Users Users_username_key551; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key551" UNIQUE (username);


--
-- Name: Users Users_username_key552; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key552" UNIQUE (username);


--
-- Name: Users Users_username_key553; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key553" UNIQUE (username);


--
-- Name: Users Users_username_key554; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key554" UNIQUE (username);


--
-- Name: Users Users_username_key555; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key555" UNIQUE (username);


--
-- Name: Users Users_username_key556; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key556" UNIQUE (username);


--
-- Name: Users Users_username_key557; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key557" UNIQUE (username);


--
-- Name: Users Users_username_key558; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key558" UNIQUE (username);


--
-- Name: Users Users_username_key559; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key559" UNIQUE (username);


--
-- Name: Users Users_username_key56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key56" UNIQUE (username);


--
-- Name: Users Users_username_key560; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key560" UNIQUE (username);


--
-- Name: Users Users_username_key561; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key561" UNIQUE (username);


--
-- Name: Users Users_username_key562; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key562" UNIQUE (username);


--
-- Name: Users Users_username_key563; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key563" UNIQUE (username);


--
-- Name: Users Users_username_key564; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key564" UNIQUE (username);


--
-- Name: Users Users_username_key565; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key565" UNIQUE (username);


--
-- Name: Users Users_username_key566; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key566" UNIQUE (username);


--
-- Name: Users Users_username_key567; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key567" UNIQUE (username);


--
-- Name: Users Users_username_key568; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key568" UNIQUE (username);


--
-- Name: Users Users_username_key569; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key569" UNIQUE (username);


--
-- Name: Users Users_username_key57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key57" UNIQUE (username);


--
-- Name: Users Users_username_key570; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key570" UNIQUE (username);


--
-- Name: Users Users_username_key571; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key571" UNIQUE (username);


--
-- Name: Users Users_username_key572; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key572" UNIQUE (username);


--
-- Name: Users Users_username_key573; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key573" UNIQUE (username);


--
-- Name: Users Users_username_key574; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key574" UNIQUE (username);


--
-- Name: Users Users_username_key575; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key575" UNIQUE (username);


--
-- Name: Users Users_username_key576; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key576" UNIQUE (username);


--
-- Name: Users Users_username_key577; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key577" UNIQUE (username);


--
-- Name: Users Users_username_key578; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key578" UNIQUE (username);


--
-- Name: Users Users_username_key579; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key579" UNIQUE (username);


--
-- Name: Users Users_username_key58; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key58" UNIQUE (username);


--
-- Name: Users Users_username_key580; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key580" UNIQUE (username);


--
-- Name: Users Users_username_key581; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key581" UNIQUE (username);


--
-- Name: Users Users_username_key582; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key582" UNIQUE (username);


--
-- Name: Users Users_username_key583; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key583" UNIQUE (username);


--
-- Name: Users Users_username_key584; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key584" UNIQUE (username);


--
-- Name: Users Users_username_key585; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key585" UNIQUE (username);


--
-- Name: Users Users_username_key586; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key586" UNIQUE (username);


--
-- Name: Users Users_username_key587; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key587" UNIQUE (username);


--
-- Name: Users Users_username_key588; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key588" UNIQUE (username);


--
-- Name: Users Users_username_key589; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key589" UNIQUE (username);


--
-- Name: Users Users_username_key59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key59" UNIQUE (username);


--
-- Name: Users Users_username_key590; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key590" UNIQUE (username);


--
-- Name: Users Users_username_key591; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key591" UNIQUE (username);


--
-- Name: Users Users_username_key592; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key592" UNIQUE (username);


--
-- Name: Users Users_username_key593; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key593" UNIQUE (username);


--
-- Name: Users Users_username_key594; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key594" UNIQUE (username);


--
-- Name: Users Users_username_key595; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key595" UNIQUE (username);


--
-- Name: Users Users_username_key596; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key596" UNIQUE (username);


--
-- Name: Users Users_username_key597; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key597" UNIQUE (username);


--
-- Name: Users Users_username_key598; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key598" UNIQUE (username);


--
-- Name: Users Users_username_key599; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key599" UNIQUE (username);


--
-- Name: Users Users_username_key6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key6" UNIQUE (username);


--
-- Name: Users Users_username_key60; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key60" UNIQUE (username);


--
-- Name: Users Users_username_key600; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key600" UNIQUE (username);


--
-- Name: Users Users_username_key601; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key601" UNIQUE (username);


--
-- Name: Users Users_username_key602; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key602" UNIQUE (username);


--
-- Name: Users Users_username_key603; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key603" UNIQUE (username);


--
-- Name: Users Users_username_key604; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key604" UNIQUE (username);


--
-- Name: Users Users_username_key605; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key605" UNIQUE (username);


--
-- Name: Users Users_username_key606; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key606" UNIQUE (username);


--
-- Name: Users Users_username_key607; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key607" UNIQUE (username);


--
-- Name: Users Users_username_key608; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key608" UNIQUE (username);


--
-- Name: Users Users_username_key609; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key609" UNIQUE (username);


--
-- Name: Users Users_username_key61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key61" UNIQUE (username);


--
-- Name: Users Users_username_key610; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key610" UNIQUE (username);


--
-- Name: Users Users_username_key611; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key611" UNIQUE (username);


--
-- Name: Users Users_username_key612; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key612" UNIQUE (username);


--
-- Name: Users Users_username_key613; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key613" UNIQUE (username);


--
-- Name: Users Users_username_key614; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key614" UNIQUE (username);


--
-- Name: Users Users_username_key615; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key615" UNIQUE (username);


--
-- Name: Users Users_username_key616; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key616" UNIQUE (username);


--
-- Name: Users Users_username_key617; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key617" UNIQUE (username);


--
-- Name: Users Users_username_key618; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key618" UNIQUE (username);


--
-- Name: Users Users_username_key619; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key619" UNIQUE (username);


--
-- Name: Users Users_username_key62; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key62" UNIQUE (username);


--
-- Name: Users Users_username_key620; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key620" UNIQUE (username);


--
-- Name: Users Users_username_key621; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key621" UNIQUE (username);


--
-- Name: Users Users_username_key622; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key622" UNIQUE (username);


--
-- Name: Users Users_username_key623; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key623" UNIQUE (username);


--
-- Name: Users Users_username_key624; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key624" UNIQUE (username);


--
-- Name: Users Users_username_key625; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key625" UNIQUE (username);


--
-- Name: Users Users_username_key626; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key626" UNIQUE (username);


--
-- Name: Users Users_username_key627; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key627" UNIQUE (username);


--
-- Name: Users Users_username_key628; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key628" UNIQUE (username);


--
-- Name: Users Users_username_key629; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key629" UNIQUE (username);


--
-- Name: Users Users_username_key63; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key63" UNIQUE (username);


--
-- Name: Users Users_username_key630; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key630" UNIQUE (username);


--
-- Name: Users Users_username_key631; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key631" UNIQUE (username);


--
-- Name: Users Users_username_key632; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key632" UNIQUE (username);


--
-- Name: Users Users_username_key633; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key633" UNIQUE (username);


--
-- Name: Users Users_username_key634; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key634" UNIQUE (username);


--
-- Name: Users Users_username_key635; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key635" UNIQUE (username);


--
-- Name: Users Users_username_key636; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key636" UNIQUE (username);


--
-- Name: Users Users_username_key637; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key637" UNIQUE (username);


--
-- Name: Users Users_username_key638; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key638" UNIQUE (username);


--
-- Name: Users Users_username_key639; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key639" UNIQUE (username);


--
-- Name: Users Users_username_key64; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key64" UNIQUE (username);


--
-- Name: Users Users_username_key640; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key640" UNIQUE (username);


--
-- Name: Users Users_username_key641; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key641" UNIQUE (username);


--
-- Name: Users Users_username_key642; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key642" UNIQUE (username);


--
-- Name: Users Users_username_key643; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key643" UNIQUE (username);


--
-- Name: Users Users_username_key644; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key644" UNIQUE (username);


--
-- Name: Users Users_username_key645; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key645" UNIQUE (username);


--
-- Name: Users Users_username_key646; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key646" UNIQUE (username);


--
-- Name: Users Users_username_key647; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key647" UNIQUE (username);


--
-- Name: Users Users_username_key648; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key648" UNIQUE (username);


--
-- Name: Users Users_username_key649; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key649" UNIQUE (username);


--
-- Name: Users Users_username_key65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key65" UNIQUE (username);


--
-- Name: Users Users_username_key650; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key650" UNIQUE (username);


--
-- Name: Users Users_username_key651; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key651" UNIQUE (username);


--
-- Name: Users Users_username_key652; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key652" UNIQUE (username);


--
-- Name: Users Users_username_key653; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key653" UNIQUE (username);


--
-- Name: Users Users_username_key654; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key654" UNIQUE (username);


--
-- Name: Users Users_username_key655; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key655" UNIQUE (username);


--
-- Name: Users Users_username_key656; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key656" UNIQUE (username);


--
-- Name: Users Users_username_key657; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key657" UNIQUE (username);


--
-- Name: Users Users_username_key658; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key658" UNIQUE (username);


--
-- Name: Users Users_username_key659; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key659" UNIQUE (username);


--
-- Name: Users Users_username_key66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key66" UNIQUE (username);


--
-- Name: Users Users_username_key660; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key660" UNIQUE (username);


--
-- Name: Users Users_username_key661; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key661" UNIQUE (username);


--
-- Name: Users Users_username_key662; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key662" UNIQUE (username);


--
-- Name: Users Users_username_key663; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key663" UNIQUE (username);


--
-- Name: Users Users_username_key664; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key664" UNIQUE (username);


--
-- Name: Users Users_username_key665; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key665" UNIQUE (username);


--
-- Name: Users Users_username_key666; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key666" UNIQUE (username);


--
-- Name: Users Users_username_key667; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key667" UNIQUE (username);


--
-- Name: Users Users_username_key668; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key668" UNIQUE (username);


--
-- Name: Users Users_username_key67; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key67" UNIQUE (username);


--
-- Name: Users Users_username_key68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key68" UNIQUE (username);


--
-- Name: Users Users_username_key69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key69" UNIQUE (username);


--
-- Name: Users Users_username_key7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key7" UNIQUE (username);


--
-- Name: Users Users_username_key70; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key70" UNIQUE (username);


--
-- Name: Users Users_username_key71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key71" UNIQUE (username);


--
-- Name: Users Users_username_key72; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key72" UNIQUE (username);


--
-- Name: Users Users_username_key73; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key73" UNIQUE (username);


--
-- Name: Users Users_username_key74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key74" UNIQUE (username);


--
-- Name: Users Users_username_key75; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key75" UNIQUE (username);


--
-- Name: Users Users_username_key76; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key76" UNIQUE (username);


--
-- Name: Users Users_username_key77; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key77" UNIQUE (username);


--
-- Name: Users Users_username_key78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key78" UNIQUE (username);


--
-- Name: Users Users_username_key79; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key79" UNIQUE (username);


--
-- Name: Users Users_username_key8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key8" UNIQUE (username);


--
-- Name: Users Users_username_key80; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key80" UNIQUE (username);


--
-- Name: Users Users_username_key81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key81" UNIQUE (username);


--
-- Name: Users Users_username_key82; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key82" UNIQUE (username);


--
-- Name: Users Users_username_key83; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key83" UNIQUE (username);


--
-- Name: Users Users_username_key84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key84" UNIQUE (username);


--
-- Name: Users Users_username_key85; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key85" UNIQUE (username);


--
-- Name: Users Users_username_key86; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key86" UNIQUE (username);


--
-- Name: Users Users_username_key87; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key87" UNIQUE (username);


--
-- Name: Users Users_username_key88; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key88" UNIQUE (username);


--
-- Name: Users Users_username_key89; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key89" UNIQUE (username);


--
-- Name: Users Users_username_key9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key9" UNIQUE (username);


--
-- Name: Users Users_username_key90; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key90" UNIQUE (username);


--
-- Name: Users Users_username_key91; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key91" UNIQUE (username);


--
-- Name: Users Users_username_key92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key92" UNIQUE (username);


--
-- Name: Users Users_username_key93; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key93" UNIQUE (username);


--
-- Name: Users Users_username_key94; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key94" UNIQUE (username);


--
-- Name: Users Users_username_key95; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key95" UNIQUE (username);


--
-- Name: Users Users_username_key96; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key96" UNIQUE (username);


--
-- Name: Users Users_username_key97; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key97" UNIQUE (username);


--
-- Name: Users Users_username_key98; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key98" UNIQUE (username);


--
-- Name: Users Users_username_key99; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_username_key99" UNIQUE (username);


--
-- Name: amenities amenities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_pkey PRIMARY KEY (id);


--
-- Name: amenities amenities_title_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key UNIQUE (title);


--
-- Name: amenities amenities_title_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key1 UNIQUE (title);


--
-- Name: amenities amenities_title_key10; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key10 UNIQUE (title);


--
-- Name: amenities amenities_title_key100; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key100 UNIQUE (title);


--
-- Name: amenities amenities_title_key101; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key101 UNIQUE (title);


--
-- Name: amenities amenities_title_key102; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key102 UNIQUE (title);


--
-- Name: amenities amenities_title_key103; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key103 UNIQUE (title);


--
-- Name: amenities amenities_title_key104; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key104 UNIQUE (title);


--
-- Name: amenities amenities_title_key105; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key105 UNIQUE (title);


--
-- Name: amenities amenities_title_key106; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key106 UNIQUE (title);


--
-- Name: amenities amenities_title_key107; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key107 UNIQUE (title);


--
-- Name: amenities amenities_title_key108; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key108 UNIQUE (title);


--
-- Name: amenities amenities_title_key109; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key109 UNIQUE (title);


--
-- Name: amenities amenities_title_key11; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key11 UNIQUE (title);


--
-- Name: amenities amenities_title_key110; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key110 UNIQUE (title);


--
-- Name: amenities amenities_title_key111; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key111 UNIQUE (title);


--
-- Name: amenities amenities_title_key112; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key112 UNIQUE (title);


--
-- Name: amenities amenities_title_key113; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key113 UNIQUE (title);


--
-- Name: amenities amenities_title_key114; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key114 UNIQUE (title);


--
-- Name: amenities amenities_title_key115; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key115 UNIQUE (title);


--
-- Name: amenities amenities_title_key116; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key116 UNIQUE (title);


--
-- Name: amenities amenities_title_key117; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key117 UNIQUE (title);


--
-- Name: amenities amenities_title_key118; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key118 UNIQUE (title);


--
-- Name: amenities amenities_title_key119; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key119 UNIQUE (title);


--
-- Name: amenities amenities_title_key12; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key12 UNIQUE (title);


--
-- Name: amenities amenities_title_key120; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key120 UNIQUE (title);


--
-- Name: amenities amenities_title_key121; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key121 UNIQUE (title);


--
-- Name: amenities amenities_title_key122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key122 UNIQUE (title);


--
-- Name: amenities amenities_title_key123; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key123 UNIQUE (title);


--
-- Name: amenities amenities_title_key124; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key124 UNIQUE (title);


--
-- Name: amenities amenities_title_key125; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key125 UNIQUE (title);


--
-- Name: amenities amenities_title_key126; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key126 UNIQUE (title);


--
-- Name: amenities amenities_title_key127; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key127 UNIQUE (title);


--
-- Name: amenities amenities_title_key128; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key128 UNIQUE (title);


--
-- Name: amenities amenities_title_key129; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key129 UNIQUE (title);


--
-- Name: amenities amenities_title_key13; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key13 UNIQUE (title);


--
-- Name: amenities amenities_title_key130; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key130 UNIQUE (title);


--
-- Name: amenities amenities_title_key131; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key131 UNIQUE (title);


--
-- Name: amenities amenities_title_key132; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key132 UNIQUE (title);


--
-- Name: amenities amenities_title_key133; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key133 UNIQUE (title);


--
-- Name: amenities amenities_title_key134; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key134 UNIQUE (title);


--
-- Name: amenities amenities_title_key135; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key135 UNIQUE (title);


--
-- Name: amenities amenities_title_key136; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key136 UNIQUE (title);


--
-- Name: amenities amenities_title_key137; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key137 UNIQUE (title);


--
-- Name: amenities amenities_title_key138; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key138 UNIQUE (title);


--
-- Name: amenities amenities_title_key139; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key139 UNIQUE (title);


--
-- Name: amenities amenities_title_key14; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key14 UNIQUE (title);


--
-- Name: amenities amenities_title_key140; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key140 UNIQUE (title);


--
-- Name: amenities amenities_title_key141; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key141 UNIQUE (title);


--
-- Name: amenities amenities_title_key142; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key142 UNIQUE (title);


--
-- Name: amenities amenities_title_key143; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key143 UNIQUE (title);


--
-- Name: amenities amenities_title_key144; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key144 UNIQUE (title);


--
-- Name: amenities amenities_title_key145; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key145 UNIQUE (title);


--
-- Name: amenities amenities_title_key146; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key146 UNIQUE (title);


--
-- Name: amenities amenities_title_key147; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key147 UNIQUE (title);


--
-- Name: amenities amenities_title_key148; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key148 UNIQUE (title);


--
-- Name: amenities amenities_title_key149; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key149 UNIQUE (title);


--
-- Name: amenities amenities_title_key15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key15 UNIQUE (title);


--
-- Name: amenities amenities_title_key150; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key150 UNIQUE (title);


--
-- Name: amenities amenities_title_key151; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key151 UNIQUE (title);


--
-- Name: amenities amenities_title_key152; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key152 UNIQUE (title);


--
-- Name: amenities amenities_title_key153; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key153 UNIQUE (title);


--
-- Name: amenities amenities_title_key154; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key154 UNIQUE (title);


--
-- Name: amenities amenities_title_key155; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key155 UNIQUE (title);


--
-- Name: amenities amenities_title_key156; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key156 UNIQUE (title);


--
-- Name: amenities amenities_title_key157; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key157 UNIQUE (title);


--
-- Name: amenities amenities_title_key158; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key158 UNIQUE (title);


--
-- Name: amenities amenities_title_key159; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key159 UNIQUE (title);


--
-- Name: amenities amenities_title_key16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key16 UNIQUE (title);


--
-- Name: amenities amenities_title_key160; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key160 UNIQUE (title);


--
-- Name: amenities amenities_title_key161; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key161 UNIQUE (title);


--
-- Name: amenities amenities_title_key162; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key162 UNIQUE (title);


--
-- Name: amenities amenities_title_key163; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key163 UNIQUE (title);


--
-- Name: amenities amenities_title_key164; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key164 UNIQUE (title);


--
-- Name: amenities amenities_title_key165; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key165 UNIQUE (title);


--
-- Name: amenities amenities_title_key166; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key166 UNIQUE (title);


--
-- Name: amenities amenities_title_key167; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key167 UNIQUE (title);


--
-- Name: amenities amenities_title_key168; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key168 UNIQUE (title);


--
-- Name: amenities amenities_title_key169; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key169 UNIQUE (title);


--
-- Name: amenities amenities_title_key17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key17 UNIQUE (title);


--
-- Name: amenities amenities_title_key170; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key170 UNIQUE (title);


--
-- Name: amenities amenities_title_key171; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key171 UNIQUE (title);


--
-- Name: amenities amenities_title_key172; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key172 UNIQUE (title);


--
-- Name: amenities amenities_title_key173; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key173 UNIQUE (title);


--
-- Name: amenities amenities_title_key174; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key174 UNIQUE (title);


--
-- Name: amenities amenities_title_key175; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key175 UNIQUE (title);


--
-- Name: amenities amenities_title_key176; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key176 UNIQUE (title);


--
-- Name: amenities amenities_title_key177; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key177 UNIQUE (title);


--
-- Name: amenities amenities_title_key178; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key178 UNIQUE (title);


--
-- Name: amenities amenities_title_key179; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key179 UNIQUE (title);


--
-- Name: amenities amenities_title_key18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key18 UNIQUE (title);


--
-- Name: amenities amenities_title_key180; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key180 UNIQUE (title);


--
-- Name: amenities amenities_title_key181; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key181 UNIQUE (title);


--
-- Name: amenities amenities_title_key182; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key182 UNIQUE (title);


--
-- Name: amenities amenities_title_key183; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key183 UNIQUE (title);


--
-- Name: amenities amenities_title_key184; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key184 UNIQUE (title);


--
-- Name: amenities amenities_title_key185; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key185 UNIQUE (title);


--
-- Name: amenities amenities_title_key186; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key186 UNIQUE (title);


--
-- Name: amenities amenities_title_key187; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key187 UNIQUE (title);


--
-- Name: amenities amenities_title_key188; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key188 UNIQUE (title);


--
-- Name: amenities amenities_title_key189; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key189 UNIQUE (title);


--
-- Name: amenities amenities_title_key19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key19 UNIQUE (title);


--
-- Name: amenities amenities_title_key190; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key190 UNIQUE (title);


--
-- Name: amenities amenities_title_key191; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key191 UNIQUE (title);


--
-- Name: amenities amenities_title_key192; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key192 UNIQUE (title);


--
-- Name: amenities amenities_title_key193; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key193 UNIQUE (title);


--
-- Name: amenities amenities_title_key194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key194 UNIQUE (title);


--
-- Name: amenities amenities_title_key195; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key195 UNIQUE (title);


--
-- Name: amenities amenities_title_key196; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key196 UNIQUE (title);


--
-- Name: amenities amenities_title_key197; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key197 UNIQUE (title);


--
-- Name: amenities amenities_title_key198; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key198 UNIQUE (title);


--
-- Name: amenities amenities_title_key199; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key199 UNIQUE (title);


--
-- Name: amenities amenities_title_key2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key2 UNIQUE (title);


--
-- Name: amenities amenities_title_key20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key20 UNIQUE (title);


--
-- Name: amenities amenities_title_key200; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key200 UNIQUE (title);


--
-- Name: amenities amenities_title_key201; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key201 UNIQUE (title);


--
-- Name: amenities amenities_title_key202; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key202 UNIQUE (title);


--
-- Name: amenities amenities_title_key203; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key203 UNIQUE (title);


--
-- Name: amenities amenities_title_key204; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key204 UNIQUE (title);


--
-- Name: amenities amenities_title_key205; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key205 UNIQUE (title);


--
-- Name: amenities amenities_title_key206; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key206 UNIQUE (title);


--
-- Name: amenities amenities_title_key207; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key207 UNIQUE (title);


--
-- Name: amenities amenities_title_key208; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key208 UNIQUE (title);


--
-- Name: amenities amenities_title_key209; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key209 UNIQUE (title);


--
-- Name: amenities amenities_title_key21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key21 UNIQUE (title);


--
-- Name: amenities amenities_title_key210; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key210 UNIQUE (title);


--
-- Name: amenities amenities_title_key211; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key211 UNIQUE (title);


--
-- Name: amenities amenities_title_key212; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key212 UNIQUE (title);


--
-- Name: amenities amenities_title_key213; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key213 UNIQUE (title);


--
-- Name: amenities amenities_title_key214; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key214 UNIQUE (title);


--
-- Name: amenities amenities_title_key215; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key215 UNIQUE (title);


--
-- Name: amenities amenities_title_key216; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key216 UNIQUE (title);


--
-- Name: amenities amenities_title_key217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key217 UNIQUE (title);


--
-- Name: amenities amenities_title_key218; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key218 UNIQUE (title);


--
-- Name: amenities amenities_title_key219; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key219 UNIQUE (title);


--
-- Name: amenities amenities_title_key22; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key22 UNIQUE (title);


--
-- Name: amenities amenities_title_key220; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key220 UNIQUE (title);


--
-- Name: amenities amenities_title_key221; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key221 UNIQUE (title);


--
-- Name: amenities amenities_title_key222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key222 UNIQUE (title);


--
-- Name: amenities amenities_title_key223; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key223 UNIQUE (title);


--
-- Name: amenities amenities_title_key224; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key224 UNIQUE (title);


--
-- Name: amenities amenities_title_key225; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key225 UNIQUE (title);


--
-- Name: amenities amenities_title_key226; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key226 UNIQUE (title);


--
-- Name: amenities amenities_title_key227; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key227 UNIQUE (title);


--
-- Name: amenities amenities_title_key228; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key228 UNIQUE (title);


--
-- Name: amenities amenities_title_key229; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key229 UNIQUE (title);


--
-- Name: amenities amenities_title_key23; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key23 UNIQUE (title);


--
-- Name: amenities amenities_title_key230; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key230 UNIQUE (title);


--
-- Name: amenities amenities_title_key231; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key231 UNIQUE (title);


--
-- Name: amenities amenities_title_key232; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key232 UNIQUE (title);


--
-- Name: amenities amenities_title_key233; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key233 UNIQUE (title);


--
-- Name: amenities amenities_title_key234; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key234 UNIQUE (title);


--
-- Name: amenities amenities_title_key235; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key235 UNIQUE (title);


--
-- Name: amenities amenities_title_key236; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key236 UNIQUE (title);


--
-- Name: amenities amenities_title_key237; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key237 UNIQUE (title);


--
-- Name: amenities amenities_title_key238; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key238 UNIQUE (title);


--
-- Name: amenities amenities_title_key239; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key239 UNIQUE (title);


--
-- Name: amenities amenities_title_key24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key24 UNIQUE (title);


--
-- Name: amenities amenities_title_key240; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key240 UNIQUE (title);


--
-- Name: amenities amenities_title_key241; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key241 UNIQUE (title);


--
-- Name: amenities amenities_title_key242; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key242 UNIQUE (title);


--
-- Name: amenities amenities_title_key243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key243 UNIQUE (title);


--
-- Name: amenities amenities_title_key244; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key244 UNIQUE (title);


--
-- Name: amenities amenities_title_key245; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key245 UNIQUE (title);


--
-- Name: amenities amenities_title_key246; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key246 UNIQUE (title);


--
-- Name: amenities amenities_title_key247; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key247 UNIQUE (title);


--
-- Name: amenities amenities_title_key248; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key248 UNIQUE (title);


--
-- Name: amenities amenities_title_key249; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key249 UNIQUE (title);


--
-- Name: amenities amenities_title_key25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key25 UNIQUE (title);


--
-- Name: amenities amenities_title_key250; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key250 UNIQUE (title);


--
-- Name: amenities amenities_title_key251; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key251 UNIQUE (title);


--
-- Name: amenities amenities_title_key252; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key252 UNIQUE (title);


--
-- Name: amenities amenities_title_key253; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key253 UNIQUE (title);


--
-- Name: amenities amenities_title_key254; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key254 UNIQUE (title);


--
-- Name: amenities amenities_title_key255; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key255 UNIQUE (title);


--
-- Name: amenities amenities_title_key256; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key256 UNIQUE (title);


--
-- Name: amenities amenities_title_key257; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key257 UNIQUE (title);


--
-- Name: amenities amenities_title_key258; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key258 UNIQUE (title);


--
-- Name: amenities amenities_title_key259; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key259 UNIQUE (title);


--
-- Name: amenities amenities_title_key26; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key26 UNIQUE (title);


--
-- Name: amenities amenities_title_key260; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key260 UNIQUE (title);


--
-- Name: amenities amenities_title_key261; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key261 UNIQUE (title);


--
-- Name: amenities amenities_title_key262; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key262 UNIQUE (title);


--
-- Name: amenities amenities_title_key263; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key263 UNIQUE (title);


--
-- Name: amenities amenities_title_key264; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key264 UNIQUE (title);


--
-- Name: amenities amenities_title_key265; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key265 UNIQUE (title);


--
-- Name: amenities amenities_title_key266; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key266 UNIQUE (title);


--
-- Name: amenities amenities_title_key267; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key267 UNIQUE (title);


--
-- Name: amenities amenities_title_key268; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key268 UNIQUE (title);


--
-- Name: amenities amenities_title_key269; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key269 UNIQUE (title);


--
-- Name: amenities amenities_title_key27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key27 UNIQUE (title);


--
-- Name: amenities amenities_title_key270; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key270 UNIQUE (title);


--
-- Name: amenities amenities_title_key271; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key271 UNIQUE (title);


--
-- Name: amenities amenities_title_key272; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key272 UNIQUE (title);


--
-- Name: amenities amenities_title_key273; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key273 UNIQUE (title);


--
-- Name: amenities amenities_title_key274; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key274 UNIQUE (title);


--
-- Name: amenities amenities_title_key275; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key275 UNIQUE (title);


--
-- Name: amenities amenities_title_key276; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key276 UNIQUE (title);


--
-- Name: amenities amenities_title_key277; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key277 UNIQUE (title);


--
-- Name: amenities amenities_title_key278; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key278 UNIQUE (title);


--
-- Name: amenities amenities_title_key279; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key279 UNIQUE (title);


--
-- Name: amenities amenities_title_key28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key28 UNIQUE (title);


--
-- Name: amenities amenities_title_key280; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key280 UNIQUE (title);


--
-- Name: amenities amenities_title_key281; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key281 UNIQUE (title);


--
-- Name: amenities amenities_title_key282; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key282 UNIQUE (title);


--
-- Name: amenities amenities_title_key283; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key283 UNIQUE (title);


--
-- Name: amenities amenities_title_key284; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key284 UNIQUE (title);


--
-- Name: amenities amenities_title_key285; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key285 UNIQUE (title);


--
-- Name: amenities amenities_title_key286; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key286 UNIQUE (title);


--
-- Name: amenities amenities_title_key287; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key287 UNIQUE (title);


--
-- Name: amenities amenities_title_key288; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key288 UNIQUE (title);


--
-- Name: amenities amenities_title_key289; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key289 UNIQUE (title);


--
-- Name: amenities amenities_title_key29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key29 UNIQUE (title);


--
-- Name: amenities amenities_title_key290; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key290 UNIQUE (title);


--
-- Name: amenities amenities_title_key291; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key291 UNIQUE (title);


--
-- Name: amenities amenities_title_key292; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key292 UNIQUE (title);


--
-- Name: amenities amenities_title_key293; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key293 UNIQUE (title);


--
-- Name: amenities amenities_title_key294; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key294 UNIQUE (title);


--
-- Name: amenities amenities_title_key295; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key295 UNIQUE (title);


--
-- Name: amenities amenities_title_key296; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key296 UNIQUE (title);


--
-- Name: amenities amenities_title_key297; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key297 UNIQUE (title);


--
-- Name: amenities amenities_title_key298; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key298 UNIQUE (title);


--
-- Name: amenities amenities_title_key299; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key299 UNIQUE (title);


--
-- Name: amenities amenities_title_key3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key3 UNIQUE (title);


--
-- Name: amenities amenities_title_key30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key30 UNIQUE (title);


--
-- Name: amenities amenities_title_key300; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key300 UNIQUE (title);


--
-- Name: amenities amenities_title_key301; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key301 UNIQUE (title);


--
-- Name: amenities amenities_title_key302; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key302 UNIQUE (title);


--
-- Name: amenities amenities_title_key303; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key303 UNIQUE (title);


--
-- Name: amenities amenities_title_key304; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key304 UNIQUE (title);


--
-- Name: amenities amenities_title_key305; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key305 UNIQUE (title);


--
-- Name: amenities amenities_title_key306; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key306 UNIQUE (title);


--
-- Name: amenities amenities_title_key307; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key307 UNIQUE (title);


--
-- Name: amenities amenities_title_key308; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key308 UNIQUE (title);


--
-- Name: amenities amenities_title_key309; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key309 UNIQUE (title);


--
-- Name: amenities amenities_title_key31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key31 UNIQUE (title);


--
-- Name: amenities amenities_title_key310; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key310 UNIQUE (title);


--
-- Name: amenities amenities_title_key311; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key311 UNIQUE (title);


--
-- Name: amenities amenities_title_key312; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key312 UNIQUE (title);


--
-- Name: amenities amenities_title_key313; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key313 UNIQUE (title);


--
-- Name: amenities amenities_title_key314; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key314 UNIQUE (title);


--
-- Name: amenities amenities_title_key315; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key315 UNIQUE (title);


--
-- Name: amenities amenities_title_key316; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key316 UNIQUE (title);


--
-- Name: amenities amenities_title_key317; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key317 UNIQUE (title);


--
-- Name: amenities amenities_title_key318; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key318 UNIQUE (title);


--
-- Name: amenities amenities_title_key319; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key319 UNIQUE (title);


--
-- Name: amenities amenities_title_key32; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key32 UNIQUE (title);


--
-- Name: amenities amenities_title_key320; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key320 UNIQUE (title);


--
-- Name: amenities amenities_title_key321; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key321 UNIQUE (title);


--
-- Name: amenities amenities_title_key322; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key322 UNIQUE (title);


--
-- Name: amenities amenities_title_key323; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key323 UNIQUE (title);


--
-- Name: amenities amenities_title_key324; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key324 UNIQUE (title);


--
-- Name: amenities amenities_title_key325; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key325 UNIQUE (title);


--
-- Name: amenities amenities_title_key326; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key326 UNIQUE (title);


--
-- Name: amenities amenities_title_key327; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key327 UNIQUE (title);


--
-- Name: amenities amenities_title_key328; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key328 UNIQUE (title);


--
-- Name: amenities amenities_title_key329; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key329 UNIQUE (title);


--
-- Name: amenities amenities_title_key33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key33 UNIQUE (title);


--
-- Name: amenities amenities_title_key330; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key330 UNIQUE (title);


--
-- Name: amenities amenities_title_key331; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key331 UNIQUE (title);


--
-- Name: amenities amenities_title_key332; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key332 UNIQUE (title);


--
-- Name: amenities amenities_title_key333; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key333 UNIQUE (title);


--
-- Name: amenities amenities_title_key334; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key334 UNIQUE (title);


--
-- Name: amenities amenities_title_key335; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key335 UNIQUE (title);


--
-- Name: amenities amenities_title_key336; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key336 UNIQUE (title);


--
-- Name: amenities amenities_title_key337; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key337 UNIQUE (title);


--
-- Name: amenities amenities_title_key338; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key338 UNIQUE (title);


--
-- Name: amenities amenities_title_key339; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key339 UNIQUE (title);


--
-- Name: amenities amenities_title_key34; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key34 UNIQUE (title);


--
-- Name: amenities amenities_title_key340; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key340 UNIQUE (title);


--
-- Name: amenities amenities_title_key341; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key341 UNIQUE (title);


--
-- Name: amenities amenities_title_key342; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key342 UNIQUE (title);


--
-- Name: amenities amenities_title_key343; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key343 UNIQUE (title);


--
-- Name: amenities amenities_title_key344; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key344 UNIQUE (title);


--
-- Name: amenities amenities_title_key345; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key345 UNIQUE (title);


--
-- Name: amenities amenities_title_key346; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key346 UNIQUE (title);


--
-- Name: amenities amenities_title_key347; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key347 UNIQUE (title);


--
-- Name: amenities amenities_title_key348; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key348 UNIQUE (title);


--
-- Name: amenities amenities_title_key349; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key349 UNIQUE (title);


--
-- Name: amenities amenities_title_key35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key35 UNIQUE (title);


--
-- Name: amenities amenities_title_key350; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key350 UNIQUE (title);


--
-- Name: amenities amenities_title_key351; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key351 UNIQUE (title);


--
-- Name: amenities amenities_title_key352; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key352 UNIQUE (title);


--
-- Name: amenities amenities_title_key353; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key353 UNIQUE (title);


--
-- Name: amenities amenities_title_key354; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key354 UNIQUE (title);


--
-- Name: amenities amenities_title_key355; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key355 UNIQUE (title);


--
-- Name: amenities amenities_title_key356; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key356 UNIQUE (title);


--
-- Name: amenities amenities_title_key357; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key357 UNIQUE (title);


--
-- Name: amenities amenities_title_key358; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key358 UNIQUE (title);


--
-- Name: amenities amenities_title_key359; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key359 UNIQUE (title);


--
-- Name: amenities amenities_title_key36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key36 UNIQUE (title);


--
-- Name: amenities amenities_title_key360; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key360 UNIQUE (title);


--
-- Name: amenities amenities_title_key361; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key361 UNIQUE (title);


--
-- Name: amenities amenities_title_key362; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key362 UNIQUE (title);


--
-- Name: amenities amenities_title_key363; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key363 UNIQUE (title);


--
-- Name: amenities amenities_title_key364; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key364 UNIQUE (title);


--
-- Name: amenities amenities_title_key365; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key365 UNIQUE (title);


--
-- Name: amenities amenities_title_key366; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key366 UNIQUE (title);


--
-- Name: amenities amenities_title_key367; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key367 UNIQUE (title);


--
-- Name: amenities amenities_title_key368; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key368 UNIQUE (title);


--
-- Name: amenities amenities_title_key369; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key369 UNIQUE (title);


--
-- Name: amenities amenities_title_key37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key37 UNIQUE (title);


--
-- Name: amenities amenities_title_key370; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key370 UNIQUE (title);


--
-- Name: amenities amenities_title_key371; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key371 UNIQUE (title);


--
-- Name: amenities amenities_title_key372; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key372 UNIQUE (title);


--
-- Name: amenities amenities_title_key373; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key373 UNIQUE (title);


--
-- Name: amenities amenities_title_key374; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key374 UNIQUE (title);


--
-- Name: amenities amenities_title_key375; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key375 UNIQUE (title);


--
-- Name: amenities amenities_title_key376; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key376 UNIQUE (title);


--
-- Name: amenities amenities_title_key377; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key377 UNIQUE (title);


--
-- Name: amenities amenities_title_key378; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key378 UNIQUE (title);


--
-- Name: amenities amenities_title_key379; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key379 UNIQUE (title);


--
-- Name: amenities amenities_title_key38; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key38 UNIQUE (title);


--
-- Name: amenities amenities_title_key380; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key380 UNIQUE (title);


--
-- Name: amenities amenities_title_key381; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key381 UNIQUE (title);


--
-- Name: amenities amenities_title_key382; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key382 UNIQUE (title);


--
-- Name: amenities amenities_title_key383; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key383 UNIQUE (title);


--
-- Name: amenities amenities_title_key384; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key384 UNIQUE (title);


--
-- Name: amenities amenities_title_key385; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key385 UNIQUE (title);


--
-- Name: amenities amenities_title_key386; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key386 UNIQUE (title);


--
-- Name: amenities amenities_title_key387; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key387 UNIQUE (title);


--
-- Name: amenities amenities_title_key388; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key388 UNIQUE (title);


--
-- Name: amenities amenities_title_key389; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key389 UNIQUE (title);


--
-- Name: amenities amenities_title_key39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key39 UNIQUE (title);


--
-- Name: amenities amenities_title_key390; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key390 UNIQUE (title);


--
-- Name: amenities amenities_title_key391; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key391 UNIQUE (title);


--
-- Name: amenities amenities_title_key392; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key392 UNIQUE (title);


--
-- Name: amenities amenities_title_key393; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key393 UNIQUE (title);


--
-- Name: amenities amenities_title_key394; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key394 UNIQUE (title);


--
-- Name: amenities amenities_title_key395; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key395 UNIQUE (title);


--
-- Name: amenities amenities_title_key396; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key396 UNIQUE (title);


--
-- Name: amenities amenities_title_key397; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key397 UNIQUE (title);


--
-- Name: amenities amenities_title_key398; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key398 UNIQUE (title);


--
-- Name: amenities amenities_title_key399; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key399 UNIQUE (title);


--
-- Name: amenities amenities_title_key4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key4 UNIQUE (title);


--
-- Name: amenities amenities_title_key40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key40 UNIQUE (title);


--
-- Name: amenities amenities_title_key400; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key400 UNIQUE (title);


--
-- Name: amenities amenities_title_key401; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key401 UNIQUE (title);


--
-- Name: amenities amenities_title_key402; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key402 UNIQUE (title);


--
-- Name: amenities amenities_title_key403; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key403 UNIQUE (title);


--
-- Name: amenities amenities_title_key404; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key404 UNIQUE (title);


--
-- Name: amenities amenities_title_key405; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key405 UNIQUE (title);


--
-- Name: amenities amenities_title_key406; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key406 UNIQUE (title);


--
-- Name: amenities amenities_title_key407; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key407 UNIQUE (title);


--
-- Name: amenities amenities_title_key408; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key408 UNIQUE (title);


--
-- Name: amenities amenities_title_key409; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key409 UNIQUE (title);


--
-- Name: amenities amenities_title_key41; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key41 UNIQUE (title);


--
-- Name: amenities amenities_title_key410; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key410 UNIQUE (title);


--
-- Name: amenities amenities_title_key411; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key411 UNIQUE (title);


--
-- Name: amenities amenities_title_key412; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key412 UNIQUE (title);


--
-- Name: amenities amenities_title_key413; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key413 UNIQUE (title);


--
-- Name: amenities amenities_title_key414; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key414 UNIQUE (title);


--
-- Name: amenities amenities_title_key415; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key415 UNIQUE (title);


--
-- Name: amenities amenities_title_key416; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key416 UNIQUE (title);


--
-- Name: amenities amenities_title_key417; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key417 UNIQUE (title);


--
-- Name: amenities amenities_title_key418; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key418 UNIQUE (title);


--
-- Name: amenities amenities_title_key419; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key419 UNIQUE (title);


--
-- Name: amenities amenities_title_key42; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key42 UNIQUE (title);


--
-- Name: amenities amenities_title_key420; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key420 UNIQUE (title);


--
-- Name: amenities amenities_title_key421; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key421 UNIQUE (title);


--
-- Name: amenities amenities_title_key422; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key422 UNIQUE (title);


--
-- Name: amenities amenities_title_key423; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key423 UNIQUE (title);


--
-- Name: amenities amenities_title_key424; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key424 UNIQUE (title);


--
-- Name: amenities amenities_title_key425; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key425 UNIQUE (title);


--
-- Name: amenities amenities_title_key426; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key426 UNIQUE (title);


--
-- Name: amenities amenities_title_key427; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key427 UNIQUE (title);


--
-- Name: amenities amenities_title_key428; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key428 UNIQUE (title);


--
-- Name: amenities amenities_title_key429; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key429 UNIQUE (title);


--
-- Name: amenities amenities_title_key43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key43 UNIQUE (title);


--
-- Name: amenities amenities_title_key430; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key430 UNIQUE (title);


--
-- Name: amenities amenities_title_key431; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key431 UNIQUE (title);


--
-- Name: amenities amenities_title_key432; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key432 UNIQUE (title);


--
-- Name: amenities amenities_title_key433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key433 UNIQUE (title);


--
-- Name: amenities amenities_title_key434; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key434 UNIQUE (title);


--
-- Name: amenities amenities_title_key435; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key435 UNIQUE (title);


--
-- Name: amenities amenities_title_key436; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key436 UNIQUE (title);


--
-- Name: amenities amenities_title_key437; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key437 UNIQUE (title);


--
-- Name: amenities amenities_title_key438; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key438 UNIQUE (title);


--
-- Name: amenities amenities_title_key439; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key439 UNIQUE (title);


--
-- Name: amenities amenities_title_key44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key44 UNIQUE (title);


--
-- Name: amenities amenities_title_key440; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key440 UNIQUE (title);


--
-- Name: amenities amenities_title_key441; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key441 UNIQUE (title);


--
-- Name: amenities amenities_title_key442; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key442 UNIQUE (title);


--
-- Name: amenities amenities_title_key443; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key443 UNIQUE (title);


--
-- Name: amenities amenities_title_key444; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key444 UNIQUE (title);


--
-- Name: amenities amenities_title_key445; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key445 UNIQUE (title);


--
-- Name: amenities amenities_title_key446; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key446 UNIQUE (title);


--
-- Name: amenities amenities_title_key447; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key447 UNIQUE (title);


--
-- Name: amenities amenities_title_key448; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key448 UNIQUE (title);


--
-- Name: amenities amenities_title_key449; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key449 UNIQUE (title);


--
-- Name: amenities amenities_title_key45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key45 UNIQUE (title);


--
-- Name: amenities amenities_title_key450; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key450 UNIQUE (title);


--
-- Name: amenities amenities_title_key451; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key451 UNIQUE (title);


--
-- Name: amenities amenities_title_key452; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key452 UNIQUE (title);


--
-- Name: amenities amenities_title_key453; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key453 UNIQUE (title);


--
-- Name: amenities amenities_title_key454; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key454 UNIQUE (title);


--
-- Name: amenities amenities_title_key455; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key455 UNIQUE (title);


--
-- Name: amenities amenities_title_key456; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key456 UNIQUE (title);


--
-- Name: amenities amenities_title_key457; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key457 UNIQUE (title);


--
-- Name: amenities amenities_title_key458; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key458 UNIQUE (title);


--
-- Name: amenities amenities_title_key459; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key459 UNIQUE (title);


--
-- Name: amenities amenities_title_key46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key46 UNIQUE (title);


--
-- Name: amenities amenities_title_key460; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key460 UNIQUE (title);


--
-- Name: amenities amenities_title_key461; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key461 UNIQUE (title);


--
-- Name: amenities amenities_title_key462; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key462 UNIQUE (title);


--
-- Name: amenities amenities_title_key463; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key463 UNIQUE (title);


--
-- Name: amenities amenities_title_key464; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key464 UNIQUE (title);


--
-- Name: amenities amenities_title_key465; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key465 UNIQUE (title);


--
-- Name: amenities amenities_title_key466; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key466 UNIQUE (title);


--
-- Name: amenities amenities_title_key467; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key467 UNIQUE (title);


--
-- Name: amenities amenities_title_key468; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key468 UNIQUE (title);


--
-- Name: amenities amenities_title_key469; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key469 UNIQUE (title);


--
-- Name: amenities amenities_title_key47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key47 UNIQUE (title);


--
-- Name: amenities amenities_title_key470; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key470 UNIQUE (title);


--
-- Name: amenities amenities_title_key471; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key471 UNIQUE (title);


--
-- Name: amenities amenities_title_key472; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key472 UNIQUE (title);


--
-- Name: amenities amenities_title_key473; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key473 UNIQUE (title);


--
-- Name: amenities amenities_title_key474; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key474 UNIQUE (title);


--
-- Name: amenities amenities_title_key475; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key475 UNIQUE (title);


--
-- Name: amenities amenities_title_key476; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key476 UNIQUE (title);


--
-- Name: amenities amenities_title_key477; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key477 UNIQUE (title);


--
-- Name: amenities amenities_title_key478; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key478 UNIQUE (title);


--
-- Name: amenities amenities_title_key479; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key479 UNIQUE (title);


--
-- Name: amenities amenities_title_key48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key48 UNIQUE (title);


--
-- Name: amenities amenities_title_key480; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key480 UNIQUE (title);


--
-- Name: amenities amenities_title_key481; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key481 UNIQUE (title);


--
-- Name: amenities amenities_title_key482; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key482 UNIQUE (title);


--
-- Name: amenities amenities_title_key483; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key483 UNIQUE (title);


--
-- Name: amenities amenities_title_key484; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key484 UNIQUE (title);


--
-- Name: amenities amenities_title_key485; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key485 UNIQUE (title);


--
-- Name: amenities amenities_title_key486; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key486 UNIQUE (title);


--
-- Name: amenities amenities_title_key487; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key487 UNIQUE (title);


--
-- Name: amenities amenities_title_key488; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key488 UNIQUE (title);


--
-- Name: amenities amenities_title_key489; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key489 UNIQUE (title);


--
-- Name: amenities amenities_title_key49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key49 UNIQUE (title);


--
-- Name: amenities amenities_title_key490; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key490 UNIQUE (title);


--
-- Name: amenities amenities_title_key491; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key491 UNIQUE (title);


--
-- Name: amenities amenities_title_key492; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key492 UNIQUE (title);


--
-- Name: amenities amenities_title_key493; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key493 UNIQUE (title);


--
-- Name: amenities amenities_title_key494; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key494 UNIQUE (title);


--
-- Name: amenities amenities_title_key495; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key495 UNIQUE (title);


--
-- Name: amenities amenities_title_key496; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key496 UNIQUE (title);


--
-- Name: amenities amenities_title_key497; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key497 UNIQUE (title);


--
-- Name: amenities amenities_title_key498; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key498 UNIQUE (title);


--
-- Name: amenities amenities_title_key499; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key499 UNIQUE (title);


--
-- Name: amenities amenities_title_key5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key5 UNIQUE (title);


--
-- Name: amenities amenities_title_key50; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key50 UNIQUE (title);


--
-- Name: amenities amenities_title_key500; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key500 UNIQUE (title);


--
-- Name: amenities amenities_title_key501; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key501 UNIQUE (title);


--
-- Name: amenities amenities_title_key502; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key502 UNIQUE (title);


--
-- Name: amenities amenities_title_key503; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key503 UNIQUE (title);


--
-- Name: amenities amenities_title_key504; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key504 UNIQUE (title);


--
-- Name: amenities amenities_title_key505; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key505 UNIQUE (title);


--
-- Name: amenities amenities_title_key506; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key506 UNIQUE (title);


--
-- Name: amenities amenities_title_key507; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key507 UNIQUE (title);


--
-- Name: amenities amenities_title_key508; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key508 UNIQUE (title);


--
-- Name: amenities amenities_title_key509; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key509 UNIQUE (title);


--
-- Name: amenities amenities_title_key51; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key51 UNIQUE (title);


--
-- Name: amenities amenities_title_key510; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key510 UNIQUE (title);


--
-- Name: amenities amenities_title_key511; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key511 UNIQUE (title);


--
-- Name: amenities amenities_title_key512; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key512 UNIQUE (title);


--
-- Name: amenities amenities_title_key513; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key513 UNIQUE (title);


--
-- Name: amenities amenities_title_key514; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key514 UNIQUE (title);


--
-- Name: amenities amenities_title_key515; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key515 UNIQUE (title);


--
-- Name: amenities amenities_title_key516; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key516 UNIQUE (title);


--
-- Name: amenities amenities_title_key517; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key517 UNIQUE (title);


--
-- Name: amenities amenities_title_key518; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key518 UNIQUE (title);


--
-- Name: amenities amenities_title_key519; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key519 UNIQUE (title);


--
-- Name: amenities amenities_title_key52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key52 UNIQUE (title);


--
-- Name: amenities amenities_title_key520; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key520 UNIQUE (title);


--
-- Name: amenities amenities_title_key521; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key521 UNIQUE (title);


--
-- Name: amenities amenities_title_key522; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key522 UNIQUE (title);


--
-- Name: amenities amenities_title_key523; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key523 UNIQUE (title);


--
-- Name: amenities amenities_title_key524; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key524 UNIQUE (title);


--
-- Name: amenities amenities_title_key525; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key525 UNIQUE (title);


--
-- Name: amenities amenities_title_key526; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key526 UNIQUE (title);


--
-- Name: amenities amenities_title_key527; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key527 UNIQUE (title);


--
-- Name: amenities amenities_title_key528; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key528 UNIQUE (title);


--
-- Name: amenities amenities_title_key529; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key529 UNIQUE (title);


--
-- Name: amenities amenities_title_key53; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key53 UNIQUE (title);


--
-- Name: amenities amenities_title_key530; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key530 UNIQUE (title);


--
-- Name: amenities amenities_title_key531; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key531 UNIQUE (title);


--
-- Name: amenities amenities_title_key532; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key532 UNIQUE (title);


--
-- Name: amenities amenities_title_key533; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key533 UNIQUE (title);


--
-- Name: amenities amenities_title_key534; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key534 UNIQUE (title);


--
-- Name: amenities amenities_title_key535; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key535 UNIQUE (title);


--
-- Name: amenities amenities_title_key536; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key536 UNIQUE (title);


--
-- Name: amenities amenities_title_key537; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key537 UNIQUE (title);


--
-- Name: amenities amenities_title_key538; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key538 UNIQUE (title);


--
-- Name: amenities amenities_title_key539; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key539 UNIQUE (title);


--
-- Name: amenities amenities_title_key54; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key54 UNIQUE (title);


--
-- Name: amenities amenities_title_key540; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key540 UNIQUE (title);


--
-- Name: amenities amenities_title_key541; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key541 UNIQUE (title);


--
-- Name: amenities amenities_title_key542; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key542 UNIQUE (title);


--
-- Name: amenities amenities_title_key543; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key543 UNIQUE (title);


--
-- Name: amenities amenities_title_key544; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key544 UNIQUE (title);


--
-- Name: amenities amenities_title_key545; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key545 UNIQUE (title);


--
-- Name: amenities amenities_title_key546; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key546 UNIQUE (title);


--
-- Name: amenities amenities_title_key547; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key547 UNIQUE (title);


--
-- Name: amenities amenities_title_key548; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key548 UNIQUE (title);


--
-- Name: amenities amenities_title_key549; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key549 UNIQUE (title);


--
-- Name: amenities amenities_title_key55; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key55 UNIQUE (title);


--
-- Name: amenities amenities_title_key550; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key550 UNIQUE (title);


--
-- Name: amenities amenities_title_key551; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key551 UNIQUE (title);


--
-- Name: amenities amenities_title_key552; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key552 UNIQUE (title);


--
-- Name: amenities amenities_title_key553; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key553 UNIQUE (title);


--
-- Name: amenities amenities_title_key554; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key554 UNIQUE (title);


--
-- Name: amenities amenities_title_key555; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key555 UNIQUE (title);


--
-- Name: amenities amenities_title_key556; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key556 UNIQUE (title);


--
-- Name: amenities amenities_title_key557; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key557 UNIQUE (title);


--
-- Name: amenities amenities_title_key558; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key558 UNIQUE (title);


--
-- Name: amenities amenities_title_key559; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key559 UNIQUE (title);


--
-- Name: amenities amenities_title_key56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key56 UNIQUE (title);


--
-- Name: amenities amenities_title_key560; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key560 UNIQUE (title);


--
-- Name: amenities amenities_title_key561; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key561 UNIQUE (title);


--
-- Name: amenities amenities_title_key562; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key562 UNIQUE (title);


--
-- Name: amenities amenities_title_key563; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key563 UNIQUE (title);


--
-- Name: amenities amenities_title_key564; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key564 UNIQUE (title);


--
-- Name: amenities amenities_title_key565; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key565 UNIQUE (title);


--
-- Name: amenities amenities_title_key566; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key566 UNIQUE (title);


--
-- Name: amenities amenities_title_key567; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key567 UNIQUE (title);


--
-- Name: amenities amenities_title_key568; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key568 UNIQUE (title);


--
-- Name: amenities amenities_title_key569; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key569 UNIQUE (title);


--
-- Name: amenities amenities_title_key57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key57 UNIQUE (title);


--
-- Name: amenities amenities_title_key570; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key570 UNIQUE (title);


--
-- Name: amenities amenities_title_key571; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key571 UNIQUE (title);


--
-- Name: amenities amenities_title_key572; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key572 UNIQUE (title);


--
-- Name: amenities amenities_title_key573; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key573 UNIQUE (title);


--
-- Name: amenities amenities_title_key574; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key574 UNIQUE (title);


--
-- Name: amenities amenities_title_key575; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key575 UNIQUE (title);


--
-- Name: amenities amenities_title_key576; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key576 UNIQUE (title);


--
-- Name: amenities amenities_title_key577; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key577 UNIQUE (title);


--
-- Name: amenities amenities_title_key578; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key578 UNIQUE (title);


--
-- Name: amenities amenities_title_key579; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key579 UNIQUE (title);


--
-- Name: amenities amenities_title_key58; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key58 UNIQUE (title);


--
-- Name: amenities amenities_title_key580; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key580 UNIQUE (title);


--
-- Name: amenities amenities_title_key581; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key581 UNIQUE (title);


--
-- Name: amenities amenities_title_key582; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key582 UNIQUE (title);


--
-- Name: amenities amenities_title_key583; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key583 UNIQUE (title);


--
-- Name: amenities amenities_title_key584; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key584 UNIQUE (title);


--
-- Name: amenities amenities_title_key585; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key585 UNIQUE (title);


--
-- Name: amenities amenities_title_key586; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key586 UNIQUE (title);


--
-- Name: amenities amenities_title_key587; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key587 UNIQUE (title);


--
-- Name: amenities amenities_title_key588; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key588 UNIQUE (title);


--
-- Name: amenities amenities_title_key589; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key589 UNIQUE (title);


--
-- Name: amenities amenities_title_key59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key59 UNIQUE (title);


--
-- Name: amenities amenities_title_key590; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key590 UNIQUE (title);


--
-- Name: amenities amenities_title_key591; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key591 UNIQUE (title);


--
-- Name: amenities amenities_title_key592; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key592 UNIQUE (title);


--
-- Name: amenities amenities_title_key593; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key593 UNIQUE (title);


--
-- Name: amenities amenities_title_key594; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key594 UNIQUE (title);


--
-- Name: amenities amenities_title_key595; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key595 UNIQUE (title);


--
-- Name: amenities amenities_title_key596; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key596 UNIQUE (title);


--
-- Name: amenities amenities_title_key597; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key597 UNIQUE (title);


--
-- Name: amenities amenities_title_key598; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key598 UNIQUE (title);


--
-- Name: amenities amenities_title_key599; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key599 UNIQUE (title);


--
-- Name: amenities amenities_title_key6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key6 UNIQUE (title);


--
-- Name: amenities amenities_title_key60; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key60 UNIQUE (title);


--
-- Name: amenities amenities_title_key600; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key600 UNIQUE (title);


--
-- Name: amenities amenities_title_key601; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key601 UNIQUE (title);


--
-- Name: amenities amenities_title_key602; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key602 UNIQUE (title);


--
-- Name: amenities amenities_title_key603; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key603 UNIQUE (title);


--
-- Name: amenities amenities_title_key604; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key604 UNIQUE (title);


--
-- Name: amenities amenities_title_key605; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key605 UNIQUE (title);


--
-- Name: amenities amenities_title_key606; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key606 UNIQUE (title);


--
-- Name: amenities amenities_title_key607; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key607 UNIQUE (title);


--
-- Name: amenities amenities_title_key608; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key608 UNIQUE (title);


--
-- Name: amenities amenities_title_key609; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key609 UNIQUE (title);


--
-- Name: amenities amenities_title_key61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key61 UNIQUE (title);


--
-- Name: amenities amenities_title_key610; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key610 UNIQUE (title);


--
-- Name: amenities amenities_title_key611; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key611 UNIQUE (title);


--
-- Name: amenities amenities_title_key612; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key612 UNIQUE (title);


--
-- Name: amenities amenities_title_key613; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key613 UNIQUE (title);


--
-- Name: amenities amenities_title_key614; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key614 UNIQUE (title);


--
-- Name: amenities amenities_title_key615; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key615 UNIQUE (title);


--
-- Name: amenities amenities_title_key616; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key616 UNIQUE (title);


--
-- Name: amenities amenities_title_key617; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key617 UNIQUE (title);


--
-- Name: amenities amenities_title_key618; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key618 UNIQUE (title);


--
-- Name: amenities amenities_title_key619; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key619 UNIQUE (title);


--
-- Name: amenities amenities_title_key62; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key62 UNIQUE (title);


--
-- Name: amenities amenities_title_key620; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key620 UNIQUE (title);


--
-- Name: amenities amenities_title_key621; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key621 UNIQUE (title);


--
-- Name: amenities amenities_title_key622; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key622 UNIQUE (title);


--
-- Name: amenities amenities_title_key623; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key623 UNIQUE (title);


--
-- Name: amenities amenities_title_key624; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key624 UNIQUE (title);


--
-- Name: amenities amenities_title_key625; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key625 UNIQUE (title);


--
-- Name: amenities amenities_title_key626; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key626 UNIQUE (title);


--
-- Name: amenities amenities_title_key627; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key627 UNIQUE (title);


--
-- Name: amenities amenities_title_key628; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key628 UNIQUE (title);


--
-- Name: amenities amenities_title_key629; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key629 UNIQUE (title);


--
-- Name: amenities amenities_title_key63; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key63 UNIQUE (title);


--
-- Name: amenities amenities_title_key630; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key630 UNIQUE (title);


--
-- Name: amenities amenities_title_key64; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key64 UNIQUE (title);


--
-- Name: amenities amenities_title_key65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key65 UNIQUE (title);


--
-- Name: amenities amenities_title_key66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key66 UNIQUE (title);


--
-- Name: amenities amenities_title_key67; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key67 UNIQUE (title);


--
-- Name: amenities amenities_title_key68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key68 UNIQUE (title);


--
-- Name: amenities amenities_title_key69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key69 UNIQUE (title);


--
-- Name: amenities amenities_title_key7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key7 UNIQUE (title);


--
-- Name: amenities amenities_title_key70; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key70 UNIQUE (title);


--
-- Name: amenities amenities_title_key71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key71 UNIQUE (title);


--
-- Name: amenities amenities_title_key72; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key72 UNIQUE (title);


--
-- Name: amenities amenities_title_key73; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key73 UNIQUE (title);


--
-- Name: amenities amenities_title_key74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key74 UNIQUE (title);


--
-- Name: amenities amenities_title_key75; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key75 UNIQUE (title);


--
-- Name: amenities amenities_title_key76; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key76 UNIQUE (title);


--
-- Name: amenities amenities_title_key77; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key77 UNIQUE (title);


--
-- Name: amenities amenities_title_key78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key78 UNIQUE (title);


--
-- Name: amenities amenities_title_key79; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key79 UNIQUE (title);


--
-- Name: amenities amenities_title_key8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key8 UNIQUE (title);


--
-- Name: amenities amenities_title_key80; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key80 UNIQUE (title);


--
-- Name: amenities amenities_title_key81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key81 UNIQUE (title);


--
-- Name: amenities amenities_title_key82; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key82 UNIQUE (title);


--
-- Name: amenities amenities_title_key83; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key83 UNIQUE (title);


--
-- Name: amenities amenities_title_key84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key84 UNIQUE (title);


--
-- Name: amenities amenities_title_key85; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key85 UNIQUE (title);


--
-- Name: amenities amenities_title_key86; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key86 UNIQUE (title);


--
-- Name: amenities amenities_title_key87; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key87 UNIQUE (title);


--
-- Name: amenities amenities_title_key88; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key88 UNIQUE (title);


--
-- Name: amenities amenities_title_key89; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key89 UNIQUE (title);


--
-- Name: amenities amenities_title_key9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key9 UNIQUE (title);


--
-- Name: amenities amenities_title_key90; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key90 UNIQUE (title);


--
-- Name: amenities amenities_title_key91; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key91 UNIQUE (title);


--
-- Name: amenities amenities_title_key92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key92 UNIQUE (title);


--
-- Name: amenities amenities_title_key93; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key93 UNIQUE (title);


--
-- Name: amenities amenities_title_key94; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key94 UNIQUE (title);


--
-- Name: amenities amenities_title_key95; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key95 UNIQUE (title);


--
-- Name: amenities amenities_title_key96; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key96 UNIQUE (title);


--
-- Name: amenities amenities_title_key97; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key97 UNIQUE (title);


--
-- Name: amenities amenities_title_key98; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key98 UNIQUE (title);


--
-- Name: amenities amenities_title_key99; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.amenities
    ADD CONSTRAINT amenities_title_key99 UNIQUE (title);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: hero_sliders hero_sliders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hero_sliders
    ADD CONSTRAINT hero_sliders_pkey PRIMARY KEY (id);


--
-- Name: interior_articles interior_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interior_articles
    ADD CONSTRAINT interior_articles_pkey PRIMARY KEY (id);


--
-- Name: interior_designers interior_designers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.interior_designers
    ADD CONSTRAINT interior_designers_pkey PRIMARY KEY (id);


--
-- Name: jantri_rates jantri_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jantri_rates
    ADD CONSTRAINT jantri_rates_pkey PRIMARY KEY (id);


--
-- Name: locality_reviews locality_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locality_reviews
    ADD CONSTRAINT locality_reviews_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_amenities property_amenities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_amenities
    ADD CONSTRAINT property_amenities_pkey PRIMARY KEY ("amenityId", "propertyId");


--
-- Name: property_faqs property_faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_faqs
    ADD CONSTRAINT property_faqs_pkey PRIMARY KEY (id);


--
-- Name: property_images property_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT property_images_pkey PRIMARY KEY (id);


--
-- Name: property_types property_types_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key UNIQUE (name);


--
-- Name: property_types property_types_name_key1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key1 UNIQUE (name);


--
-- Name: property_types property_types_name_key10; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key10 UNIQUE (name);


--
-- Name: property_types property_types_name_key100; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key100 UNIQUE (name);


--
-- Name: property_types property_types_name_key101; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key101 UNIQUE (name);


--
-- Name: property_types property_types_name_key102; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key102 UNIQUE (name);


--
-- Name: property_types property_types_name_key103; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key103 UNIQUE (name);


--
-- Name: property_types property_types_name_key104; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key104 UNIQUE (name);


--
-- Name: property_types property_types_name_key105; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key105 UNIQUE (name);


--
-- Name: property_types property_types_name_key106; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key106 UNIQUE (name);


--
-- Name: property_types property_types_name_key107; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key107 UNIQUE (name);


--
-- Name: property_types property_types_name_key108; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key108 UNIQUE (name);


--
-- Name: property_types property_types_name_key109; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key109 UNIQUE (name);


--
-- Name: property_types property_types_name_key11; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key11 UNIQUE (name);


--
-- Name: property_types property_types_name_key110; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key110 UNIQUE (name);


--
-- Name: property_types property_types_name_key111; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key111 UNIQUE (name);


--
-- Name: property_types property_types_name_key112; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key112 UNIQUE (name);


--
-- Name: property_types property_types_name_key113; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key113 UNIQUE (name);


--
-- Name: property_types property_types_name_key114; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key114 UNIQUE (name);


--
-- Name: property_types property_types_name_key115; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key115 UNIQUE (name);


--
-- Name: property_types property_types_name_key116; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key116 UNIQUE (name);


--
-- Name: property_types property_types_name_key117; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key117 UNIQUE (name);


--
-- Name: property_types property_types_name_key118; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key118 UNIQUE (name);


--
-- Name: property_types property_types_name_key119; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key119 UNIQUE (name);


--
-- Name: property_types property_types_name_key12; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key12 UNIQUE (name);


--
-- Name: property_types property_types_name_key120; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key120 UNIQUE (name);


--
-- Name: property_types property_types_name_key121; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key121 UNIQUE (name);


--
-- Name: property_types property_types_name_key122; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key122 UNIQUE (name);


--
-- Name: property_types property_types_name_key123; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key123 UNIQUE (name);


--
-- Name: property_types property_types_name_key124; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key124 UNIQUE (name);


--
-- Name: property_types property_types_name_key125; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key125 UNIQUE (name);


--
-- Name: property_types property_types_name_key126; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key126 UNIQUE (name);


--
-- Name: property_types property_types_name_key127; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key127 UNIQUE (name);


--
-- Name: property_types property_types_name_key128; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key128 UNIQUE (name);


--
-- Name: property_types property_types_name_key129; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key129 UNIQUE (name);


--
-- Name: property_types property_types_name_key13; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key13 UNIQUE (name);


--
-- Name: property_types property_types_name_key130; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key130 UNIQUE (name);


--
-- Name: property_types property_types_name_key131; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key131 UNIQUE (name);


--
-- Name: property_types property_types_name_key132; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key132 UNIQUE (name);


--
-- Name: property_types property_types_name_key133; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key133 UNIQUE (name);


--
-- Name: property_types property_types_name_key134; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key134 UNIQUE (name);


--
-- Name: property_types property_types_name_key135; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key135 UNIQUE (name);


--
-- Name: property_types property_types_name_key136; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key136 UNIQUE (name);


--
-- Name: property_types property_types_name_key137; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key137 UNIQUE (name);


--
-- Name: property_types property_types_name_key138; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key138 UNIQUE (name);


--
-- Name: property_types property_types_name_key139; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key139 UNIQUE (name);


--
-- Name: property_types property_types_name_key14; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key14 UNIQUE (name);


--
-- Name: property_types property_types_name_key140; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key140 UNIQUE (name);


--
-- Name: property_types property_types_name_key141; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key141 UNIQUE (name);


--
-- Name: property_types property_types_name_key142; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key142 UNIQUE (name);


--
-- Name: property_types property_types_name_key143; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key143 UNIQUE (name);


--
-- Name: property_types property_types_name_key144; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key144 UNIQUE (name);


--
-- Name: property_types property_types_name_key145; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key145 UNIQUE (name);


--
-- Name: property_types property_types_name_key146; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key146 UNIQUE (name);


--
-- Name: property_types property_types_name_key147; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key147 UNIQUE (name);


--
-- Name: property_types property_types_name_key148; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key148 UNIQUE (name);


--
-- Name: property_types property_types_name_key149; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key149 UNIQUE (name);


--
-- Name: property_types property_types_name_key15; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key15 UNIQUE (name);


--
-- Name: property_types property_types_name_key150; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key150 UNIQUE (name);


--
-- Name: property_types property_types_name_key151; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key151 UNIQUE (name);


--
-- Name: property_types property_types_name_key152; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key152 UNIQUE (name);


--
-- Name: property_types property_types_name_key153; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key153 UNIQUE (name);


--
-- Name: property_types property_types_name_key154; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key154 UNIQUE (name);


--
-- Name: property_types property_types_name_key155; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key155 UNIQUE (name);


--
-- Name: property_types property_types_name_key156; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key156 UNIQUE (name);


--
-- Name: property_types property_types_name_key157; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key157 UNIQUE (name);


--
-- Name: property_types property_types_name_key158; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key158 UNIQUE (name);


--
-- Name: property_types property_types_name_key159; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key159 UNIQUE (name);


--
-- Name: property_types property_types_name_key16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key16 UNIQUE (name);


--
-- Name: property_types property_types_name_key160; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key160 UNIQUE (name);


--
-- Name: property_types property_types_name_key161; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key161 UNIQUE (name);


--
-- Name: property_types property_types_name_key162; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key162 UNIQUE (name);


--
-- Name: property_types property_types_name_key163; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key163 UNIQUE (name);


--
-- Name: property_types property_types_name_key164; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key164 UNIQUE (name);


--
-- Name: property_types property_types_name_key165; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key165 UNIQUE (name);


--
-- Name: property_types property_types_name_key166; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key166 UNIQUE (name);


--
-- Name: property_types property_types_name_key167; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key167 UNIQUE (name);


--
-- Name: property_types property_types_name_key168; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key168 UNIQUE (name);


--
-- Name: property_types property_types_name_key169; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key169 UNIQUE (name);


--
-- Name: property_types property_types_name_key17; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key17 UNIQUE (name);


--
-- Name: property_types property_types_name_key170; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key170 UNIQUE (name);


--
-- Name: property_types property_types_name_key171; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key171 UNIQUE (name);


--
-- Name: property_types property_types_name_key172; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key172 UNIQUE (name);


--
-- Name: property_types property_types_name_key173; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key173 UNIQUE (name);


--
-- Name: property_types property_types_name_key174; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key174 UNIQUE (name);


--
-- Name: property_types property_types_name_key175; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key175 UNIQUE (name);


--
-- Name: property_types property_types_name_key176; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key176 UNIQUE (name);


--
-- Name: property_types property_types_name_key177; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key177 UNIQUE (name);


--
-- Name: property_types property_types_name_key178; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key178 UNIQUE (name);


--
-- Name: property_types property_types_name_key179; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key179 UNIQUE (name);


--
-- Name: property_types property_types_name_key18; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key18 UNIQUE (name);


--
-- Name: property_types property_types_name_key180; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key180 UNIQUE (name);


--
-- Name: property_types property_types_name_key181; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key181 UNIQUE (name);


--
-- Name: property_types property_types_name_key182; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key182 UNIQUE (name);


--
-- Name: property_types property_types_name_key183; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key183 UNIQUE (name);


--
-- Name: property_types property_types_name_key184; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key184 UNIQUE (name);


--
-- Name: property_types property_types_name_key185; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key185 UNIQUE (name);


--
-- Name: property_types property_types_name_key186; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key186 UNIQUE (name);


--
-- Name: property_types property_types_name_key187; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key187 UNIQUE (name);


--
-- Name: property_types property_types_name_key188; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key188 UNIQUE (name);


--
-- Name: property_types property_types_name_key189; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key189 UNIQUE (name);


--
-- Name: property_types property_types_name_key19; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key19 UNIQUE (name);


--
-- Name: property_types property_types_name_key190; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key190 UNIQUE (name);


--
-- Name: property_types property_types_name_key191; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key191 UNIQUE (name);


--
-- Name: property_types property_types_name_key192; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key192 UNIQUE (name);


--
-- Name: property_types property_types_name_key193; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key193 UNIQUE (name);


--
-- Name: property_types property_types_name_key194; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key194 UNIQUE (name);


--
-- Name: property_types property_types_name_key195; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key195 UNIQUE (name);


--
-- Name: property_types property_types_name_key196; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key196 UNIQUE (name);


--
-- Name: property_types property_types_name_key197; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key197 UNIQUE (name);


--
-- Name: property_types property_types_name_key198; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key198 UNIQUE (name);


--
-- Name: property_types property_types_name_key199; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key199 UNIQUE (name);


--
-- Name: property_types property_types_name_key2; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key2 UNIQUE (name);


--
-- Name: property_types property_types_name_key20; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key20 UNIQUE (name);


--
-- Name: property_types property_types_name_key200; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key200 UNIQUE (name);


--
-- Name: property_types property_types_name_key201; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key201 UNIQUE (name);


--
-- Name: property_types property_types_name_key202; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key202 UNIQUE (name);


--
-- Name: property_types property_types_name_key203; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key203 UNIQUE (name);


--
-- Name: property_types property_types_name_key204; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key204 UNIQUE (name);


--
-- Name: property_types property_types_name_key205; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key205 UNIQUE (name);


--
-- Name: property_types property_types_name_key206; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key206 UNIQUE (name);


--
-- Name: property_types property_types_name_key207; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key207 UNIQUE (name);


--
-- Name: property_types property_types_name_key208; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key208 UNIQUE (name);


--
-- Name: property_types property_types_name_key209; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key209 UNIQUE (name);


--
-- Name: property_types property_types_name_key21; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key21 UNIQUE (name);


--
-- Name: property_types property_types_name_key210; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key210 UNIQUE (name);


--
-- Name: property_types property_types_name_key211; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key211 UNIQUE (name);


--
-- Name: property_types property_types_name_key212; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key212 UNIQUE (name);


--
-- Name: property_types property_types_name_key213; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key213 UNIQUE (name);


--
-- Name: property_types property_types_name_key214; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key214 UNIQUE (name);


--
-- Name: property_types property_types_name_key215; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key215 UNIQUE (name);


--
-- Name: property_types property_types_name_key216; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key216 UNIQUE (name);


--
-- Name: property_types property_types_name_key217; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key217 UNIQUE (name);


--
-- Name: property_types property_types_name_key218; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key218 UNIQUE (name);


--
-- Name: property_types property_types_name_key219; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key219 UNIQUE (name);


--
-- Name: property_types property_types_name_key22; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key22 UNIQUE (name);


--
-- Name: property_types property_types_name_key220; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key220 UNIQUE (name);


--
-- Name: property_types property_types_name_key221; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key221 UNIQUE (name);


--
-- Name: property_types property_types_name_key222; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key222 UNIQUE (name);


--
-- Name: property_types property_types_name_key223; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key223 UNIQUE (name);


--
-- Name: property_types property_types_name_key224; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key224 UNIQUE (name);


--
-- Name: property_types property_types_name_key225; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key225 UNIQUE (name);


--
-- Name: property_types property_types_name_key226; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key226 UNIQUE (name);


--
-- Name: property_types property_types_name_key227; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key227 UNIQUE (name);


--
-- Name: property_types property_types_name_key228; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key228 UNIQUE (name);


--
-- Name: property_types property_types_name_key229; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key229 UNIQUE (name);


--
-- Name: property_types property_types_name_key23; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key23 UNIQUE (name);


--
-- Name: property_types property_types_name_key230; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key230 UNIQUE (name);


--
-- Name: property_types property_types_name_key231; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key231 UNIQUE (name);


--
-- Name: property_types property_types_name_key232; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key232 UNIQUE (name);


--
-- Name: property_types property_types_name_key233; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key233 UNIQUE (name);


--
-- Name: property_types property_types_name_key234; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key234 UNIQUE (name);


--
-- Name: property_types property_types_name_key235; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key235 UNIQUE (name);


--
-- Name: property_types property_types_name_key236; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key236 UNIQUE (name);


--
-- Name: property_types property_types_name_key237; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key237 UNIQUE (name);


--
-- Name: property_types property_types_name_key238; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key238 UNIQUE (name);


--
-- Name: property_types property_types_name_key239; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key239 UNIQUE (name);


--
-- Name: property_types property_types_name_key24; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key24 UNIQUE (name);


--
-- Name: property_types property_types_name_key240; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key240 UNIQUE (name);


--
-- Name: property_types property_types_name_key241; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key241 UNIQUE (name);


--
-- Name: property_types property_types_name_key242; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key242 UNIQUE (name);


--
-- Name: property_types property_types_name_key243; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key243 UNIQUE (name);


--
-- Name: property_types property_types_name_key244; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key244 UNIQUE (name);


--
-- Name: property_types property_types_name_key245; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key245 UNIQUE (name);


--
-- Name: property_types property_types_name_key246; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key246 UNIQUE (name);


--
-- Name: property_types property_types_name_key247; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key247 UNIQUE (name);


--
-- Name: property_types property_types_name_key248; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key248 UNIQUE (name);


--
-- Name: property_types property_types_name_key249; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key249 UNIQUE (name);


--
-- Name: property_types property_types_name_key25; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key25 UNIQUE (name);


--
-- Name: property_types property_types_name_key250; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key250 UNIQUE (name);


--
-- Name: property_types property_types_name_key251; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key251 UNIQUE (name);


--
-- Name: property_types property_types_name_key252; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key252 UNIQUE (name);


--
-- Name: property_types property_types_name_key253; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key253 UNIQUE (name);


--
-- Name: property_types property_types_name_key254; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key254 UNIQUE (name);


--
-- Name: property_types property_types_name_key255; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key255 UNIQUE (name);


--
-- Name: property_types property_types_name_key256; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key256 UNIQUE (name);


--
-- Name: property_types property_types_name_key257; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key257 UNIQUE (name);


--
-- Name: property_types property_types_name_key258; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key258 UNIQUE (name);


--
-- Name: property_types property_types_name_key259; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key259 UNIQUE (name);


--
-- Name: property_types property_types_name_key26; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key26 UNIQUE (name);


--
-- Name: property_types property_types_name_key260; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key260 UNIQUE (name);


--
-- Name: property_types property_types_name_key261; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key261 UNIQUE (name);


--
-- Name: property_types property_types_name_key262; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key262 UNIQUE (name);


--
-- Name: property_types property_types_name_key263; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key263 UNIQUE (name);


--
-- Name: property_types property_types_name_key264; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key264 UNIQUE (name);


--
-- Name: property_types property_types_name_key265; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key265 UNIQUE (name);


--
-- Name: property_types property_types_name_key266; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key266 UNIQUE (name);


--
-- Name: property_types property_types_name_key267; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key267 UNIQUE (name);


--
-- Name: property_types property_types_name_key268; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key268 UNIQUE (name);


--
-- Name: property_types property_types_name_key269; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key269 UNIQUE (name);


--
-- Name: property_types property_types_name_key27; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key27 UNIQUE (name);


--
-- Name: property_types property_types_name_key270; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key270 UNIQUE (name);


--
-- Name: property_types property_types_name_key271; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key271 UNIQUE (name);


--
-- Name: property_types property_types_name_key272; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key272 UNIQUE (name);


--
-- Name: property_types property_types_name_key273; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key273 UNIQUE (name);


--
-- Name: property_types property_types_name_key274; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key274 UNIQUE (name);


--
-- Name: property_types property_types_name_key275; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key275 UNIQUE (name);


--
-- Name: property_types property_types_name_key276; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key276 UNIQUE (name);


--
-- Name: property_types property_types_name_key277; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key277 UNIQUE (name);


--
-- Name: property_types property_types_name_key278; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key278 UNIQUE (name);


--
-- Name: property_types property_types_name_key279; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key279 UNIQUE (name);


--
-- Name: property_types property_types_name_key28; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key28 UNIQUE (name);


--
-- Name: property_types property_types_name_key280; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key280 UNIQUE (name);


--
-- Name: property_types property_types_name_key281; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key281 UNIQUE (name);


--
-- Name: property_types property_types_name_key282; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key282 UNIQUE (name);


--
-- Name: property_types property_types_name_key283; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key283 UNIQUE (name);


--
-- Name: property_types property_types_name_key284; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key284 UNIQUE (name);


--
-- Name: property_types property_types_name_key285; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key285 UNIQUE (name);


--
-- Name: property_types property_types_name_key286; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key286 UNIQUE (name);


--
-- Name: property_types property_types_name_key287; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key287 UNIQUE (name);


--
-- Name: property_types property_types_name_key288; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key288 UNIQUE (name);


--
-- Name: property_types property_types_name_key289; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key289 UNIQUE (name);


--
-- Name: property_types property_types_name_key29; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key29 UNIQUE (name);


--
-- Name: property_types property_types_name_key290; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key290 UNIQUE (name);


--
-- Name: property_types property_types_name_key291; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key291 UNIQUE (name);


--
-- Name: property_types property_types_name_key292; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key292 UNIQUE (name);


--
-- Name: property_types property_types_name_key293; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key293 UNIQUE (name);


--
-- Name: property_types property_types_name_key294; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key294 UNIQUE (name);


--
-- Name: property_types property_types_name_key295; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key295 UNIQUE (name);


--
-- Name: property_types property_types_name_key296; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key296 UNIQUE (name);


--
-- Name: property_types property_types_name_key297; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key297 UNIQUE (name);


--
-- Name: property_types property_types_name_key298; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key298 UNIQUE (name);


--
-- Name: property_types property_types_name_key299; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key299 UNIQUE (name);


--
-- Name: property_types property_types_name_key3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key3 UNIQUE (name);


--
-- Name: property_types property_types_name_key30; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key30 UNIQUE (name);


--
-- Name: property_types property_types_name_key300; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key300 UNIQUE (name);


--
-- Name: property_types property_types_name_key301; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key301 UNIQUE (name);


--
-- Name: property_types property_types_name_key302; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key302 UNIQUE (name);


--
-- Name: property_types property_types_name_key303; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key303 UNIQUE (name);


--
-- Name: property_types property_types_name_key304; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key304 UNIQUE (name);


--
-- Name: property_types property_types_name_key305; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key305 UNIQUE (name);


--
-- Name: property_types property_types_name_key306; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key306 UNIQUE (name);


--
-- Name: property_types property_types_name_key307; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key307 UNIQUE (name);


--
-- Name: property_types property_types_name_key308; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key308 UNIQUE (name);


--
-- Name: property_types property_types_name_key309; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key309 UNIQUE (name);


--
-- Name: property_types property_types_name_key31; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key31 UNIQUE (name);


--
-- Name: property_types property_types_name_key310; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key310 UNIQUE (name);


--
-- Name: property_types property_types_name_key311; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key311 UNIQUE (name);


--
-- Name: property_types property_types_name_key312; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key312 UNIQUE (name);


--
-- Name: property_types property_types_name_key313; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key313 UNIQUE (name);


--
-- Name: property_types property_types_name_key314; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key314 UNIQUE (name);


--
-- Name: property_types property_types_name_key315; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key315 UNIQUE (name);


--
-- Name: property_types property_types_name_key316; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key316 UNIQUE (name);


--
-- Name: property_types property_types_name_key317; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key317 UNIQUE (name);


--
-- Name: property_types property_types_name_key318; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key318 UNIQUE (name);


--
-- Name: property_types property_types_name_key319; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key319 UNIQUE (name);


--
-- Name: property_types property_types_name_key32; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key32 UNIQUE (name);


--
-- Name: property_types property_types_name_key320; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key320 UNIQUE (name);


--
-- Name: property_types property_types_name_key321; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key321 UNIQUE (name);


--
-- Name: property_types property_types_name_key322; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key322 UNIQUE (name);


--
-- Name: property_types property_types_name_key323; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key323 UNIQUE (name);


--
-- Name: property_types property_types_name_key324; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key324 UNIQUE (name);


--
-- Name: property_types property_types_name_key325; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key325 UNIQUE (name);


--
-- Name: property_types property_types_name_key326; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key326 UNIQUE (name);


--
-- Name: property_types property_types_name_key327; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key327 UNIQUE (name);


--
-- Name: property_types property_types_name_key328; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key328 UNIQUE (name);


--
-- Name: property_types property_types_name_key329; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key329 UNIQUE (name);


--
-- Name: property_types property_types_name_key33; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key33 UNIQUE (name);


--
-- Name: property_types property_types_name_key330; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key330 UNIQUE (name);


--
-- Name: property_types property_types_name_key331; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key331 UNIQUE (name);


--
-- Name: property_types property_types_name_key332; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key332 UNIQUE (name);


--
-- Name: property_types property_types_name_key333; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key333 UNIQUE (name);


--
-- Name: property_types property_types_name_key334; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key334 UNIQUE (name);


--
-- Name: property_types property_types_name_key335; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key335 UNIQUE (name);


--
-- Name: property_types property_types_name_key336; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key336 UNIQUE (name);


--
-- Name: property_types property_types_name_key337; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key337 UNIQUE (name);


--
-- Name: property_types property_types_name_key338; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key338 UNIQUE (name);


--
-- Name: property_types property_types_name_key339; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key339 UNIQUE (name);


--
-- Name: property_types property_types_name_key34; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key34 UNIQUE (name);


--
-- Name: property_types property_types_name_key340; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key340 UNIQUE (name);


--
-- Name: property_types property_types_name_key341; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key341 UNIQUE (name);


--
-- Name: property_types property_types_name_key342; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key342 UNIQUE (name);


--
-- Name: property_types property_types_name_key343; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key343 UNIQUE (name);


--
-- Name: property_types property_types_name_key344; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key344 UNIQUE (name);


--
-- Name: property_types property_types_name_key345; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key345 UNIQUE (name);


--
-- Name: property_types property_types_name_key346; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key346 UNIQUE (name);


--
-- Name: property_types property_types_name_key347; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key347 UNIQUE (name);


--
-- Name: property_types property_types_name_key348; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key348 UNIQUE (name);


--
-- Name: property_types property_types_name_key349; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key349 UNIQUE (name);


--
-- Name: property_types property_types_name_key35; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key35 UNIQUE (name);


--
-- Name: property_types property_types_name_key350; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key350 UNIQUE (name);


--
-- Name: property_types property_types_name_key351; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key351 UNIQUE (name);


--
-- Name: property_types property_types_name_key352; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key352 UNIQUE (name);


--
-- Name: property_types property_types_name_key353; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key353 UNIQUE (name);


--
-- Name: property_types property_types_name_key354; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key354 UNIQUE (name);


--
-- Name: property_types property_types_name_key355; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key355 UNIQUE (name);


--
-- Name: property_types property_types_name_key356; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key356 UNIQUE (name);


--
-- Name: property_types property_types_name_key357; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key357 UNIQUE (name);


--
-- Name: property_types property_types_name_key358; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key358 UNIQUE (name);


--
-- Name: property_types property_types_name_key359; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key359 UNIQUE (name);


--
-- Name: property_types property_types_name_key36; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key36 UNIQUE (name);


--
-- Name: property_types property_types_name_key360; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key360 UNIQUE (name);


--
-- Name: property_types property_types_name_key361; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key361 UNIQUE (name);


--
-- Name: property_types property_types_name_key362; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key362 UNIQUE (name);


--
-- Name: property_types property_types_name_key363; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key363 UNIQUE (name);


--
-- Name: property_types property_types_name_key364; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key364 UNIQUE (name);


--
-- Name: property_types property_types_name_key365; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key365 UNIQUE (name);


--
-- Name: property_types property_types_name_key366; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key366 UNIQUE (name);


--
-- Name: property_types property_types_name_key367; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key367 UNIQUE (name);


--
-- Name: property_types property_types_name_key368; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key368 UNIQUE (name);


--
-- Name: property_types property_types_name_key369; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key369 UNIQUE (name);


--
-- Name: property_types property_types_name_key37; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key37 UNIQUE (name);


--
-- Name: property_types property_types_name_key370; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key370 UNIQUE (name);


--
-- Name: property_types property_types_name_key371; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key371 UNIQUE (name);


--
-- Name: property_types property_types_name_key372; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key372 UNIQUE (name);


--
-- Name: property_types property_types_name_key373; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key373 UNIQUE (name);


--
-- Name: property_types property_types_name_key374; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key374 UNIQUE (name);


--
-- Name: property_types property_types_name_key375; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key375 UNIQUE (name);


--
-- Name: property_types property_types_name_key376; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key376 UNIQUE (name);


--
-- Name: property_types property_types_name_key377; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key377 UNIQUE (name);


--
-- Name: property_types property_types_name_key378; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key378 UNIQUE (name);


--
-- Name: property_types property_types_name_key379; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key379 UNIQUE (name);


--
-- Name: property_types property_types_name_key38; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key38 UNIQUE (name);


--
-- Name: property_types property_types_name_key380; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key380 UNIQUE (name);


--
-- Name: property_types property_types_name_key381; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key381 UNIQUE (name);


--
-- Name: property_types property_types_name_key382; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key382 UNIQUE (name);


--
-- Name: property_types property_types_name_key383; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key383 UNIQUE (name);


--
-- Name: property_types property_types_name_key384; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key384 UNIQUE (name);


--
-- Name: property_types property_types_name_key385; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key385 UNIQUE (name);


--
-- Name: property_types property_types_name_key386; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key386 UNIQUE (name);


--
-- Name: property_types property_types_name_key387; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key387 UNIQUE (name);


--
-- Name: property_types property_types_name_key388; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key388 UNIQUE (name);


--
-- Name: property_types property_types_name_key389; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key389 UNIQUE (name);


--
-- Name: property_types property_types_name_key39; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key39 UNIQUE (name);


--
-- Name: property_types property_types_name_key390; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key390 UNIQUE (name);


--
-- Name: property_types property_types_name_key391; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key391 UNIQUE (name);


--
-- Name: property_types property_types_name_key392; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key392 UNIQUE (name);


--
-- Name: property_types property_types_name_key393; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key393 UNIQUE (name);


--
-- Name: property_types property_types_name_key394; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key394 UNIQUE (name);


--
-- Name: property_types property_types_name_key395; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key395 UNIQUE (name);


--
-- Name: property_types property_types_name_key396; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key396 UNIQUE (name);


--
-- Name: property_types property_types_name_key397; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key397 UNIQUE (name);


--
-- Name: property_types property_types_name_key398; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key398 UNIQUE (name);


--
-- Name: property_types property_types_name_key399; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key399 UNIQUE (name);


--
-- Name: property_types property_types_name_key4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key4 UNIQUE (name);


--
-- Name: property_types property_types_name_key40; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key40 UNIQUE (name);


--
-- Name: property_types property_types_name_key400; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key400 UNIQUE (name);


--
-- Name: property_types property_types_name_key401; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key401 UNIQUE (name);


--
-- Name: property_types property_types_name_key402; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key402 UNIQUE (name);


--
-- Name: property_types property_types_name_key403; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key403 UNIQUE (name);


--
-- Name: property_types property_types_name_key404; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key404 UNIQUE (name);


--
-- Name: property_types property_types_name_key405; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key405 UNIQUE (name);


--
-- Name: property_types property_types_name_key406; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key406 UNIQUE (name);


--
-- Name: property_types property_types_name_key407; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key407 UNIQUE (name);


--
-- Name: property_types property_types_name_key408; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key408 UNIQUE (name);


--
-- Name: property_types property_types_name_key409; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key409 UNIQUE (name);


--
-- Name: property_types property_types_name_key41; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key41 UNIQUE (name);


--
-- Name: property_types property_types_name_key410; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key410 UNIQUE (name);


--
-- Name: property_types property_types_name_key411; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key411 UNIQUE (name);


--
-- Name: property_types property_types_name_key412; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key412 UNIQUE (name);


--
-- Name: property_types property_types_name_key413; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key413 UNIQUE (name);


--
-- Name: property_types property_types_name_key414; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key414 UNIQUE (name);


--
-- Name: property_types property_types_name_key415; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key415 UNIQUE (name);


--
-- Name: property_types property_types_name_key416; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key416 UNIQUE (name);


--
-- Name: property_types property_types_name_key417; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key417 UNIQUE (name);


--
-- Name: property_types property_types_name_key418; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key418 UNIQUE (name);


--
-- Name: property_types property_types_name_key419; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key419 UNIQUE (name);


--
-- Name: property_types property_types_name_key42; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key42 UNIQUE (name);


--
-- Name: property_types property_types_name_key420; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key420 UNIQUE (name);


--
-- Name: property_types property_types_name_key421; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key421 UNIQUE (name);


--
-- Name: property_types property_types_name_key422; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key422 UNIQUE (name);


--
-- Name: property_types property_types_name_key423; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key423 UNIQUE (name);


--
-- Name: property_types property_types_name_key424; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key424 UNIQUE (name);


--
-- Name: property_types property_types_name_key425; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key425 UNIQUE (name);


--
-- Name: property_types property_types_name_key426; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key426 UNIQUE (name);


--
-- Name: property_types property_types_name_key427; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key427 UNIQUE (name);


--
-- Name: property_types property_types_name_key428; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key428 UNIQUE (name);


--
-- Name: property_types property_types_name_key429; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key429 UNIQUE (name);


--
-- Name: property_types property_types_name_key43; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key43 UNIQUE (name);


--
-- Name: property_types property_types_name_key430; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key430 UNIQUE (name);


--
-- Name: property_types property_types_name_key431; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key431 UNIQUE (name);


--
-- Name: property_types property_types_name_key432; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key432 UNIQUE (name);


--
-- Name: property_types property_types_name_key433; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key433 UNIQUE (name);


--
-- Name: property_types property_types_name_key434; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key434 UNIQUE (name);


--
-- Name: property_types property_types_name_key435; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key435 UNIQUE (name);


--
-- Name: property_types property_types_name_key436; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key436 UNIQUE (name);


--
-- Name: property_types property_types_name_key437; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key437 UNIQUE (name);


--
-- Name: property_types property_types_name_key438; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key438 UNIQUE (name);


--
-- Name: property_types property_types_name_key439; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key439 UNIQUE (name);


--
-- Name: property_types property_types_name_key44; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key44 UNIQUE (name);


--
-- Name: property_types property_types_name_key440; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key440 UNIQUE (name);


--
-- Name: property_types property_types_name_key441; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key441 UNIQUE (name);


--
-- Name: property_types property_types_name_key442; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key442 UNIQUE (name);


--
-- Name: property_types property_types_name_key443; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key443 UNIQUE (name);


--
-- Name: property_types property_types_name_key444; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key444 UNIQUE (name);


--
-- Name: property_types property_types_name_key445; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key445 UNIQUE (name);


--
-- Name: property_types property_types_name_key446; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key446 UNIQUE (name);


--
-- Name: property_types property_types_name_key447; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key447 UNIQUE (name);


--
-- Name: property_types property_types_name_key448; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key448 UNIQUE (name);


--
-- Name: property_types property_types_name_key449; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key449 UNIQUE (name);


--
-- Name: property_types property_types_name_key45; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key45 UNIQUE (name);


--
-- Name: property_types property_types_name_key450; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key450 UNIQUE (name);


--
-- Name: property_types property_types_name_key451; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key451 UNIQUE (name);


--
-- Name: property_types property_types_name_key452; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key452 UNIQUE (name);


--
-- Name: property_types property_types_name_key453; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key453 UNIQUE (name);


--
-- Name: property_types property_types_name_key454; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key454 UNIQUE (name);


--
-- Name: property_types property_types_name_key455; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key455 UNIQUE (name);


--
-- Name: property_types property_types_name_key456; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key456 UNIQUE (name);


--
-- Name: property_types property_types_name_key457; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key457 UNIQUE (name);


--
-- Name: property_types property_types_name_key458; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key458 UNIQUE (name);


--
-- Name: property_types property_types_name_key459; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key459 UNIQUE (name);


--
-- Name: property_types property_types_name_key46; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key46 UNIQUE (name);


--
-- Name: property_types property_types_name_key460; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key460 UNIQUE (name);


--
-- Name: property_types property_types_name_key461; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key461 UNIQUE (name);


--
-- Name: property_types property_types_name_key462; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key462 UNIQUE (name);


--
-- Name: property_types property_types_name_key463; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key463 UNIQUE (name);


--
-- Name: property_types property_types_name_key464; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key464 UNIQUE (name);


--
-- Name: property_types property_types_name_key465; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key465 UNIQUE (name);


--
-- Name: property_types property_types_name_key466; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key466 UNIQUE (name);


--
-- Name: property_types property_types_name_key467; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key467 UNIQUE (name);


--
-- Name: property_types property_types_name_key468; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key468 UNIQUE (name);


--
-- Name: property_types property_types_name_key469; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key469 UNIQUE (name);


--
-- Name: property_types property_types_name_key47; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key47 UNIQUE (name);


--
-- Name: property_types property_types_name_key470; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key470 UNIQUE (name);


--
-- Name: property_types property_types_name_key471; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key471 UNIQUE (name);


--
-- Name: property_types property_types_name_key472; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key472 UNIQUE (name);


--
-- Name: property_types property_types_name_key473; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key473 UNIQUE (name);


--
-- Name: property_types property_types_name_key474; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key474 UNIQUE (name);


--
-- Name: property_types property_types_name_key475; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key475 UNIQUE (name);


--
-- Name: property_types property_types_name_key476; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key476 UNIQUE (name);


--
-- Name: property_types property_types_name_key477; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key477 UNIQUE (name);


--
-- Name: property_types property_types_name_key478; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key478 UNIQUE (name);


--
-- Name: property_types property_types_name_key479; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key479 UNIQUE (name);


--
-- Name: property_types property_types_name_key48; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key48 UNIQUE (name);


--
-- Name: property_types property_types_name_key480; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key480 UNIQUE (name);


--
-- Name: property_types property_types_name_key481; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key481 UNIQUE (name);


--
-- Name: property_types property_types_name_key482; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key482 UNIQUE (name);


--
-- Name: property_types property_types_name_key483; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key483 UNIQUE (name);


--
-- Name: property_types property_types_name_key484; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key484 UNIQUE (name);


--
-- Name: property_types property_types_name_key485; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key485 UNIQUE (name);


--
-- Name: property_types property_types_name_key486; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key486 UNIQUE (name);


--
-- Name: property_types property_types_name_key487; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key487 UNIQUE (name);


--
-- Name: property_types property_types_name_key488; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key488 UNIQUE (name);


--
-- Name: property_types property_types_name_key489; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key489 UNIQUE (name);


--
-- Name: property_types property_types_name_key49; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key49 UNIQUE (name);


--
-- Name: property_types property_types_name_key490; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key490 UNIQUE (name);


--
-- Name: property_types property_types_name_key491; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key491 UNIQUE (name);


--
-- Name: property_types property_types_name_key492; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key492 UNIQUE (name);


--
-- Name: property_types property_types_name_key493; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key493 UNIQUE (name);


--
-- Name: property_types property_types_name_key494; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key494 UNIQUE (name);


--
-- Name: property_types property_types_name_key495; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key495 UNIQUE (name);


--
-- Name: property_types property_types_name_key496; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key496 UNIQUE (name);


--
-- Name: property_types property_types_name_key497; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key497 UNIQUE (name);


--
-- Name: property_types property_types_name_key498; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key498 UNIQUE (name);


--
-- Name: property_types property_types_name_key499; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key499 UNIQUE (name);


--
-- Name: property_types property_types_name_key5; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key5 UNIQUE (name);


--
-- Name: property_types property_types_name_key50; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key50 UNIQUE (name);


--
-- Name: property_types property_types_name_key500; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key500 UNIQUE (name);


--
-- Name: property_types property_types_name_key501; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key501 UNIQUE (name);


--
-- Name: property_types property_types_name_key502; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key502 UNIQUE (name);


--
-- Name: property_types property_types_name_key503; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key503 UNIQUE (name);


--
-- Name: property_types property_types_name_key504; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key504 UNIQUE (name);


--
-- Name: property_types property_types_name_key505; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key505 UNIQUE (name);


--
-- Name: property_types property_types_name_key506; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key506 UNIQUE (name);


--
-- Name: property_types property_types_name_key507; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key507 UNIQUE (name);


--
-- Name: property_types property_types_name_key508; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key508 UNIQUE (name);


--
-- Name: property_types property_types_name_key509; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key509 UNIQUE (name);


--
-- Name: property_types property_types_name_key51; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key51 UNIQUE (name);


--
-- Name: property_types property_types_name_key510; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key510 UNIQUE (name);


--
-- Name: property_types property_types_name_key511; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key511 UNIQUE (name);


--
-- Name: property_types property_types_name_key512; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key512 UNIQUE (name);


--
-- Name: property_types property_types_name_key513; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key513 UNIQUE (name);


--
-- Name: property_types property_types_name_key514; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key514 UNIQUE (name);


--
-- Name: property_types property_types_name_key515; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key515 UNIQUE (name);


--
-- Name: property_types property_types_name_key516; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key516 UNIQUE (name);


--
-- Name: property_types property_types_name_key517; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key517 UNIQUE (name);


--
-- Name: property_types property_types_name_key518; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key518 UNIQUE (name);


--
-- Name: property_types property_types_name_key519; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key519 UNIQUE (name);


--
-- Name: property_types property_types_name_key52; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key52 UNIQUE (name);


--
-- Name: property_types property_types_name_key520; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key520 UNIQUE (name);


--
-- Name: property_types property_types_name_key521; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key521 UNIQUE (name);


--
-- Name: property_types property_types_name_key522; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key522 UNIQUE (name);


--
-- Name: property_types property_types_name_key523; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key523 UNIQUE (name);


--
-- Name: property_types property_types_name_key524; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key524 UNIQUE (name);


--
-- Name: property_types property_types_name_key525; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key525 UNIQUE (name);


--
-- Name: property_types property_types_name_key526; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key526 UNIQUE (name);


--
-- Name: property_types property_types_name_key527; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key527 UNIQUE (name);


--
-- Name: property_types property_types_name_key528; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key528 UNIQUE (name);


--
-- Name: property_types property_types_name_key529; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key529 UNIQUE (name);


--
-- Name: property_types property_types_name_key53; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key53 UNIQUE (name);


--
-- Name: property_types property_types_name_key530; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key530 UNIQUE (name);


--
-- Name: property_types property_types_name_key531; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key531 UNIQUE (name);


--
-- Name: property_types property_types_name_key532; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key532 UNIQUE (name);


--
-- Name: property_types property_types_name_key533; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key533 UNIQUE (name);


--
-- Name: property_types property_types_name_key534; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key534 UNIQUE (name);


--
-- Name: property_types property_types_name_key535; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key535 UNIQUE (name);


--
-- Name: property_types property_types_name_key536; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key536 UNIQUE (name);


--
-- Name: property_types property_types_name_key537; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key537 UNIQUE (name);


--
-- Name: property_types property_types_name_key538; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key538 UNIQUE (name);


--
-- Name: property_types property_types_name_key539; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key539 UNIQUE (name);


--
-- Name: property_types property_types_name_key54; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key54 UNIQUE (name);


--
-- Name: property_types property_types_name_key540; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key540 UNIQUE (name);


--
-- Name: property_types property_types_name_key541; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key541 UNIQUE (name);


--
-- Name: property_types property_types_name_key542; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key542 UNIQUE (name);


--
-- Name: property_types property_types_name_key543; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key543 UNIQUE (name);


--
-- Name: property_types property_types_name_key544; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key544 UNIQUE (name);


--
-- Name: property_types property_types_name_key545; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key545 UNIQUE (name);


--
-- Name: property_types property_types_name_key546; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key546 UNIQUE (name);


--
-- Name: property_types property_types_name_key547; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key547 UNIQUE (name);


--
-- Name: property_types property_types_name_key548; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key548 UNIQUE (name);


--
-- Name: property_types property_types_name_key549; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key549 UNIQUE (name);


--
-- Name: property_types property_types_name_key55; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key55 UNIQUE (name);


--
-- Name: property_types property_types_name_key550; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key550 UNIQUE (name);


--
-- Name: property_types property_types_name_key551; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key551 UNIQUE (name);


--
-- Name: property_types property_types_name_key552; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key552 UNIQUE (name);


--
-- Name: property_types property_types_name_key553; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key553 UNIQUE (name);


--
-- Name: property_types property_types_name_key554; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key554 UNIQUE (name);


--
-- Name: property_types property_types_name_key555; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key555 UNIQUE (name);


--
-- Name: property_types property_types_name_key556; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key556 UNIQUE (name);


--
-- Name: property_types property_types_name_key557; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key557 UNIQUE (name);


--
-- Name: property_types property_types_name_key558; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key558 UNIQUE (name);


--
-- Name: property_types property_types_name_key559; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key559 UNIQUE (name);


--
-- Name: property_types property_types_name_key56; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key56 UNIQUE (name);


--
-- Name: property_types property_types_name_key560; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key560 UNIQUE (name);


--
-- Name: property_types property_types_name_key561; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key561 UNIQUE (name);


--
-- Name: property_types property_types_name_key57; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key57 UNIQUE (name);


--
-- Name: property_types property_types_name_key58; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key58 UNIQUE (name);


--
-- Name: property_types property_types_name_key59; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key59 UNIQUE (name);


--
-- Name: property_types property_types_name_key6; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key6 UNIQUE (name);


--
-- Name: property_types property_types_name_key60; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key60 UNIQUE (name);


--
-- Name: property_types property_types_name_key61; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key61 UNIQUE (name);


--
-- Name: property_types property_types_name_key62; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key62 UNIQUE (name);


--
-- Name: property_types property_types_name_key63; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key63 UNIQUE (name);


--
-- Name: property_types property_types_name_key64; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key64 UNIQUE (name);


--
-- Name: property_types property_types_name_key65; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key65 UNIQUE (name);


--
-- Name: property_types property_types_name_key66; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key66 UNIQUE (name);


--
-- Name: property_types property_types_name_key67; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key67 UNIQUE (name);


--
-- Name: property_types property_types_name_key68; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key68 UNIQUE (name);


--
-- Name: property_types property_types_name_key69; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key69 UNIQUE (name);


--
-- Name: property_types property_types_name_key7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key7 UNIQUE (name);


--
-- Name: property_types property_types_name_key70; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key70 UNIQUE (name);


--
-- Name: property_types property_types_name_key71; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key71 UNIQUE (name);


--
-- Name: property_types property_types_name_key72; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key72 UNIQUE (name);


--
-- Name: property_types property_types_name_key73; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key73 UNIQUE (name);


--
-- Name: property_types property_types_name_key74; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key74 UNIQUE (name);


--
-- Name: property_types property_types_name_key75; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key75 UNIQUE (name);


--
-- Name: property_types property_types_name_key76; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key76 UNIQUE (name);


--
-- Name: property_types property_types_name_key77; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key77 UNIQUE (name);


--
-- Name: property_types property_types_name_key78; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key78 UNIQUE (name);


--
-- Name: property_types property_types_name_key79; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key79 UNIQUE (name);


--
-- Name: property_types property_types_name_key8; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key8 UNIQUE (name);


--
-- Name: property_types property_types_name_key80; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key80 UNIQUE (name);


--
-- Name: property_types property_types_name_key81; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key81 UNIQUE (name);


--
-- Name: property_types property_types_name_key82; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key82 UNIQUE (name);


--
-- Name: property_types property_types_name_key83; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key83 UNIQUE (name);


--
-- Name: property_types property_types_name_key84; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key84 UNIQUE (name);


--
-- Name: property_types property_types_name_key85; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key85 UNIQUE (name);


--
-- Name: property_types property_types_name_key86; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key86 UNIQUE (name);


--
-- Name: property_types property_types_name_key87; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key87 UNIQUE (name);


--
-- Name: property_types property_types_name_key88; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key88 UNIQUE (name);


--
-- Name: property_types property_types_name_key89; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key89 UNIQUE (name);


--
-- Name: property_types property_types_name_key9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key9 UNIQUE (name);


--
-- Name: property_types property_types_name_key90; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key90 UNIQUE (name);


--
-- Name: property_types property_types_name_key91; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key91 UNIQUE (name);


--
-- Name: property_types property_types_name_key92; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key92 UNIQUE (name);


--
-- Name: property_types property_types_name_key93; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key93 UNIQUE (name);


--
-- Name: property_types property_types_name_key94; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key94 UNIQUE (name);


--
-- Name: property_types property_types_name_key95; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key95 UNIQUE (name);


--
-- Name: property_types property_types_name_key96; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key96 UNIQUE (name);


--
-- Name: property_types property_types_name_key97; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key97 UNIQUE (name);


--
-- Name: property_types property_types_name_key98; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key98 UNIQUE (name);


--
-- Name: property_types property_types_name_key99; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_name_key99 UNIQUE (name);


--
-- Name: property_types property_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_types
    ADD CONSTRAINT property_types_pkey PRIMARY KEY (id);


--
-- Name: reviews reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT reviews_pkey PRIMARY KEY (id);


--
-- Name: shortlists shortlists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shortlists
    ADD CONSTRAINT shortlists_pkey PRIMARY KEY (id);


--
-- Name: viewed_properties viewed_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.viewed_properties
    ADD CONSTRAINT viewed_properties_pkey PRIMARY KEY (id);


--
-- Name: ChatMessages ChatMessages_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."ChatConversations"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ChatMessages ChatMessages_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ChatMessages"
    ADD CONSTRAINT "ChatMessages_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Localities Localities_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Localities"
    ADD CONSTRAINT "Localities_city_id_fkey" FOREIGN KEY (city_id) REFERENCES public."Cities"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Projects Projects_builder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "Projects_builder_id_fkey" FOREIGN KEY (builder_id) REFERENCES public."Builders"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Projects Projects_city_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "Projects_city_id_fkey" FOREIGN KEY (city_id) REFERENCES public."Cities"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Projects Projects_locality_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "Projects_locality_id_fkey" FOREIGN KEY (locality_id) REFERENCES public."Localities"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Projects Projects_property_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Projects"
    ADD CONSTRAINT "Projects_property_type_id_fkey" FOREIGN KEY (property_type_id) REFERENCES public.property_types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Properties Properties_typeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Properties"
    ADD CONSTRAINT "Properties_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES public.property_types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Testimonials Testimonials_posted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Testimonials"
    ADD CONSTRAINT "Testimonials_posted_by_fkey" FOREIGN KEY (posted_by) REFERENCES public."Users"(id) ON UPDATE CASCADE;


--
-- Name: articles articles_posted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_posted_by_fkey FOREIGN KEY (posted_by) REFERENCES public."Users"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: locality_reviews locality_reviews_localityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locality_reviews
    ADD CONSTRAINT "locality_reviews_localityId_fkey" FOREIGN KEY ("localityId") REFERENCES public."Localities"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: locality_reviews locality_reviews_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locality_reviews
    ADD CONSTRAINT "locality_reviews_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE;


--
-- Name: properties properties_locality_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_locality_id_fkey FOREIGN KEY (locality_id) REFERENCES public."Localities"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: properties properties_posted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_posted_by_fkey FOREIGN KEY (posted_by) REFERENCES public."Users"(id) ON UPDATE CASCADE;


--
-- Name: properties properties_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_project_id_fkey FOREIGN KEY (project_id) REFERENCES public."Projects"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: properties properties_typeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT "properties_typeId_fkey" FOREIGN KEY ("typeId") REFERENCES public.property_types(id) ON UPDATE CASCADE;


--
-- Name: property_amenities property_amenities_amenityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_amenities
    ADD CONSTRAINT "property_amenities_amenityId_fkey" FOREIGN KEY ("amenityId") REFERENCES public.amenities(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_amenities property_amenities_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_amenities
    ADD CONSTRAINT "property_amenities_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: property_faqs property_faqs_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_faqs
    ADD CONSTRAINT "property_faqs_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE;


--
-- Name: property_images property_images_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT "property_images_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviews reviews_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "reviews_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE;


--
-- Name: reviews reviews_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reviews
    ADD CONSTRAINT "reviews_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE;


--
-- Name: shortlists shortlists_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shortlists
    ADD CONSTRAINT "shortlists_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE;


--
-- Name: shortlists shortlists_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shortlists
    ADD CONSTRAINT "shortlists_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE;


--
-- Name: viewed_properties viewed_properties_propertyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.viewed_properties
    ADD CONSTRAINT "viewed_properties_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES public.properties(id) ON UPDATE CASCADE;


--
-- Name: viewed_properties viewed_properties_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.viewed_properties
    ADD CONSTRAINT "viewed_properties_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON UPDATE CASCADE;


--
-- PostgreSQL database dump complete
--

